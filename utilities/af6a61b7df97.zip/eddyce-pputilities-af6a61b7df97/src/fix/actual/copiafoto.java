package fix.actual;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;

import it.portaportese.utils.DBWrapper;


public class copiafoto  extends Thread {
	
	public static void main(String parametri[]) throws Throwable {
		System.out.println("copiafoto V0.4");
		BasicDataSource dbgest = getDS("dbpp");
		BasicDataSource dba400pp3 = getDS("dba400PP20");
		BasicDataSource dba400pp4 = getDS("dba400PP22");
		
		System.out.println("da " + dbgest.getUrl() + " a " + dba400pp3.getUrl() + " e " + dba400pp4.getUrl());
		
		// vado a scorrere gli utenti
		try {
			// scorro le foto
			
			
			Connection cgest = dbgest.getConnection();
			Connection cdba400pp3 = dba400pp3.getConnection();
			Connection cdba400pp4 = dba400pp4.getConnection();
			
			DBWrapper dmflow = new DBWrapper(dba400pp3.getConnection());
			
			dmflow.getList("select ka from annuncio400 where ka in (select annuncio400.ka from annuncio400 left join images on images.ka=annuncio400.ka where rubric>='LA' and tipoannuncio='FG' and images.ka is null)");
			while (dmflow.rsNext()) {
				int ka = dmflow.rsGetInt("ka");
				System.out.println("KA = " + ka);
				if (!contieneFotoKA(cdba400pp3, ka) || !contieneFotoKA(cdba400pp4, ka)) {
					copiaFoto(cgest, cdba400pp3, ka, ka);
					copiaFoto(cgest, cdba400pp4, ka, ka);
				}	
			}
			

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbgest.close();
			dba400pp3.close();
			dba400pp4.close();
		}
	}
	
	private static void cancellaFoto(Connection db, int ka) throws SQLException {
		// System.out.println("Cancello foto " + db.getMetaData().getURL() + " KA " + ka);
	    db.setAutoCommit(false);
	    try {
	    	PreparedStatement stmt = null;
	
	        stmt = db.prepareStatement("delete from images where ka = ?");
	        stmt.setInt(1, ka);
	        stmt.executeUpdate();
	        stmt.close();
	
	    } catch (SQLException e) {
	        System.out.println("cancellaFoto eccezione" + e.getMessage());
	    }
	    db.commit();
	}
	
	private static void copiaFoto(Connection fotoin, Connection fotoout, int ka, int kaout) throws SQLException {
		cancellaFoto(fotoout, kaout);
		System.out.println("Copio foto da " + fotoin.getMetaData().getURL() + " ka " + ka + " su " + fotoout.getMetaData().getURL() + " ka " + kaout );
		
		String q = "select * from images where ka=? order by imgoid;";
		fotoin.setAutoCommit(false);
		PreparedStatement stmt = fotoin.prepareStatement(q);
		stmt.setInt(1, ka);
		
		int kfi=0;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			kfi++;
			Blob immagine = rs.getBlob("imgoid");
			Blob im180x135 = rs.getBlob("im180x135");
			Blob im83x60 = rs.getBlob("im83x60");
			Blob im48x36 = rs.getBlob("im48x36");
			insertImage(fotoout, kaout, kfi, 
					immagine.getBytes(1, (int) immagine.length()), 
					im180x135 != null ? im180x135.getBytes(1, (int) im180x135.length()) : null, 
					im83x60 != null ? im83x60.getBytes(1, (int) im83x60.length()) : null,
							im48x36 != null ? im48x36.getBytes(1, (int) im48x36.length()) : null);
		}
		rs.close();
		stmt.close();
		fotoin.rollback();
	}
	
	private static void insertImage(Connection db, int ka, int id, byte[] immagine, byte[] im180x135, byte[] im83x60, byte[] im48x36) throws SQLException {
	    db.setAutoCommit(false);
	    try {
	    	PreparedStatement stmt = null;
	
	        stmt = db.prepareStatement("INSERT into images (imgoid, im180x135, im83x60, id, ka) " + "VALUES(?,?,?,?,?)");
	        stmt.setBytes(1, immagine);	 // QUESTI SONO I BLOB
	        stmt.setBytes(2, im180x135);
	        stmt.setBytes(3, im83x60);	 
	        stmt.setInt(4, id);	 
	        stmt.setInt(5, ka);
	        stmt.executeUpdate();
	        stmt.close();
	
	    } catch (SQLException e) {
	        System.out.println("insertImage eccezione" + e.getMessage());
	    }
	    db.commit();
	}
	
	private static boolean contieneFotoKA(Connection db, int ka) throws SQLException {
		boolean esiste = false;
		if (ka != 0) {
			try {
				PreparedStatement stmt = db.prepareStatement("select * from images where ka = " + ka);
		
				ResultSet rs = stmt.executeQuery();
				esiste = rs.next();
				if (esiste) {
					// verifico tutti e 3
					try {
						Blob immagine = rs.getBlob("imgoid");
						immagine = rs.getBlob("im180x135");
						immagine = rs.getBlob("im83x60");
						// se li carica tutti e 3 ...
					} catch (Exception e) {
						esiste = false;
					}
				}
				
				rs.close();
				stmt.close();
				db.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("ka " + ka + (esiste ? " ha " : " non ha " ) + "foto su " + db.getMetaData().getURL());
		return esiste;
	}
		
    public static BasicDataSource getDS(String poolname) {

        String mutex = "";
        synchronized (mutex) {

            BasicDataSource ds = null;
            try {
                ds = new BasicDataSource();
                
                ds.setMaxActive(350);   // cambiato da 150 a 350 dopo aver messo i threads a 80
                ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
                ds.setMinIdle(10);

                ds.setDriverClassName("org.postgresql.Driver");

                if (poolname.equals("dbppLOC")) {
                    ds.setUsername("pepper");
                    ds.setPassword("ciccio");
                    ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

                } else if (poolname.equals("dbpp")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://pp200.prv.lan/portaportese?compatible=7.1");

                } else {
    				// si aspetta una cosa tipo: dba400PP4
    				String machinename = poolname.substring(6, poolname.length()).toLowerCase();
    				ds.setUsername("pepper");
    				ds.setPassword("hotsauce");
    				ds.setUrl("jdbc:postgresql://" + machinename + ".prv.lan/dba400L1?compatible=7.1");
                }
                
            } catch (Exception e) {
            	System.out.println("getDS chiedendo " + ds.getUrl() + "\nEccezione: " + e.getMessage());
            }
            return ds;
        }
    }
}