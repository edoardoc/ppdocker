package fix.actual;



public class test  extends Thread {
	
	public static void main(String parametri[]) throws Throwable {
		System.out.println(">INIZIALIZZAZIONE<");
		for (int i=0; i < 12; i++) {
			System.out.println("iesimo " + (i % (12/2)));
		}
    }
}