package fix.actual;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;


public class aggiornaNumFotoA400  extends Thread {
	
	public static void main(String parametri[]) throws Throwable {
		System.out.println(">INIZIALIZZAZIONE<");
		BasicDataSource dsdest = getDS(parametri[0]);
		BasicDataSource dssrc = getDS("dbpp");
		
		System.out.println("source  on " + dssrc.getUrl());
		System.out.println("working on " + dsdest.getUrl());
		
		// vado a scorrere gli utenti
		try {
			Connection conn = dssrc.getConnection();
			Connection conn2 = dsdest.getConnection();
	        // PG8
			conn.setAutoCommit(false);
			PreparedStatement stmt = conn.prepareStatement("select ka, numerofoto from annuncio400 where uscita=22 and numerofoto > 6");
	
			ResultSet rs = stmt.executeQuery();
			int count = 0;
			while (rs.next()) {
				if (((++count) % 50) == 0) {
					System.out.println("sono arrivato a " + count + " records...");
				}

				
				int ka = rs.getInt("ka");
				int numerofoto = rs.getInt("numerofoto");
				
				aggiorna(conn2, ka, numerofoto);
			}
			rs.close();
			stmt.close();
			conn.close();
			conn2.close();
			System.out.println("Processati: " + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private static void aggiorna(Connection db, int ka, int numerofoto) throws SQLException {
		try {
            db.setAutoCommit(false);
        	
            try {
            	PreparedStatement stmt = null;
            	
                stmt = db.prepareStatement("update annuncio400 set numerofoto=? where ka=? and numerofoto=6");
                System.out.println("ka " + ka + " nfoto: " + numerofoto);
			
                stmt.setShort(1, (short)numerofoto);
                stmt.setInt(2, ka);
                stmt.executeUpdate();
                stmt.close();
            	System.out.println(" Ok!");
                
            } catch (SQLException e) {
            	System.out.println("aggiorna eccezione SQL: " + e.getMessage());
            }
            db.commit();
            
        } catch (Exception e) {
        	System.out.println("aggiorna eccezione: " + e.getMessage());
        }
	}
	
    public static BasicDataSource getDS(String poolname) {

        String mutex = "";
        synchronized (mutex) {

            BasicDataSource ds = null;
            try {
                ds = new BasicDataSource();
                
                ds.setMaxActive(350);   // cambiato da 150 a 350 dopo aver messo i threads a 80
                ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
                ds.setMinIdle(10);

                ds.setDriverClassName("org.postgresql.Driver");

                if (poolname.equals("dbppLOC")) {
                    ds.setUsername("pepper");
                    ds.setPassword("ciccio");
                    ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

                } else if (poolname.equals("dbppPP2")) {
                    ds.setUsername("pepper");
                    ds.setPassword("hotsauce");
                    ds.setUrl("jdbc:postgresql://pp2.prv.lan/portaportese?compatible=7.1");
                    
                } else if (poolname.equals("dbpp")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://pp30.prv.lan/portaportese?compatible=7.1");

                } else {
    				// si aspetta una cosa tipo: dba400PP4
    				String machinename = poolname.substring(6, poolname.length()).toLowerCase();
    				ds.setUsername("pepper");
    				ds.setPassword("hotsauce");
    				ds.setUrl("jdbc:postgresql://" + machinename + ".prv.lan/dba400L1?compatible=7.1");
                }
                
            } catch (Exception e) {
            	System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
            }
            return ds;
        }
    }
}