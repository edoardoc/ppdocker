package fix.actual;

import forms.AggiuntaMedia;
import it.portaportese.utils.functions;
import it.portaportese.utils.logging.Syslog;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;


public class copiaFOTOPP30  extends Thread {
	
	public static void main(String parametri[]) throws Throwable {
		System.out.println("ver. 1.3");
		BasicDataSource dspp1 = getDS("dbppPP1");
		BasicDataSource dspp30 = getDS("dbppPP5");
		
		System.out.println("pp1  on " + dspp1.getUrl());
		System.out.println("pp30 on " + dspp30.getUrl());
		
		/*
		 * 
		 * su gestionale pp1
tutti i record annuncio ku >= 1083 
se ka annuncio esiste nella tabella images di pp30
	SI
	loggo eventuali righe images gia presenti con quel ka
	copia le immagini da pp30 a pp1 con lo stesso ka (INSERT)
	NO
	se kaprovenienza  esiste nella tabella images di pp30
		SI
		copia le immagini da pp30 a pp1 con lo stesso ka (INSERT)
		copia le immagini da pp30 a pp1 con lo stesso ka (la stessa insert
		 * 
		 * 
		 */
		boolean ai = false;
		try {
			ai = (parametri[3].equalsIgnoreCase("ai"));
		} catch (Exception e) {
			ai = false;
		}
		// vado a scorrere gli utenti
		try {
			Connection connpp1 = dspp1.getConnection();
			Connection connpp1list = dspp1.getConnection();
			Connection connpp30 = dspp30.getConnection();

			connpp1.setAutoCommit(false);
			connpp30.setAutoCommit(false);
			String qq = "select * from annuncio  where " + (ai ? "attributi like 'A%' AND" : "")  + " ku = " + parametri[0] + " order by ka offset " + parametri[1] + " limit " + parametri[2];
			System.out.println(qq);
			PreparedStatement stmt = connpp1list.prepareStatement(qq);;
	
			ResultSet rs = stmt.executeQuery();
			int count = 0;
			while (rs.next()) {
				if (((++count) % 50) == 0) {
					System.out.println("sono arrivato a " + count + " records...");
				}
				
				int ka = rs.getInt("ka");
				int kaprovenienza = rs.getInt("kaprovenienza");
				
				// se ka annuncio esiste nella tabella images di pp30
				System.out.print("PP30 ");
				if (checkKA(connpp30, ka)) {
					// se ka annuncio non esiste nella tabella images di pp1
					System.out.print("PP1 ");
					if (!checkKA(connpp1, ka)) {
						// copio foto images pp30 ka e scrivo images pp1 ka
						copiaFoto(connpp30, connpp1, ka, ka);
					}
				} else {
					System.out.print("PP30 provenienza ");
					if (checkKA(connpp30, kaprovenienza)) {
						// se ka annuncio non esiste nella tabella images di pp1
						System.out.print("PP1 provenienza ");
						if (!checkKA(connpp1, ka)) {
							// copio foto images pp30 kaprovenienza e scrivo images pp1 ka
							copiaFoto(connpp30, connpp1, kaprovenienza, ka);
						}
					}
				}
				System.out.println("--");
			}
			rs.close();
			stmt.close();
			connpp30.close();
			connpp1.close();
			System.out.println("Processati: " + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private static void copiaFoto(Connection fotoin, Connection fotoout, int ka, int kaout) throws SQLException {
		cancellaFoto(fotoout, kaout);
		System.out.println("Copio foto da pp30 ka " + ka + " su pp1 ka " + kaout );
		
		String q = "select * from images where ka=? order by imgoid;";
		fotoin.setAutoCommit(false);
		PreparedStatement stmt = fotoin.prepareStatement(q);
		stmt.setInt(1, ka);
		
		int kfi=0;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			kfi++;
			Blob immagine = rs.getBlob("imgoid");
			Blob im180x135 = rs.getBlob("im180x135");
			Blob im83x60 = rs.getBlob("im83x60");
			Blob im48x36 = rs.getBlob("im48x36");
			insertImage(fotoout, kaout, kfi, 
					immagine.getBytes(1, (int) immagine.length()), 
					im180x135 != null ? im180x135.getBytes(1, (int) im180x135.length()) : null, 
					im83x60 != null ? im83x60.getBytes(1, (int) im83x60.length()) : null,
							im48x36 != null ? im48x36.getBytes(1, (int) im48x36.length()) : null);
		}
		rs.close();
		stmt.close();
		fotoin.rollback();
	}
	
	private static void insertImage(Connection db, int ka, int id, byte[] immagine, byte[] im180x135, byte[] im83x60, byte[] im48x36) throws SQLException {
	    db.setAutoCommit(false);
	    try {
	    	PreparedStatement stmt = null;
	
	        stmt = db.prepareStatement("INSERT into images (imgoid, im180x135, im83x60, im48x36, ka) " + "VALUES(?,?,?,?,?)");
	        stmt.setBytes(1, immagine);	 // QUESTI SONO I BLOB
	        stmt.setBytes(2, im180x135);
	        stmt.setBytes(3, im83x60);	 
	        stmt.setBytes(4, im48x36);	 
	        stmt.setInt(5, ka);
	        stmt.executeUpdate();
	        stmt.close();
	
	    } catch (SQLException e) {
	        System.out.println("insertImage eccezione" + e.getMessage());
	    }
	    db.commit();
	}
	
	private static void cancellaFoto(Connection db, int ka) throws SQLException {
		System.out.println("Cancello foto PP1 KA " + ka);
	    db.setAutoCommit(false);
	    try {
	    	PreparedStatement stmt = null;
	
	        stmt = db.prepareStatement("delete from images where ka = ?");
	        stmt.setInt(1, ka);
	        stmt.executeUpdate();
	        stmt.close();
	
	    } catch (SQLException e) {
	        System.out.println("cancellaFoto eccezione" + e.getMessage());
	    }
	    db.commit();
	}
	
	private static boolean checkKA(Connection db, int ka) throws SQLException {
		boolean esiste = false;
		if (ka != 0) {
			try {
				PreparedStatement stmt = db.prepareStatement("select * from images where ka = " + ka);
		
				ResultSet rs = stmt.executeQuery();
				esiste = rs.next();
				if (esiste) {
					// verifico tutti e 3
					try {
						Blob immagine = rs.getBlob("imgoid");
						immagine = rs.getBlob("im180x135");
						immagine = rs.getBlob("im83x60");
						// se li carica tutti e 3 ...
					} catch (Exception e) {
						esiste = false;
					}
				}
				
				rs.close();
				stmt.close();
				db.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println((!esiste ? "non " : "" ) + "esiste ka " + ka);
		return esiste;
	}
		
    public static BasicDataSource getDS(String poolname) {

        String mutex = "";
        synchronized (mutex) {

            BasicDataSource ds = null;
            try {
                ds = new BasicDataSource();
                
                ds.setMaxActive(350);   // cambiato da 150 a 350 dopo aver messo i threads a 80
                ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
                ds.setMinIdle(10);

                ds.setDriverClassName("org.postgresql.Driver");

                if (poolname.equals("dbppLOC")) {
                    ds.setUsername("pepper");
                    ds.setPassword("ciccio");
                    ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

                } else if (poolname.equals("dbppPP2")) {
                    ds.setUsername("pepper");
                    ds.setPassword("hotsauce");
                    ds.setUrl("jdbc:postgresql://pp2.prv.lan/portaportese?compatible=7.1");
                    
                } else if (poolname.equals("dbppPP30")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://pp40.inroma.roma.it:5430/portaportese?compatible=7.1");
                    // ds.setUrl("jdbc:postgresql://pp30.prv.lan/portaportese?compatible=7.1");

                } else if (poolname.equals("dbppPP1")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://pp1.prv.lan/portaportese?compatible=7.1");

                } else if (poolname.equals("dbppPP5")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://10.0.0.5/portaportese?compatible=7.1");

                } else {
    				// si aspetta una cosa tipo: dba400PP4
    				String machinename = poolname.substring(6, poolname.length()).toLowerCase();
    				ds.setUsername("pepper");
    				ds.setPassword("hotsauce");
    				ds.setUrl("jdbc:postgresql://" + machinename + ".prv.lan/dba400L1?compatible=7.1");
                }
                
            } catch (Exception e) {
            	System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
            }
            return ds;
        }
    }
}