package fix.actual;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;


public class riempiBuchi  extends Thread {
	
	public static void main(String parametri[]) throws Throwable {
		System.out.println(">INIZIALIZZAZIONE<");
		BasicDataSource dssrc = getDS(parametri[0]);

		int quanti = Integer.parseInt(parametri[1]);
		
		System.out.println("working on " + dssrc.getUrl() + " per limit " + quanti);
		
		// vado a scorrere gli utenti
		try {
			Connection conn = dssrc.getConnection();
			Connection conn2 = dssrc.getConnection();
	        // PG8
			conn.setAutoCommit(false);
			PreparedStatement stmt = conn.prepareStatement("select codutente from utente where codutente > 100000 and codutente < 799999 order by codutente limit " + quanti);
	
			ResultSet rs = stmt.executeQuery();
			int count = 100000;
			while (rs.next()) {
				if (((++count) % 50) == 0) {
					System.out.println("sono arrivato a " + count + " records...");
				}

				
				int prossimocutente = rs.getInt("codutente");
				if (count != prossimocutente) {
					System.out.println("parto da " + count + " a " + prossimocutente);
					for (;count < prossimocutente; count++) {
						inserisci(conn2, count);
					}
				}
			}
			rs.close();
			stmt.close();
			conn.close();
			conn2.close();
			System.out.println("Processati: " + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private static void inserisci(Connection db, int newcod) throws SQLException {
		try {
            db.setAutoCommit(false);
        	
            try {
            	PreparedStatement stmt = null;
            	
            	System.out.print("inserisco: " + newcod);
                stmt = db.prepareStatement("insert into utente (codutente, dataultimologin, dataregistrazione) VALUES(?, '1/1/1970', '1/1/1970');");
                stmt.setInt(1, newcod);  // devi salvare le varie versioni
                stmt.executeUpdate();
                stmt.close();
            	System.out.println(" Ok!");
                
            } catch (SQLException e) {
            	System.out.println("inserisciFinoA eccezione SQL: " + e.getMessage());
            }
            db.commit();
            
        } catch (Exception e) {
        	System.out.println("inserisciFinoA eccezione: " + e.getMessage());
        }
	}
	
    public static BasicDataSource getDS(String poolname) {

        String mutex = "";
        synchronized (mutex) {

            BasicDataSource ds = null;
            try {
                ds = new BasicDataSource();
                
                ds.setMaxActive(350);   // cambiato da 150 a 350 dopo aver messo i threads a 80
                ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
                ds.setMinIdle(10);

                ds.setDriverClassName("org.postgresql.Driver");

                if (poolname.equals("dbppLOC")) {
                    ds.setUsername("pepper");
                    ds.setPassword("ciccio");
                    ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

                } else if (poolname.equals("dbppPP2")) {
                    ds.setUsername("pepper");
                    ds.setPassword("hotsauce");
                    ds.setUrl("jdbc:postgresql://pp2.prv.lan/portaportese?compatible=7.1");
                    
                } else if (poolname.equals("dbpp")) {
                    ds.setUsername("pepper");
                    ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
                    ds.setUrl("jdbc:postgresql://pp30.prv.lan/portaportese?compatible=7.1");

                } else {
    				// si aspetta una cosa tipo: dba400PP4
    				String machinename = poolname.substring(6, poolname.length()).toLowerCase();
    				ds.setUsername("pepper");
    				ds.setPassword("hotsauce");
    				ds.setUrl("jdbc:postgresql://" + machinename + ".prv.lan/dba400L1?compatible=7.1");
                }
                
            } catch (Exception e) {
            	System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
            }
            return ds;
        }
    }
}