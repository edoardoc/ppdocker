package logprocessors;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class ParseDeleted {

        public static void main(String[] args) {
                Hashtable cword = new Hashtable(); 

                InputStreamReader sr = new InputStreamReader(System.in);
                BufferedReader br = new BufferedReader(sr);

                while (true) {
                        String line;
                        try {
                                line = br.readLine();
                        } catch (IOException e) {
                                break;
                        }

                        if (line == null || line.equals(""))
                                break;

                        // da qui in poi ho la linea
                        String parole = "";
                        String tag = "ka=";
                        int id1 = line.indexOf(tag) + tag.length();
                        String secondaparte = line.substring(id1);
                        
                        String tag2=" codcliente=";
                        int id2start = secondaparte.indexOf(tag2);
                        int id2end = id2start + tag2.length();
                        String terzaparte = secondaparte.substring(id2end);

                        int id3=terzaparte.indexOf("cancello da");
                        
                        String ka = secondaparte.substring(0, id2start);
                        String cc = terzaparte.substring(0, id3);
                        System.out.println("delete from annuncio400 where ka="+ ka + " AND codcliente=" + cc + ";");


                }
        }
}

