package savers;

import java.sql.SQLException;

import forms.AnnuncioBean;
import gestione.utils;
import it.portaportese.system.Impostazioni;
import it.portaportese.utils.DBWrapper;
import it.portaportese.utils.Strings;
import it.portaportese.utils.functions;

public class AnnuncioSaver {
	DBWrapper dm;
    private String mutex = "";
	
	public AnnuncioSaver(DBWrapper indm) {
		dm=indm;
	}
	
	public boolean update(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
		
		if (f.getTipoannuncio().equals("VT")) {
			f.setAttributi("AL");
		}
		if (f.getKa() != 0) {
			String QOut="UPDATE Annuncio SET " +
					"testo= '" + Strings.stripChar('\n', Strings.purify(f.getTesto())) + 	"', " +
					"titolo= '" + Strings.purify(f.getTitolo()) + 	"', " +
					"addinfo= '" + Strings.purify(f.getAddinfo()) + 	"', " +
					"immoviewer= '" + Strings.purify(f.getImmoviewer()) + 	"', " +
					"telef1= '" + Strings.purify(f.getTelef1()) + 	"', " +
					"pref1= '" + Strings.purify(f.getPref1()) + 	"', " +
					"telef2= '" + Strings.purify(f.getTelef2()) + 	"', " +
					"pref2= '" + Strings.purify(f.getPref2()) + 	"', " +
					"alimentazione= '" + Strings.purify(f.getAlimentazione()) + 	"', " +
					"modello= '" + Strings.purify(f.getModello()) + 	"', " +
					"tipologia= '" + Strings.purify(f.getTipologiaimmobile()) + 	"', " +
					"prezzo= '" + Strings.purify(f.getPrezzo()) + 	"', " +
					"locali= " + f.getLocali() + 					", " +
					"postiletto= " + f.getPostiletto() + 			", " +
					"m2= " + f.getMq() + 							", " +
					"km= " + f.getKm() + 							", " +
					"anno= " + f.getAnno() + 						", " +
					"nf= '', " + /* indica che e' stato modificato -> se era ripetuto */
					"tiprec= '" + Strings.purify(f.getTiprec()) + 	"', " +
					"latitudine= " + f.getLatitudine() + 	", " +
					"longitudine= " + f.getLongitudine() + 	", " +
					"codutente= " + f.getCodutente() + 	", " +
					"statoai = '" + f.getStatoai() + "', " +
					"ke=0, " + /* indica che e' stato modificato -> se era gia' stato esportato */ 
					"kr= " + f.getKr() + 							", " +
					(f.getKu() != 0 ? "ku= " + f.getKu() + ", " : "") +
					(!f.getAttributi().equals("") ? "attributi= '" + f.getAttributi() + "', " : "") +
					"tipo= '" + Strings.purify(f.getTipofordb()) + 	"', " +
					"tipoace= '" + Strings.purify(f.getTipoace()) + 	"', " +
					"ipimmissione= '" + Strings.purify(f.getIpimmissione()) + 	"', " +
					"data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", " +
					"pubblicaemail= '" + Strings.purify(f.getDBpubblicaemail()) + "' " +
					"WHERE ka=" + f.getKa();

			dm.setSql(QOut);
			rval=(dm.executeSql() > 0 ? true : false);

			// cancello vecchie foto se cambia da F a Normale 
			if (rval && utils.tipoFoto(f.getTipoannuncioprecedente()) && !utils.tipoFoto(f.getTipoannuncio())) {
				// cancello anche eventuali foto
				dm.setSql("delete from images where ka=" + f.getKa());
				dm.executeSql();
			}
		} // check ka
		return rval;
	}
	public boolean salvaFormato(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval = false;
		
		if (!(f.getTipoannuncio() == null) && !f.getTipoannuncio().equals("")) {
            if (f.getTipoannuncio().equals("VT")) {
            	f.setAttributi("AL");
            }
			String QOut =
				"UPDATE Annuncio SET "
					+ "tipoannuncio = '" + f.getTipoannuncio() + "', "
					+ "attributi = '" + f.getAttributi() + "', "
                    + "data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", "
					+ "nf= '', " /* indica che e' stato modificato -> se era ripetuto */
                    + "ku= " + f.getKu() + ", " /* indica che e' stato modificato -> se era ripetuto */
					+ "ke=0, "   /* indica che e' stato modificato -> se era gia' stato esportato */
					+ "numerofoto= " + f.getNumerofoto() + " "
					+ "WHERE (ka=" + f.getKa() + " AND codutente = " + codiceutente + ") AND ((attributi is null or attributi = '') OR (ke = 0))";

			dm.setSql(QOut);
			rval = (dm.executeSql() > 0 ? true : false);
			// Syslog.write("salvaFormato " + rval + " - " + QOut);
			
			if (rval) {
				
				if (utils.tipoFoto(f.getTipoannuncioprecedente()) && !utils.tipoFoto(f.getTipoannuncio())) {
					// cancello anche eventuali foto
					dm.setSql("delete from images where ka=" + f.getKa());
					dm.executeSql();
				}
			}
		}

		return rval;
	}
	public boolean salvaYoutube(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval = false;
		
		String QOut =
			"UPDATE Annuncio SET "
				+ "videolink = '" + f.getVideolink() + "', "
				+ "videostatus = " + f.getVideostatus() + ", "
				+ "videodir = '" + f.getVideodir() + "', "
				+ "videofrom = " + f.getVideofrom() + " "
				+ "WHERE ka=" + f.getKa();

		dm.setSql(QOut);
		rval = (dm.executeSql() > 0 ? true : false);
		// Syslog.write("retcode " + rval + " - " + QOut);

		return rval;
	}
	/*
	 * ripete le foto, compresi i formati miniblob
	 */
	public boolean ripetiFoto(AnnuncioBean f, int vecchioka) throws SQLException {
		boolean rval = false;

		String QOut ="INSERT INTO images ( ka, imgoid, im48x36, im180x135, im83x60, nomefile, url ) SELECT " + f.getKa() + ", imgoid, im48x36, im180x135, im83x60, nomefile, url FROM images WHERE images.ka=" + vecchioka + " order by oid;";
		dm.setSql(QOut);
		rval = (dm.executeSql() > 0 ? true : false);
		
		return rval;
	}
	
	/*
	 * resetta per controlli (dopo aggiornamento foto)
	 */
	public boolean reset(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
	
		String QOut="UPDATE Annuncio SET " +
                "data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", " +
				"nf= '', " +
				"numerofoto= " + f.getNumerofoto() + ", " +
				"ke=0 " +	// imposto ke = 0 per farlo riesportare nuovamente
				"WHERE ka=" + f.getKa(); // + " AND codutente = " + codiceutente;
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}
	
	/*
	 * resetta per controlli (dopo aggiornamento foto) VERSIONE QUICK (solo su KA)
	 */
	public boolean reset(AnnuncioBean f) throws SQLException {
		boolean rval=false;
	
		String QOut="UPDATE Annuncio SET " +
                "data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", " +
				"nf= '', " +
				"numerofoto= " + f.getNumerofoto() + ", " +
				"ke=0 " +	// imposto ke = 0 per farlo riesportare nuovamente
				"WHERE ka=" + f.getKa();
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}
	
	public boolean delete(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
	
		String QOut="UPDATE Annuncio SET " +
                "data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", " +
				"statoai= 'W', " + /* indica che e' stato cancellato */
				"nf= 'X', " + /* indica che e' stato cancellato */
				"ke=0 " +	// imposto ke = 0 per farlo riesportare nuovamente
				"WHERE ka=" + f.getKa() + " AND codutente = " + codiceutente;
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}

	public boolean markPerCancellazione(int ka, int codiceutente) throws SQLException {
		boolean rval=false;
		String QOut="UPDATE Annuncio SET nf= 'X', statoai= 'W', ke=0 WHERE ka=" + ka + " AND codutente = " + codiceutente;
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}
	
	public boolean ripristina(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
	
		String QOut="UPDATE Annuncio SET " +
                "data= " + Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + ", " +
				"statoai= 'W', " + /* indica che e' stato cambiato */
				"nf= '" + f.getNf() + "', " +
				"ke=0 " +	// imposto ke = 0 per farlo riesportare nuovamente
				"WHERE ka=" + f.getKa()  + " AND codutente = " + codiceutente;;
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}
	public boolean exists(AnnuncioBean f) throws SQLException {	
		//		VERIFICA DUPLICATO
		boolean Exists = false;
		String qq= "SELECT * from annuncio WHERE telef1 = '"
					+ Strings.purify(f.getTelef1())
					+ "' and codutente="
					+ f.getCodutente()
                    + " and tipoannuncio='"
                    + f.getTipoannuncio()
                    + "' and attributi='"
                    + f.getAttributi()
					+ "' and tipo='"
					+ f.getTipofordb()
					+ "' and pref1='"
					+ Strings.purify(f.getPref1())
					+ "' and kr="
					+ f.getKr()
					+ " and ku="
					+ f.getKu()
					+ " and testo='"
					+ Strings.purify(f.getTesto())
					+ "';";
		dm.getList(qq);
		//Syslog.write("query verifica duplicato="+qq);
		Exists = dm.rsNext();
		
		if (Exists) {
			f.setKa(dm.rsGetInt("ka"));	// salvo il ka se successivamente devo fare un ripristino
			f.setNf(dm.rsGetString("nf"));	// se esiste devo sapere il perche'
		}
		dm.rsClose();
		return Exists;
	}
	public boolean loadpermodifica(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
		if (f.getKa() != 0) {
			String Q="SELECT * FROM Annuncio WHERE ka=" + f.getKa()  + " AND codutente = " + codiceutente + " AND ((attributi = 'AI' AND ke = 0) OR (attributi <> 'AI')) ";
			dm.getList(Q);
			
			if (dm.rsNext()) {
					rval=true;
					assegna(f);
			}
			dm.rsClose();
			// Syslog.write(Q + " caricato " + rval);
		} 
		return rval;
	}
	
	/* versione di load per paginaformato che non permette caricamenti incoerenti */
	public boolean load(AnnuncioBean f, int codiceutente, int maxkugest) throws SQLException {
		boolean rval=false;
		if ((f.getKa() != 0) && (codiceutente != 0) && (maxkugest != 0)) {
			String Q="SELECT * FROM Annuncio WHERE ka=" + f.getKa()  + " AND codutente = " + codiceutente + " AND ku > " + maxkugest;
			dm.getList(Q);
			
			if (dm.rsNext()) {
					rval=true;
					assegna(f);
			}
			dm.rsClose();
		} 
		return rval;
	}
	
	public boolean load(AnnuncioBean f, int codiceutente) throws SQLException {
		boolean rval=false;
		if ((f.getKa() != 0) && (codiceutente != 0)) {
			String Q="SELECT * FROM Annuncio WHERE ka=" + f.getKa()  + " AND codutente = " + codiceutente;
			dm.getList(Q);
			
			if (dm.rsNext()) {
					rval=true;
					assegna(f);
			}
			dm.rsClose();
		} 
		return rval;
	}
	/*
	 * nuova versione di load che usa solo il KA 
	 * 
	 * NON USARE IN MIOPP
	 * 
	 */
	public boolean load(AnnuncioBean f) throws SQLException {
		boolean rval=false;
		if (f.getKa() != 0) {
			String Q="SELECT * FROM Annuncio WHERE ka=" + f.getKa();
			dm.getList(Q);
			
			if (dm.rsNext()) {
					rval=true;
					assegna(f);
			}
			dm.rsClose();
		} 
		return rval;
	}
	
	public void assegna(AnnuncioBean f) throws SQLException {
		f.setCodutente(dm.rsGetInt("codutente"));
		f.setTesto(dm.rsGetString("testo"));
		f.setTitolo(dm.rsGetString("titolo"));
		f.setAddinfo(dm.rsGetString("addinfo"));
		f.setImmoviewer(dm.rsGetString("immoviewer"));
		f.setTipo(dm.rsGetString("tipo"));
		f.setTipoace(dm.rsGetString("tipoace"));
		f.setKr(dm.rsGetInt("kr"));		
		f.setKroriginale(f.getKr());
		f.setKu(dm.rsGetInt("ku"));
		f.setKa(dm.rsGetInt("ka"));
		f.setKe(dm.rsGetInt("ke"));
		f.setNumerofoto(dm.rsGetInt("numerofoto"));
		f.setData(dm.rsGetTimestamp("data"));
		f.setDataprimoinserimento(dm.rsGetTimestamp("dataprimoinserimento"));
		f.setPref1(dm.rsGetString("pref1"));
		f.setTelef1(dm.rsGetString("telef1"));
		f.setPref2(dm.rsGetString("pref2"));
		f.setTelef2(dm.rsGetString("telef2"));
		f.setAlimentazione(dm.rsGetString("alimentazione"));
		f.setModello(dm.rsGetString("modello"));
		f.setTipologiaimmobile(dm.rsGetString("tipologia"));
		f.setPrezzo(dm.rsGetString("prezzo"));
		f.setLocali(dm.rsGetInt("locali"));
		f.setPostiletto(dm.rsGetInt("postiletto"));
		f.setMq(dm.rsGetInt("m2"));
		f.setKm(dm.rsGetInt("km"));
		f.setAnno(dm.rsGetInt("anno"));

		f.setTiprec(dm.rsGetString("tiprec"));
		f.setNf(dm.rsGetString("nf"));
		f.setTipoannuncio(dm.rsGetString("tipoannuncio"));
		f.setAttributi(dm.rsGetString("attributi"));
		f.setTipoannuncioprecedente(dm.rsGetString("tipoannuncio"));
		f.setIpimmissione(dm.rsGetString("ipimmissione"));
		f.setPubblicaemail(dm.rsGetBoolean("pubblicaemail") ? "on" : "");
		f.setKaprovenienza(dm.rsGetInt("kaprovenienza"));
		f.setVideofrom(dm.rsGetInt("videofrom"));
		f.setVideostatus(dm.rsGetInt("videostatus"));
		f.setVideolink(dm.rsGetString("videolink"));
		f.setVideodir(dm.rsGetString("videodir"));
		f.setLatitudine(dm.rsGetDouble("latitudine"));
		f.setLongitudine(dm.rsGetDouble("longitudine"));
		f.setStatoai(dm.rsGetString("statoai"));
	}
	
	public int save(AnnuncioBean f) throws SQLException {
	
		String QOut="INSERT INTO annuncio (" +
								"codutente, " +
								"testo, " +
								"titolo, " +
								"addinfo, " +
								"immoviewer, " +
								"telef1, " +
								"pref1, " +
								"telef2, " +
								"pref2, " +
								"alimentazione, " +
								"modello, " +
								"tipologia, " +
								"prezzo, " +
								"locali, " +
								"postiletto, " +
								"m2, " +
								"km, " +
								"anno, " +
								"tiprec, " +
								"nf, " +
								"tipoannuncio, " +
								"attributi, " +
								"tipoace, " +
								"ipimmissione, " +
								"videolink, " +
								"videodir, " +
								"videostatus, " +
								"videofrom, " +
								"kaprovenienza, " +
								"kr, " +
								"ku, " +
								"ke, " +
								"numerofoto, " +
								"latitudine, " +
								"longitudine, " +
								"tipo, " +
								"pubblicaemail, " +
								"data " +
							") " +
							Impostazioni.DBVALUES +  
								+ f.getCodutente() + ", " +
								Impostazioni.DBSTRDEL + Strings.stripChar('\n', Strings.purify(f.getTesto())) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getTitolo()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getAddinfo()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getImmoviewer()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getTelef1()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getPref1()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getTelef2()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getPref2()) + Impostazioni.DBSTRDEL + ", " +
								
								Impostazioni.DBSTRDEL + Strings.purify(f.getAlimentazione()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getModello()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getTipologiaimmobile()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getPrezzo()) + Impostazioni.DBSTRDEL + ", " +
								f.getLocali() + ", " +
								f.getPostiletto() + ", " +
								f.getMq() + ", " +
								f.getKm() + ", " +
								f.getAnno() + ", " +
								
								Impostazioni.DBSTRDEL + Strings.purify(f.getTiprec()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getNf()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getTipoannuncio()) + Impostazioni.DBSTRDEL + ", " + 
								Impostazioni.DBSTRDEL + Strings.purify(f.getAttributi()) + Impostazioni.DBSTRDEL + ", " + 
								Impostazioni.DBSTRDEL + Strings.purify(f.getTipoace()) + Impostazioni.DBSTRDEL + ", " + 
								Impostazioni.DBSTRDEL + Strings.purify(f.getIpimmissione()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getVideolink()) + Impostazioni.DBSTRDEL + ", " +
								Impostazioni.DBSTRDEL + Strings.purify(f.getVideodir()) + Impostazioni.DBSTRDEL + ", " +
								f.getVideostatus() + ", " +
								f.getVideofrom() + ", " +
								f.getKaprovenienza() + ", " +
								f.getKr() + ", " +
								f.getKu() + ", " +
								f.getKe() + ", " +
								f.getNumerofoto() + ", " + 
								f.getLatitudine() + ", " + 
								f.getLongitudine() + ", " + 
								Impostazioni.DBSTRDEL + Strings.purify(f.getTipofordb()) + Impostazioni.DBSTRDEL + ", " +
								Strings.purify(f.getDBpubblicaemail()) + ", " +
								Impostazioni.DBSTRDEL + functions.sqlDate(Impostazioni.DATE2SAVEFORMAT) + Impostazioni.DBSTRDEL + " " +
							Impostazioni.DBVALUESCLOSE + "  RETURNING ka; ";

		dm.getList(QOut);
		dm.rsNext();
		int ka = dm.rsGetInt("ka");

		return ka;
	}

	public boolean deleteVideo(AnnuncioBean f) throws SQLException {
		boolean rval=false;
	
		String QOut="UPDATE Annuncio SET " +
				"videostatus= 0, " +
				"videofrom= 0, " +
				"videolink= '', " +
				"videodir= '', " +
				"ke=0 " +	// imposto ke = 0 per farlo riesportare nuovamente
				"WHERE ka=" + f.getKa();
		
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}

	/* DA TOGLIERE */
	public boolean saveNormale(AnnuncioBean f) throws SQLException {
		boolean rval=false;
		
		String QOut="UPDATE Annuncio SET corretto = true, ke = 0 WHERE ka=" + f.getKa();
		dm.setSql(QOut);
		rval=(dm.executeSql() > 0 ? true : false);
		return rval;
	}

}
