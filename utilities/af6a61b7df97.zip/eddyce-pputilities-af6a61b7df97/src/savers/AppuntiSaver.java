package savers;

import it.portaportese.utils.DBWrapper;

import java.sql.SQLException;
import java.util.HashSet;


public class AppuntiSaver {
	DBWrapper dm;
    private String mutex = "";
    
	public AppuntiSaver(DBWrapper indm) {
		dm=indm;
	}
	
	public boolean save(long f, int codutente) {
		boolean rval=false;
		try {
	        String QOut="INSERT INTO annunciosalvato (" +
									"codutente, " +
	                                "oid " +
								") " +
								"VALUES (" + 
									 		codutente + ", " +								
											f +
								") ";
	
			dm.setSql(QOut);
			rval=(dm.executeSql() > 0 ? true : false);
		} catch (Exception e) { }
		return rval;
	}
	    
    public HashSet<Long> loadTutti(int codutente) throws SQLException {
    	HashSet<Long> as = new HashSet<Long> ();
		String Q="SELECT *,oid FROM annunciosalvato WHERE codutente=" + codutente;
		dm.getList(Q);
		
		while (dm.rsNext()) {
			as.add(dm.rsGetLong("oid"));
		}
		dm.rsClose();
		return as;
    }
    
	public boolean cancella(long quale, int codutente) throws SQLException {
        boolean rval=false;
        
        synchronized(mutex) {
            String QOut="delete from annunciosalvato WHERE codutente=" + codutente + " AND oid = " + quale;

            dm.setSql(QOut);
            rval=(dm.executeSql() > 0 ? true : false);
        }
        return rval;
	}

	public boolean cancellaTutti(int codutente) throws SQLException {
        boolean rval=false;
        
        synchronized(mutex) {
            String QOut="delete from annunciosalvato WHERE codutente=" + codutente;

            dm.setSql(QOut);
            rval=(dm.executeSql() > 0 ? true : false);
        }
        return rval;
	}
}