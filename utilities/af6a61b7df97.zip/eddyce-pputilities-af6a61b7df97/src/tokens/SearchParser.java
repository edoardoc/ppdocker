package tokens;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class SearchParser {

        public static void main(String[] args) {
                Hashtable cword = new Hashtable(); 

                InputStreamReader sr = new InputStreamReader(System.in);
                BufferedReader br = new BufferedReader(sr);

                while (true) {
                        String line;
                        try {
                                line = br.readLine();
                        } catch (IOException e) {
                                break;
                        }

                        if (line == null || line.equals(""))
                                break;

                        // da qui in poi ho la linea
                        String parole = "";
                        String tag = "searchglobal=";
                        int id1 = line.indexOf(tag) + tag.length();
                        String secondaparte = line.substring(id1);

                        try {
                                parole = secondaparte.substring(0, secondaparte.indexOf("HTTP"));
                        } catch (RuntimeException h) {
                                System.out.println("ERRORE linea \"" + line + "\"");
                        }

                        try {
                                parole = parole.substring(0, parole.indexOf('&'));
                        } catch (RuntimeException e) {
                        }
                        parole = parole.trim().toLowerCase();

                        StringTokenizer pp = new StringTokenizer(parole, "+");
                        while (pp.hasMoreTokens()) {
                                String parola = pp.nextToken();
                                if (cword.containsKey(parola)) {
                                        int value = Integer.valueOf(cword.get(parola).toString()).intValue();
                                        cword.put(parola, new Integer(value +1));
                                } else {
                                        // prima volta
                                        cword.put(parola, new Integer(1));
                                }
                        }

                }

                Enumeration cw = cword.keys();

                while (cw.hasMoreElements()) {
                        String chiave = cw.nextElement().toString();
                        System.out.println(cword.get(chiave) +  " : " + chiave);
                }
        }
}

