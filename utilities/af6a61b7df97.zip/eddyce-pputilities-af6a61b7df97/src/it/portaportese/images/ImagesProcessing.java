package it.portaportese.images;

import java.awt.Transparency;
import java.awt.color.ColorSpace;
import java.awt.color.ICC_ColorSpace;
import java.awt.color.ICC_Profile;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ByteLookupTable;
import java.awt.image.ColorConvertOp;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.LookupOp;
import java.awt.image.LookupTable;
import java.awt.image.WritableRaster;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGDecodeParam;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

import it.portaportese.utils.logging.Syslog;

public class ImagesProcessing {

	public void setResizedImage(InputStream is, int rx, int ry, OutputStream os) {
		BufferedImage outImage = resizeImage(is, rx, ry, false);
		imageEncode(outImage, os, 100);
	}
	/*
	 * versione che scarica l'immagine dal db e la ingrandisce se necessario
	 */
	public void setResizedImageandzoom(InputStream is, int rx, int ry, OutputStream os) {
		BufferedImage outImage = resizeImage(is, rx, ry, true);
		imageEncode(outImage, os, 100);
	}
	
	/* 
	 * prendo l'immagine cosi' come e', senza resize
	 */
	public void setImage(InputStream is, OutputStream os) {
		JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(is);
		BufferedImage outImage = null;
		try {
			outImage = decoder.decodeAsBufferedImage();
			is.close();
		} catch (Exception e) {
		}
		imageEncode(outImage, os, 100);
	}
	
	public void imageEncode(BufferedImage outImage, OutputStream os, int quality) {
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);
		
		// questa parte serve per dire che l'immagine non deve esere compressa
		com.sun.image.codec.jpeg.JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(outImage);
		quality = Math.max(0, Math.min(quality, 100));
		param.setQuality((float) quality / 100.0f, false);
		encoder.setJPEGEncodeParam(param);
		
		try {
			encoder.encode(outImage);
		} catch (Exception e) {
			Syslog.write("ENCODER IMMAGINI: Caricamento multiplo, " + e.getMessage());
		}
	}

	public void setResizedImageAndConvertToCMYK(InputStream is, int rx, int ry, OutputStream os, String localwebinfpath) throws IOException {
		BufferedImage rgbImage = resizeImage(is, rx, ry, false);

		// Create a CMYK Color Space from cmykProfile
		ICC_Profile p = ICC_Profile.getInstance(new FileInputStream(localwebinfpath + "USWebCoatedSWOP.icc"));

		ColorSpace cmykCS = new ICC_ColorSpace(p);

		// ColorConvert rgbImage to CMYK
		ColorSpace rgbCS = rgbImage.getColorModel().getColorSpace();
		ColorConvertOp rgbToCmyk = new ColorConvertOp(rgbCS, cmykCS, null);

		// Create a ColorModel for destination CMYK image
		ColorModel cmykModel = new ComponentColorModel(cmykCS, new int[]{8, 8, 8, 8}, // 8 bits for each C, M, Y, K
				false, true, // No alpha
				Transparency.OPAQUE, DataBuffer.TYPE_BYTE);
		
		WritableRaster cmykRaster = cmykModel.createCompatibleWritableRaster(rgbImage.getWidth(), rgbImage.getHeight());

		// Convert to CMYK now
		rgbToCmyk.filter(rgbImage.getRaster(), cmykRaster);

		// Invert components (era opzionale)
		byte swap[] = new byte[256];
		for (int i = 0; i < swap.length; i++) {
			swap[i] = (byte) (255 - i);
		}
		LookupTable lookup = new ByteLookupTable(0, new byte[][]{swap, swap, swap, swap});
		LookupOp luop = new LookupOp(lookup, null);
		cmykRaster = luop.filter(cmykRaster, cmykRaster.createCompatibleWritableRaster());

		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);

		// questa parte serve per dire che l'immagine non deve esere compressa
		JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(cmykRaster, JPEGDecodeParam.COLOR_ID_CMYK);

		int quality = 100;
		quality = Math.max(0, Math.min(quality, 100));
		param.setQuality((float) quality / 100.0f, false);
		encoder.setJPEGEncodeParam(param);
		encoder.encode(cmykRaster);
	}

    /* 
     * controlla la largezza di una immagine (blob) facendo meno cose possibili
     * 
     * restituisce true se l'immagine e' piu' larga di larghezza minima 
     */
    public boolean largerThan(InputStream is, int larghezzaminima) {
        JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(is);
        BufferedImage origImage = null;
        try {
            origImage = decoder.decodeAsBufferedImage();
            is.close();
            
            int origHeight = origImage.getHeight(null);
            int origWidth = origImage.getWidth(null);
            return origWidth >= larghezzaminima;
            
        } catch (Exception e) {
            Syslog.write("largerThan exception: " + e.getMessage());
            return false;
        }
    }
 
    /*
     * ridimensiona le immagini a 350 x 262
     * se ingrandisci==true allora deve anche fare il resize in piu' 
     */
	private BufferedImage resizeImage(InputStream is, int rx, int ry, boolean ingrandisci) {
		JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(is);
		BufferedImage origImage = null;
		try {
			origImage = decoder.decodeAsBufferedImage();
			is.close();
            
            int origHeight = origImage.getHeight(null);
            int origWidth = origImage.getWidth(null);

            double maxHeight = 0;
            double maxWidth = 0;

            int scaledW = 0;
            int scaledH = 0;
            double scale = 1;
            
            // immagine piu' alta che larga
            maxHeight = ingrandisci ? ry : (origHeight > ry ? ry : origHeight);
            double scaleX = (double) maxHeight / (double) origHeight;
            
            // immagine piu' larga che alta
            maxWidth = ingrandisci ? rx : (origWidth > rx ? rx : origWidth);
            double scaleY = (double) maxWidth / (double) origWidth;
            
            // la scala piu' piccola e' quella su cui devo ridimensionare!
            scale = Math.min(scaleX, scaleY);
            
            
            // IN QUESTA FASE GLI DEVO DARE DUE SCALE IDENTICHE
            // ALTRIMENTI DISTORCE!
            scaledW = (int) Math.round((scale * origWidth));
            scaledH = (int) Math.round((scale * origHeight));

            BufferedImage outImage = new BufferedImage(scaledW, scaledH, BufferedImage.TYPE_INT_RGB);
            AffineTransform tx = new AffineTransform();
            tx.scale(scale, scale);
            AffineTransformOp af = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
            af.filter(origImage, outImage);
            return outImage;
            
		} catch (Exception e) {
            Syslog.write("resizeImage exception: " + e.getMessage());
            return null;
		}
	}
	
	public ByteArrayOutputStream getResizedImage(InputStream is, int rx, int ry) throws IOException {
		BufferedImage outImage = resizeImage(is, rx, ry, false);
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);
		encoder.encode(outImage);
		return os;
	}	
}
	