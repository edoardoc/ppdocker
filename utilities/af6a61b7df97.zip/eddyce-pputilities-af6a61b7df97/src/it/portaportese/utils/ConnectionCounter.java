/*
 * ConnectionCounter.java it.portaportese.utils - PPLIBS Created on 16-nov-2005 
 *
 */
package it.portaportese.utils;

import it.portaportese.utils.logging.Syslog;

public class ConnectionCounter {
    int numconn;
    /*
    int querydbpp=0;
    long msdbpp=0;
    */
    
    public ConnectionCounter() {
        super();
        numconn=0;
    }
    
    public void open() {
        numconn++;
    }
    public void close() {
        numconn--;
    }

    public int getNumconn() {
        return numconn;
    }
    
}
