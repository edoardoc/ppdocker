package it.portaportese.utils;

import it.portaportese.utils.logging.Syslog;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;

import gestione.utils;

public class DBWrapper {
	// Instance variables:
	private String sql;
	private String result = "";
	private ResultSet rs = null;
	private String message = "";
	private Connection con = null;
	private Statement stmt = null;
	private static final int STARTS_WITH_LEN = 40;
    private ConnectionCounter cc = null; 
    private boolean ConnectionCounterAvailable = true;
    private DatabaseMetaData databaseMetaData  = null;   

	public DBWrapper(Connection inCon) throws SQLException {
		con = inCon;
		stmt = con.createStatement();
		result = "Connected to: " + con.getClass().getName();
		message = "Successfully connected to database.";
		databaseMetaData = con.getMetaData(); 		
		// Syslog.write("CONNESSIONE... " + databaseMetaData.getURL());
        
        // DA QUI DEVO FARE IL BIND CON JNDI  PER TRASMETTERE VALORI ALL'ESTERNO
        InitialContext ctx;
        try {
            ctx = new InitialContext();
            cc = (ConnectionCounter) ctx.lookup("CONNCOUNTER");
        } catch (Exception e) { 
        	ConnectionCounterAvailable = false;
        }
        if (ConnectionCounterAvailable) 
        	cc.open();
	}

	public void closeDB() throws SQLException {
        if (con != null) {
            if (ConnectionCounterAvailable) 
            	cc.open();			
            stmt = null;
			con.close();
			con=null;
            
			//Syslog.write(" ...CHIUSA!");
		}
	}
	
	public void getList(String str, float seed) throws SQLException {
		stmt.executeQuery("select setseed(" + seed + ");");
		getList(str);
	}

	public void getList(String str) throws SQLException {
		setSql(str);
		String l = "Executed query: " + sql;
		long starttimer = System.currentTimeMillis();
		rs = stmt.executeQuery(sql);
		long stoptimer = System.currentTimeMillis();
        verificaT(starttimer, stoptimer);
		logMessage(l + "... Recordset ready in " + (stoptimer - starttimer) + "ms");
	}

    private void verificaT(long starttimer, long stoptimer) throws SQLException {
        long tt=(stoptimer - starttimer);
        
        if (tt > 7000) {
            Syslog.write("QUERY LENTA " + tt/1000 + "sec URL: " + databaseMetaData.getURL() + " QUERY: " + sql);
        } else if (utils.isDebugMode() || utils.isDebugModeLight()) {
            // Syslog.write("[***] getList ESEGUITA QUERY: [" + sql + "]");
        }
    }
    
	public String getMessage() {
		return message;
	}

	public String getResult() {
		return result;
	}
	public String getSql() {
		return sql;
	}

	public void reset() {
		sql = "";
		result = "";
		message = "";
	}
	public void rsClose() throws SQLException {
		if (con != null) {
			rs.close();
		}
	}

	public boolean rsGetBoolean(String field) throws SQLException {
		// SQL TYPES: BIT
		try {
			return rs.getBoolean(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetBoolean campo " + field + " err " + e.getMessage());
		}
		return false;
	}

	public byte rsGetByte(String field) {
		// SQL TYPES: TINYINT
		try {
			return rs.getByte(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("getByte campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public java.sql.Date rsGetDate(String field) {
		// SQL TYPES: DATE
		try {
			if (rs.getDate(field) != null) {
				return rs.getDate(field);
			}
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetDate campo " + field + " err " + e.getMessage());
		}
		return new java.sql.Date(0);
	}

	public double rsGetDouble(String field) {
		// SQL TYPES: FLOAT, DOUBLE
		try {
			return rs.getDouble(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("getDouble campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public float rsGetFloat(String field) {
		// SQL TYPES: REAL
		try {
			return rs.getFloat(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("getFloat campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public Blob rsGetBlob(String field) {
		// SQL TYPES: REAL
		try {
			return rs.getBlob(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetBlob campo " + field + " err " + e.getMessage());
		}
		return null;
	}
	
	public int rsGetInt(String field) {
		// SQL TYPES: INTEGER
		try {
			return rs.getInt(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetInt campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public long rsGetLong(String field) {
		// SQL TYPES: BIGINT
		try {
			return rs.getLong(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("getLong campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public short rsGetShort(String field) {
		// SQL TYPES: SMALLINT
		try {
			return rs.getShort(field);
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("getShort campo " + field + " err " + e.getMessage());
		}
		return 0;
	}

	public String rsGetString(String field) {
		// SQL TYPES: CHAR, VARCHAR, LONGVARCHAR
		try {
			if (rs.getString(field) != null) {
				return rs.getString(field).trim();
			}
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetString campo " + field + " err " + e.getMessage());
		}
		return "";
	}

	public java.sql.Time rsGetTime(String field) {
		// SQL TYPES: TIME
		
		try {
			if (rs.getTime(field) != null) {
				return rs.getTime(field);
			}
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetTime campo " + field + " err " + e.getMessage());
		}
		return new java.sql.Time(0);
	}

	public java.sql.Timestamp rsGetTimestamp(String field) {
		// SQL TYPES: TIMESTAMP
		try {
			if (rs.getTimestamp(field) != null) {
				return rs.getTimestamp(field);
			}
		} catch (SQLException e) {
			if (utils.isDebugMode())
				Syslog.write("rsGetTimestamp campo " + field + " err " + e.getMessage());
		}
		return new java.sql.Timestamp(0);
	}

	public boolean rsNext() throws SQLException {
		if (con != null) {
			return rs.next();
		}
		return false;
	}

	public boolean rsPrevious() throws SQLException {
		if (con != null) {
			return rs.previous();
		}
		return false;
	}

	public void setSql(String str) {
		sql = str;
	}

	public int executeSql() throws SQLException {
		int retval = -1;
		if (con == null || stmt == null) {
			logMessage("Please connect to a database.");
			return retval;
		}
		int len = sql.length();
		if (len == 0) {
			logMessage("SQL statement is empty.");
			return retval;
		}
		if (len < 6) {
			logMessage("SQL statement is invalid.");
			return retval;
		}
		String keyword = sql.substring(0, 6);
		int startLength = (len < STARTS_WITH_LEN) ? len : STARTS_WITH_LEN;
		String cmdStart = sql.substring(0, startLength);
		if (keyword.equalsIgnoreCase("select")) {
            long starttimer = System.currentTimeMillis();
                ResultSet rs = stmt.executeQuery(sql);
            long stoptimer = System.currentTimeMillis();
            verificaT(starttimer, stoptimer);

			rs.close();
			logMessage("Executed query: " + cmdStart + "...");
		} else if (
			keyword.equalsIgnoreCase("update")
				|| keyword.equalsIgnoreCase("insert")
				|| keyword.equalsIgnoreCase("delete")) {

			// ABILITA SOLO UPDATE CON TRANSAZIONI
			//con.setAutoCommit(false);
            
            
            long starttimer = System.currentTimeMillis();
                int result = stmt.executeUpdate(sql);
                //con.commit(); // COMMIT CHANGES
                retval = result;
            long stoptimer = System.currentTimeMillis();
            verificaT(starttimer, stoptimer);
            
            
            
			this.result = "Executed update: " + sql + " ... with result: " + result;
			logMessage(this.result);
		} else {
			// ABILITA SOLO UPDATE CON TRANSAZIONI
            long starttimer = System.currentTimeMillis();
                retval = (stmt.execute(sql) == true ? 1 : 0);
            long stoptimer = System.currentTimeMillis();
            verificaT(starttimer, stoptimer);
			
            //con.setAutoCommit(false);
			result = "Executed: " + cmdStart + "...";
			logMessage(result);
		}
		return retval;
	}
	public BigDecimal rsGetBigDecimal(String field) throws SQLException {
		// SQL TYPES: NUMERIC, DECIMAL
		if (rs.getBigDecimal(field) != null) {
			return rs.getBigDecimal(field);
		}
		return new BigDecimal(0);
	}

	private void errorMessage(String msg) {
		handleMessage(msg + "\n-->SQL:" + sql, true);
	}
	private void handleMessage(String msg, boolean error) {
		if (error || !utils.isProduction() || utils.isDebugMode() || utils.isDebugModeLight())
			Syslog.write(msg);
		message = msg;
	}
	private void logMessage(String msg) {
		handleMessage(msg, false);
	}
	protected void finalize() throws Throwable {
		super.finalize();
        if (con != null) {
            Syslog.write("WARNING: CHIUDERE DBWRAPPER CON FINALIZE NON E' EFFICIENTE!");
            Syslog.write("         " + sql);
        }
        
        closeDB();
	}
}