package it.portaportese.utils;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import gestione.utils;
import it.portaportese.system.Impostazioni;
import it.portaportese.utils.logging.Syslog;

public abstract class functions {
static public boolean booleanParm(String parametro) {
	boolean ret = (parametro == null ? false : parametro.toLowerCase().equals("true"));
	//Syslog.write("booleanParm " + parametro + " ritorno " + ret);
	return ret;
}


public static Document loadXMLFromString(String xml) throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    InputSource is = new InputSource(new StringReader(xml));
    return builder.parse(is);
}


static public long getMaxValue(DBWrapper dm, String tablename, String fieldname) throws SQLException {
	long value = 0;

	dm.getList("SELECT " + fieldname +" AS ValoreMassimo FROM " + tablename +" ORDER BY " + fieldname +" DESC LIMIT 1;");
	if (dm.rsNext())
		value=dm.rsGetLong("ValoreMassimo");
	dm.rsClose();
	return value;
}
static public long getMinValue(DBWrapper dm, String tablename, String fieldname) throws SQLException {
	long value = 0;
	
	dm.getList("SELECT " + fieldname +" AS ValoreMinimo FROM " + tablename +" ORDER BY " + fieldname +" LIMIT 1;");
	if (dm.rsNext())
		value=dm.rsGetLong("ValoreMinimo");
	dm.rsClose();
	return value;
}
static public int intParm(String parametro) {
	try {
	  return (parametro == null) ? 0 : new Integer(parametro).intValue();
	}	catch (Exception ignored) { return 0; }
}
static public int intParmparse(String parametro) {
	try {
	  return (parametro == null) ? 0 : Integer.parseInt(parametro);
	}	catch (Exception ignored) { return 0; }
}


static public long longParm(String parametro) {
	try {
		return (parametro == null) ? 0 : new Long(parametro).longValue();
	} catch (Exception ignored) {
		if (utils.isDebugMode()) 
			Syslog.write("WARNING longParm 0 per " + parametro );
		return 0;
	}
}

static public String pathRecur(String path, String titolo, String sKC, String delimiter) {
	StringTokenizer st = new StringTokenizer(path, delimiter);
	String sout="";
	boolean first=true, trovato=false;
	
	while((st.hasMoreTokens()) && (!trovato)) {
		String tit=st.nextToken();
		String tk=st.nextToken();
		if (tk.equals(sKC)) {
			trovato=true;
			break;
		} else {			
			if (first) {
				sout = tit + delimiter + tk;	
				first=false;
			} else {
	    		sout = sout + delimiter + tit + delimiter + tk;
			}
		}
	}
	if (first)
		sout = titolo + delimiter + sKC;
	else
		sout = sout + delimiter + titolo + delimiter + sKC;
	
	return sout;
}
static public String readFile(String nome) {
	String ret="";
	try {
		FileInputStream inStream = new FileInputStream(nome);
		int inBytes = inStream.available();
		byte inBuf[] = new byte[inBytes];
		inStream.read(inBuf);
		ret=new String(inBuf);
		inStream.close();
	} catch (Exception e) {
		if (utils.isDebugMode()) 
			Syslog.write("Errore apertura del file " + nome + " Messaggio: " + e.getMessage());
	}
	return ret;
}
static public boolean writeFile(String nome, String Contenuto) {
	boolean ret;
	try {
		FileOutputStream outStream = new FileOutputStream(nome);
		outStream.write(Contenuto.getBytes());
		outStream.close();
		ret=true;
	} catch (Exception e) {
		if (utils.isDebugMode()) 
			Syslog.write("Errore scrittura del file " + nome + " Messaggio: " + e.getMessage());
		ret=false;
	}
	return ret;
}
static public String sqlDate(String dbformat) {
	SimpleDateFormat format = new SimpleDateFormat(dbformat);
	Calendar cal = Calendar.getInstance();
	java.util.Date now = new java.util.Date();
	cal.setTime(now);
	String datareg = format.format(cal.getTime());
	return datareg;
}
static public String stringParm(String parametro) {
  return (parametro == null) ? "" : parametro;
}
static public String dateFormatter(java.util.Date now, String dbformat) {
	if (now != null) {
		SimpleDateFormat format = new SimpleDateFormat(dbformat);
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		String datareg = format.format(cal.getTime());
		return datareg;
	} else
		return "";
}

static public String dateFormatterdb(java.util.Date now, String dbformat) {
	if (now != null) {
		SimpleDateFormat format = new SimpleDateFormat(dbformat);
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		return Impostazioni.DBSTRDEL + format.format(cal.getTime()) + Impostazioni.DBSTRDEL;
	} else 
		return "null";
}

static public String dateFormatter(java.util.Date now, String dbformat, String twoloc) {
	if (now != null) {
		Locale l;
		if (twoloc.equals("it"))
			l = Locale.ITALY;
		else
			l = Locale.ENGLISH;
		
		SimpleDateFormat format = new SimpleDateFormat(dbformat, l);
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		String datareg = format.format(cal.getTime());
		return datareg;
	} else
		return "";
}

static public double doubleParm(String parametro) {
	try {
		return (parametro == null) ? 0 : new Double(parametro).doubleValue();
	} catch (Exception ignored) {
		return 0;
	}
}

static public int getRecordCount(DBWrapper dm, String tablename) throws SQLException {
	int value = 0;
	dm.getList("SELECT Count(*) AS conteggio FROM " + tablename +";");
	while (dm.rsNext())
		value=dm.rsGetInt("conteggio");
	dm.rsClose();
	return value;
}

static public int getRecordCount(DBWrapper dm, String tablename, String where) throws SQLException {
	int value = 0;

	dm.getList("SELECT Count(*) AS conteggio FROM " + tablename +" WHERE " + where);
	while (dm.rsNext())
		value=dm.rsGetInt("conteggio");
	dm.rsClose();
	return value;
}
}