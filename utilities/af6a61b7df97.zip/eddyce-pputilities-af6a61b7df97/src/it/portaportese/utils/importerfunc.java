/*
 * Ricerca.java gestione.rubriche - PPJR Created on 28-lug-2006 
 *
 */
package it.portaportese.utils;

import gestione.utils;
import it.portaportese.utils.logging.Syslog;

public abstract class importerfunc {

	public static boolean bfield(String bbuf, int start, int stop) {
		return (field(bbuf, start, stop).equals("X"));
	}

	public static String field(String bbuf, int start, int stop) {
		if (utils.isDebugMode()) {
			Syslog.write("estraggo da " + start + " a " + stop);
			Syslog.write("field: " + bbuf.substring(start, stop));
			Syslog.write("\nLEN: " + bbuf.substring(start, stop).length());
		}
		String dat = "";

		try {
			dat = bbuf.substring(start, stop).trim();
		} catch (Exception e) {
			Syslog.write("ERRORE FIELD da " + start + " a " + stop, e);
		}

		return dat;
	}

}