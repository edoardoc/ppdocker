/*
 * Created on 21-dic-2003
 *
 */
package it.portaportese.utils;

import java.util.Random;

/**
 * @author Edoardo
 */
public class Pprand {
	Random r = null;

	public Pprand() {
		r = new Random();
	}

	public int getRandomInRange(int lo, int hi) {
		if (lo > hi) {
			throw new IllegalArgumentException("lo > hi");
		}

		// get the range, casting to long to
		// avoid overflow problems
		long range = (long) hi - (long) lo + 1;

		// compute a fraction of the range, 0
		// <= frac < range
		long frac = (long) (range * r.nextDouble());

		// add the fraction to the lo value and
		// return the sum

		return (int) (frac + lo);
	}
}
