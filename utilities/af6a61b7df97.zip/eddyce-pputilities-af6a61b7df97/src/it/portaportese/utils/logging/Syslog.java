package it.portaportese.utils.logging;
import it.portaportese.utils.Strings;
import it.portaportese.utils.functions;


public abstract class Syslog {
	private static final String WARNING_NO_SC = "WARNING NO SC ";
	private static String prefix = "PortaPortese";
	
	public static void write(String msg) {
		StringBuffer t = new StringBuffer(prefix + "[");
		t.append(functions.sqlDate("ss.SSS") + "] " + msg);
		t.append(Strings.chars(' ', 70 - t.length()));
		System.err.println(WARNING_NO_SC + t.toString());
	}
	
	public static void write(String msg, Throwable th) {
		StringBuffer t = new StringBuffer(prefix + "[");
		t.append(functions.sqlDate("ss.SSS") + "] " + msg);
		t.append(Strings.chars(' ', 70 - t.length()));
		System.err.println(WARNING_NO_SC + t.toString() + " Throwable " + th.getMessage());
	}
	
}
