package it.portaportese.system.serialize;

public interface Serex {
	// e' solo un tag (per ora)

}
