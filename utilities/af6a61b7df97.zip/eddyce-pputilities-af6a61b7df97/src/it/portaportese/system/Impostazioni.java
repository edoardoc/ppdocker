package it.portaportese.system;

/**
 * Questa e' una classe di impostazioni per questo progetto
 */

public final class Impostazioni {
  public final static String DBSTRDEL = "\'"; // delimitatore stringa nel db

  public final static String DBVALUES = "VALUES (";

  public final static String DBVALUESCLOSE = ") ";

  public final static String USERLABEL = "ppuser";
  public static final String TOKENLABEL = "pptoken";
  public final static String RUBRICALABEL = "pprubrica";
  public final static String PRLABEL = "ppprop";

  public final static int MINIMALUNGHEZZATESTORICERCA = 1;
  public final static int MASSIMALUNGHEZZATESTORICERCA = 40;

  public final static int MINIMALUNGHEZZATESTORICERCAPARZIALE = 3;

  public final static String DATE2SAVEFORMAT = "MM/dd/yyyy HH:mm:ss";
  public final static String DATE2READFORMAT = "yyyy-MM-dd HH:mm:ss";

  public static final String RALABEL = "paginaripetiannunci";
  public static final String PFLABEL = "paginaformato";

  public static final String RPLABEL = "paginaripristinaannuncio";;

  public static final int MAXPAGINEVISUALIZZABILI = 9000; // da 0 a 9

  public static final int MAXAPAGINATOT = 11100; // era 110 x 10 pag


  public static final String TXTTITOLO = "Porta Portese annunci gratuiti - il primo portale di annunci per Roma e Lazio";

  public static final String PBINGONAME = "bingovalue";;

  // questo serve alla ricerca
  public static final int MAXFOTO = 12;
  public static final int RANKINGFOTO = 10;
  public static final int RANKINGLIVE = 7000;

  public static final String FBAPPID = "1384867891827905";
  public static final String FBCBURL = "/fbredirect/";
  public static final String TOSCANURL = "http://www.tplat.it/fromext/portaportese/PortaporteseSpecifica";
  
  public static final String FBCLIENTSECRET = "b7cc62872a961ef54e63656174b037f5";
  public static final String EXTRNUSERLBL = "externaluser";

  public static final String WHEREESPORTA = "(ke = 0 AND (NF = 'R' OR attributi='AI' OR (attributi like 'A%' AND (tipoannuncio <> 'NO' AND tipoannuncio <> 'FG' AND tipoannuncio <> 'PU'))))";

}
