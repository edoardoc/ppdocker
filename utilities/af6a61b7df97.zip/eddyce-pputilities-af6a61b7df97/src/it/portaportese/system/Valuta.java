/*
 * Valuta.java it.portaportese.system - PPJR Created on Jul 8, 2005 
 *
 */
package it.portaportese.system;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * @author root */

public class Valuta implements Serializable {
	double valore=0;
	boolean Europrefisso = true;
	boolean Stampanientezero = false;
	
	public Valuta(double valore) {
		this.valore=valore;
	}

	public Valuta(String valore) {
		try {
			this.valore = Double.parseDouble(valore);
		} catch (Exception e) {}
	}

	public String toString() {
		if (!(Stampanientezero && valore == 0)) {
			
			DecimalFormat df=null;
			try {
				df = (DecimalFormat) NumberFormat.getInstance(java.util.Locale.ITALY);
			} 
			catch (Exception e) { }
			df.applyPattern("###,###,###,##0.00");
			
			if (Europrefisso) 
				return "&euro; " + df.format(valore);
			else
				return df.format(valore) + " &euro;";
		} else 
			return "";
	}
	
	public double getValore() {
		return valore;
	}

	public void setValore(double valore) {
		this.valore = valore;
	}

    public String toStringnohtml() {
		if (!(Stampanientezero && valore == 0)) {
	    	
	        // TOLTO IL SIMBOLO EURO
	        
	        DecimalFormat df=null;
	        try {
	            df = (DecimalFormat) NumberFormat.getCurrencyInstance(java.util.Locale.ITALY);
	        } 
	        catch (Exception e) { }
	        df.applyPattern("###,###,###,##0.00");
	        return df.format(valore);
		} else 
			return "";
    }

	public boolean isEuroprefisso() {
		return Europrefisso;
	}

	public void setEuroprefisso(boolean europrefisso) {
		Europrefisso = europrefisso;
	}

	public boolean isStampanientezero() {
		return Stampanientezero;
	}

	public void setStampanientezero(boolean stampanientezero) {
		Stampanientezero = stampanientezero;
	}
}