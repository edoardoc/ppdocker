package it.portaportese.system;

import gestione.utils;
import gestione.rubriche.Listarubriche;
import it.portaportese.system.serialize.Serex;

import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

/**
 * @author Edoardo
 * 
 * questo e' l'oggetto che mantiene i valori precalcolati su disco tra una
 * partenza e l'altra
 * 
 */
public class PCValues implements Serex, Serializable {

	private static final long serialVersionUID = 3257565126709491007L;
	private List uscite;
	private List lksottorubrica;
	private List lksottorubricamodello;
	private List lkalimentazioneauto;
	Hashtable<Integer, Map> htmodello;
	private int maxuscita;
	private int uscitaprecedente;
	private int annuncionline;
	private int maxkugest;
	private int ultimoku;
	private int uscitaultimoku;
	private Date datauscitaultimoku;
	private Date datauscitapenultimoku;
	private Listarubriche listarubriche;
    
	private List formati;
    private Hashtable hashformati;	// forse potrebbe sostituire la lista
	private Hashtable<String, String> htfiltroricerca; 
	private Hashtable<String, String> htnomedescrizionemodello;
	private Hashtable<Integer, Map> htlogoutente;
	private Hashtable<Integer, String> htgestimmannuncio;
	private Hashtable<Integer, String> htgestimmannuncioutente;
	
	private List tabellauscita;
    
	public void setUscite(List list) {
		uscite = list;
	}

	public void setLksottorubricamodello(List lksottorubricamodello) {
		this.lksottorubricamodello = lksottorubricamodello;
	}

	public void setLksottorubrica(List list2) {
		lksottorubrica = list2;
	}

	public void setMaxuscita(int i) {
		maxuscita = i;

	}

	public void setUscitaprecedente(int i) {
		uscitaprecedente = i;

	}

	public void setAnnuncionline(int recordCount) {
		annuncionline = recordCount;

	}
	
    public void setMaxkugest(int maxkugest) {
		this.maxkugest = maxkugest;

	}
    
	public void setUltimoku(int integer) {
		ultimoku = integer;

	}
    
	public void setUscitaultimoku(int uscitaultimoku) {
		this.uscitaultimoku = uscitaultimoku;

	}

	public void setDatauscitaultimoku(Date datauscitaultimoku) {
		this.datauscitaultimoku = datauscitaultimoku;

	}

	public void setDatauscitapenultimoku(Date datauscitapenultimoku) {
		this.datauscitapenultimoku = datauscitapenultimoku;

	}
    
	public int getAnnuncionline() {
		return annuncionline;
	}
	
    public Date getDatauscitapenultimoku() {
		return datauscitapenultimoku;
	}

	public Date getDatauscitaultimoku() {
		return datauscitaultimoku;
	}
    
	public List getLksottorubricamodello() {
		return lksottorubricamodello;
	}

	public List getLksottorubrica() {
		return lksottorubrica;
	}

	public int getMaxkugest() {
		return maxkugest;
	}

	public int getMaxuscita() {
		return maxuscita;
	}
    
	/*
	 * e' stato aggiunto kr in quanto il prossimo ku e' funzione di
	 * formato, rubrica e di status utente (cliente o utente) 
	 * 
	 */
	public int getProssimoku(String formato, int status, int kr) {
        // getProssimoku deve ritornare il primo ku disponibile per il formato scelto
        // in definitiva il campo "prossimoku" della tabella formato senza alcune 
	    // modifiche se non quelle relative ai commerciali (prossimoku/prossimokucliente).
        
        int prossimoku=-1;
        Map colMap;
        String lsf = "";
        for (int i=0; i < formati.size(); i++) {
            colMap = (Map) formati.get(i);
            lsf = utils.m2str(colMap.get("codice")).trim();
            if (formato.equals(lsf)) {
                // ho trovato il formato...
                if (status >= 1) {
                    prossimoku = utils.m2int(colMap.get("prossimokucliente"));
                    // verifico se devo applicare l'anticipo (gruppo a)
            		if (listarubriche.getRubrica(kr).getGruppo().equals("A")) {
            			prossimoku = utils.m2int(colMap.get("prossimokuclientega"));
            		}
                }  else {
                    prossimoku = utils.m2int(colMap.get("prossimoku"));
                    // verifico se devo applicare l'anticipo (gruppo a)
            		if (listarubriche.getRubrica(kr).getGruppo().equals("A")) {
            			prossimoku = utils.m2int(colMap.get("prossimokuga"));
            		}
                }
                break;
            }
        }
	    return prossimoku;
    }
	
	//public int getUltimoku(int status) {
    public int getUltimoku() {
		// EXcondizione x ritardare la chiusura del numero ai commerciali
        // non si puo' usare il ku della tabella formato perche' 
        // quello e' per inserire mentre questo e' per visualizzare.
        
		int attualeku = ultimoku;
		/*
        if (status >= 1) {
			if (!isChiusocommerciali()) {
				attualeku--;
			}
		}
        */
		return attualeku;
	}

	public int getUscitaprecedente() {
		return uscitaprecedente;
	}
	
    public int getUscitaultimoku() {
		return uscitaultimoku;
	}
	
    public List getUscite() {
		return uscite;
	}

	public void setListarubriche(Listarubriche lrbr) {
		listarubriche=lrbr;
	}

	public Listarubriche getListaRubriche() {
		return listarubriche;
	}
    
    public void setFormati(List listc) {
        formati = listc;
    }
    
	public List getFormati() {
		return formati;
	}

    public void setTabellauscita(List listuscita) {
        tabellauscita = listuscita;
    }

    public List getTabellauscita() {
        return tabellauscita;
    }

	public Hashtable getHashformati() {
		return hashformati;
	}

	public void setHashformati(Hashtable hashformati) {
		this.hashformati = hashformati;
	}
	
	public Hashtable<Integer, Map> getHtmodello() {
		return htmodello;
	}

	public void setHtmodello(Hashtable<Integer, Map> htmodello) {
		this.htmodello = htmodello;
	}
    public Hashtable<String, String> getHtfiltroricerca() {
		return htfiltroricerca;
	}

	public void setHtfiltroricerca(Hashtable<String, String> htfiltroricerca) {
		this.htfiltroricerca = htfiltroricerca;
	}

	public void setHtnomeDescrizioneModello(Hashtable<String, String> htnomedescrizionemodello) {
		this.htnomedescrizionemodello = htnomedescrizionemodello;
	}
    public Hashtable<String, String> getHtnomeDescrizioneModello() {
		return htnomedescrizionemodello;
	}

	public void setHtgestimmannuncio(Hashtable<Integer, String> htgimm) {
		this.htgestimmannuncio = htgimm;
	}
    public Hashtable<Integer, String> getHtgestimmannuncio() {
		return this.htgestimmannuncio;
	}

	public void setHtgestimmannuncioutente(Hashtable<Integer, String> htgimmutente) {
		this.htgestimmannuncioutente = htgimmutente;
	}
    public Hashtable<Integer, String> getHtgestimmannuncioutente() {
		return this.htgestimmannuncioutente;
	}

	public Hashtable<Integer, Map> getHtlogoutente() {
		return htlogoutente;
	}

	public void setHtlogoutente(Hashtable<Integer, Map> htlogoutente) {
		this.htlogoutente = htlogoutente;
	}

}