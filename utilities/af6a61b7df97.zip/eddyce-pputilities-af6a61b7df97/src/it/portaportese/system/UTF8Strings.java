package it.portaportese.system;


public abstract class UTF8Strings {

	final static String white = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzàèìòù@0123456789,;.:-_+()°'?!=&%/\"";

	public static String whiteList(String str) {
		StringBuffer buf = new StringBuffer();
		char cs[] = str.toCharArray();
		char c = ' ';
		for (int i = 0; i < cs.length; i++) {
			c = cs[i];
			if (white.indexOf(c) >= 0) {
				// il carattere è nella whitelist, tutto ok
			} else {
				// si tratta di altro
				if (c == '€') {
					c = 'E';
				} else if ((int)c == 160) {
					// unione dell'inizio stringa
				} else {
					c = ' ';
				}

			}
			buf.append(c);
		}
		return new String(buf);
	}
}