package it.portaportese.ui.shared;

import java.io.Serializable;

public class MiniAnnuncioBean implements Serializable{
	private String pubblicaemail = "";
	private String annunciosenzatel = "";
	private String tipo = "o"; // DEFAULT offerta (o)
	private String tipoace = "";
	private int ka = 0;
	private int kaprovenienza = 0;
	private int kr = 0;
	private int kroriginale = 0;
	private int ku = 0;
	private int numerofoto = 0;
	private String telef1 = "";
	private String pref1 = "";
	private String telef2 = "";
	private String pref2 = "";
	private String immoviewer = "";
	private String testo = "";
	private String addinfo = "";
	private String titolo = "";
	private String statoai = "";
	private String tipoannuncio = "NO";
	private String tipoannuncioprecedente = "NO";
	private String descrizionerubrica = "";
	private int selectbox1 = -1;
	private int selectbox2 = -1;
	private int selectbox3 = -1;
	private double latitudine = 0;
	private double longitudine = 0;

	private String tipologia = "";
	private int locali = 0;
	private int postiletto = 0;
	private int m2 = 0;
	private String prezzo = "";
	private String modello = "";
	private int km = 0;
	private int anno = 0;
	private String alimentazione = "";
	
	private boolean attributoadsistantaneo = false;

	public MiniAnnuncioBean() {
	}

	public String getAnnunciosenzatel() {
		return annunciosenzatel;
	}

	public void setAnnunciosenzatel(String annunciosenzatel) {
		this.annunciosenzatel = annunciosenzatel;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getKa() {
		return ka;
	}

	public void setKa(int ka) {
		this.ka = ka;
	}

	public int getKaprovenienza() {
		return kaprovenienza;
	}

	public void setKaprovenienza(int kaprovenienza) {
		this.kaprovenienza = kaprovenienza;
	}

	public int getKr() {
		return kr;
	}

	public void setKr(int kr) {
		this.kr = kr;
	}

	public int getKroriginale() {
		return kroriginale;
	}

	public void setKroriginale(int kroriginale) {
		this.kroriginale = kroriginale;
	}

	public int getKu() {
		return ku;
	}

	public void setKu(int ku) {
		this.ku = ku;
	}

	public int getNumerofoto() {
		return numerofoto;
	}

	public void setNumerofoto(int numerofoto) {
		this.numerofoto = numerofoto;
	}

	public String getTelef1() {
		return telef1;
	}

	public void setTelef1(String telef1) {
		this.telef1 = telef1;
	}

	public String getPref1() {
		return pref1;
	}

	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}

	public String getTelef2() {
		return telef2;
	}

	public void setTelef2(String telef2) {
		this.telef2 = telef2;
	}

	public String getPref2() {
		return pref2;
	}

	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}

	public String getTesto() {
		return testo;
	}

	public void setTesto(String testo) {
		this.testo = testo;
	}

	public String getTipoannuncio() {
		return tipoannuncio;
	}

	public void setTipoannuncio(String tipoannuncio) {
		this.tipoannuncio = tipoannuncio;
	}

	public String getTipoannuncioprecedente() {
		return tipoannuncioprecedente;
	}

	public void setTipoannuncioprecedente(String tipoannuncioprecedente) {
		this.tipoannuncioprecedente = tipoannuncioprecedente;
	}

	public String getDescrizionerubrica() {
		return descrizionerubrica;
	}

	public void setDescrizionerubrica(String descrizionerubrica) {
		this.descrizionerubrica = descrizionerubrica;
	}

	public int getSelectbox1() {
		return selectbox1;
	}

	public void setSelectbox1(int selectbox1) {
		this.selectbox1 = selectbox1;
	}

	public int getSelectbox2() {
		return selectbox2;
	}

	public void setSelectbox2(int selectbox2) {
		this.selectbox2 = selectbox2;
	}

	public int getSelectbox3() {
		return selectbox3;
	}

	public void setSelectbox3(int selectbox3) {
		this.selectbox3 = selectbox3;
	}


	public String getPubblicaemail() {
		return pubblicaemail;
	}


	public void setPubblicaemail(String pubblicaemail) {
		this.pubblicaemail = pubblicaemail;
	}


	public double getLatitudine() {
		return latitudine;
	}


	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}


	public double getLongitudine() {
		return longitudine;
	}


	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}


	public String getTipoace() {
		return tipoace;
	}


	public void setTipoace(String tipoace) {
		this.tipoace = tipoace;
	}


	public void setAttributoadsistantaneo(boolean attributoadsistantaneo) {
		this.attributoadsistantaneo = attributoadsistantaneo;
	}


	public boolean isAttributoadsistantaneo() {
		return attributoadsistantaneo;
	}


	public String getStatoai() {
		return statoai;
	}


	public void setStatoai(String statoai) {
		this.statoai = statoai;
	}

	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public int getLocali() {
		return locali;
	}

	public void setLocali(int locali) {
		this.locali = locali;
	}

	public int getM2() {
		return m2;
	}

	public void setM2(int m2) {
		this.m2 = m2;
	}

	public String getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(String prezzo) {
		this.prezzo = prezzo;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public int getKm() {
		return km;
	}

	public void setKm(int km) {
		this.km = km;
	}

	public int getAnno() {
		return anno;
	}

	public void setAnno(int anno) {
		this.anno = anno;
	}

	public String getAlimentazione() {
		return alimentazione;
	}

	public void setAlimentazione(String alimentazione) {
		this.alimentazione = alimentazione;
	}

	public int getPostiletto() {
		return postiletto;
	}

	public void setPostiletto(int postiletto) {
		this.postiletto = postiletto;
	}

	public String getAddinfo() {
		return addinfo;
	}

	public void setAddinfo(String addinfo) {
		this.addinfo = addinfo;
	}

	public String getImmoviewer() {
		return immoviewer;
	}

	public void setImmoviewer(String immoviewer) {
		this.immoviewer = immoviewer;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
}
