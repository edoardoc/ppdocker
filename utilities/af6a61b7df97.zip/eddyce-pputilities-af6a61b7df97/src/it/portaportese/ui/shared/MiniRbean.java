package it.portaportese.ui.shared;

import java.io.Serializable;

public class MiniRbean implements Serializable {
	private int kr = 0;
	private int krpadre = 0;
	private String descrizione = "";
	private String rubric = "";

	public MiniRbean() {
	}

	public String getDescrizione() {
		return descrizione;
	}

	public int getkr() {
		return kr;
	}

	public int getkrpadre() {
		return krpadre;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setkr(int kr) {
		this.kr = kr;
	}

	public void setkrpadre(int krpadre) {
		this.krpadre = krpadre;
	}

	public String getRubric() {
		return rubric;
	}

	public void setRubric(String rubric) {
		this.rubric = rubric;
	}

}
