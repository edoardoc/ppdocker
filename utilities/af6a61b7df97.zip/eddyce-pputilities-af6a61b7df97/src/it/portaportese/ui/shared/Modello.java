package it.portaportese.ui.shared;

import java.io.Serializable;

public class Modello implements Serializable {
	public Modello(int kr, String nome, String descrizione) {
		super();
		this.kr = kr;
		this.nome = nome;
		this.descrizione = descrizione;
	}

	public Modello() {
		super();
	}

	int kr = 0;
	String nome = "";
	String descrizione = "";

	public int getKr() {
		return kr;
	}

	public void setKr(int kr) {
		this.kr = kr;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
}
