package it.portaportese.ui.shared;

import java.io.Serializable;

public class Tipologia implements Serializable {
	public Tipologia() {
	}

	public Tipologia(String nome, String codice) {
		super();
		this.nome = nome;
		this.codice = codice;
	}

	String nome = "";
	String codice = "";

	public String getCodice() {
		return codice;
	}

	public void setCodice(String codice) {
		this.codice = codice;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
