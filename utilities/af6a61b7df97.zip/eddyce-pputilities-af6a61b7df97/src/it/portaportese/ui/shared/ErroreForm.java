package it.portaportese.ui.shared;

import java.io.Serializable;

public class ErroreForm implements Serializable {
	String dove="";
	String messaggio="";

	public ErroreForm() {
		super();
	}
	
	public ErroreForm(String dove, String messaggio) {
		super();
		this.dove = dove;
		this.messaggio = messaggio;
	}

	public String getMessaggio() {
		return messaggio;
	}

	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}

	@Override
	public String toString() {
		return "ErroreForm [dove=" + dove + ", messaggio=" + messaggio + "]";
	}

	public String getDove() {
		return dove;
	}

	public void setDove(String dove) {
		this.dove = dove;
	}
}
