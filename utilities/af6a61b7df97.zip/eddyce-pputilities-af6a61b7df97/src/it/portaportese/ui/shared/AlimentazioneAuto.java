package it.portaportese.ui.shared;

public abstract class AlimentazioneAuto {
	public static String match(String s) {
		if (s.equals("B"))
			return "Benzina";
		else if (s.equals("D")) 
			return "Diesel";
		else if (s.equals("I")) 
			return "Ibrida/Elettrica";
		else if (s.equals("M")) 
			return "Gpl/Metano";
		else return "N/A";
	}
}
