package it.portaportese.ui.client.common.beans;

import java.io.Serializable;

public class Images implements Serializable {
	private String[] imgs = null;	// essendo un bean non viene serializzato se uso long
	private String url = "";
	
	public Images() {
		super();
	}

	public Images(String[] imgs, String url) {
		super();
		this.imgs = imgs;
		this.url = url;
	}
	
	public String[] getImgs() {
		return imgs;
	}
	
	public void setImgs(String[] imgs) {
		this.imgs = imgs;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String link) {
		this.url = link;
	}
}
