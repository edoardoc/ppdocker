package it.portaportese.ui.client.common.beans;

import java.io.Serializable;

/*
 * Questa e' la classe base di un formato
 */

public class FormatoAnnuncio implements Serializable {
	String codice = "";

	String descrizione = "";

	String spiegazione = "";

	String prezzo = "";
	
	String prezzoaistantanei = "";
	
	String prezzoconaistantanei = "";
	
	String prezzoaistantaneicliente = "";
	
	String prezzoconaistantaneicliente = "";
	
	int prossimoku = 0;
	
	int prossimokucliente = 0;
	
	int prossimokuga = 0;
	
	int prossimokuclientega = 0;
	
	int maxprossimoku = 0;

	private Uscita[] uscite = null;

	public int getMaxprossimoku() {
		return maxprossimoku;
	}

	public void setMaxprossimoku(int maxprossimoku) {
		this.maxprossimoku = maxprossimoku;
	}

	public int getProssimoku() {
		return prossimoku;
	}

	public void setProssimoku(int prossimoku) {
		this.prossimoku = prossimoku;
	}

	public int getProssimokucliente() {
		return prossimokucliente;
	}

	public void setProssimokucliente(int prossimokucliente) {
		this.prossimokucliente = prossimokucliente;
	}

	public FormatoAnnuncio() {
	}

	public String getCodice() {
		return codice;
	}

	public void setCodice(String codice) {
		this.codice = codice;
	}

	public String getDescrizione() {
		return descrizione == null ? "" : descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getPrezzo() {
		return prezzo;
	}
	
	public void setPrezzo(String prezzo) {
		this.prezzo = prezzo;
	}

	public String getSpiegazione() {
		return spiegazione;
	}

	public void setSpiegazione(String spiegazione) {
		this.spiegazione = spiegazione;
	}

	public void setUscite(Uscita[] uscite) {
		this.uscite  = uscite;
	}

	public Uscita[] getUscite() {
		return uscite;
	}

	public int getProssimokuga() {
		return prossimokuga;
	}

	public void setProssimokuga(int prossimokuga) {
		this.prossimokuga = prossimokuga;
	}

	public int getProssimokuclientega() {
		return prossimokuclientega;
	}

	public void setProssimokuclientega(int prossimokuclientega) {
		this.prossimokuclientega = prossimokuclientega;
	}

	public String getPrezzoconaistantanei() {
		return prezzoconaistantanei;
	}

	public void setPrezzoconaistantanei(String prezzoconaistantanei) {
		this.prezzoconaistantanei = prezzoconaistantanei;
	}

	public String getPrezzoaistantanei() {
		return prezzoaistantanei;
	}
	public void setPrezzoaistantanei(String prezzoaistantanei) {
		this.prezzoaistantanei = prezzoaistantanei;
	}

	public String getPrezzoaistantaneicliente() {
		return prezzoaistantaneicliente;
	}

	public void setPrezzoaistantaneicliente(String prezzoaistantaneicliente) {
		this.prezzoaistantaneicliente = prezzoaistantaneicliente;
	}

	public String getPrezzoconaistantaneicliente() {
		return prezzoconaistantaneicliente;
	}

	public void setPrezzoconaistantaneicliente(String prezzoconaistantaneicliente) {
		this.prezzoconaistantaneicliente = prezzoconaistantaneicliente;
	}
}