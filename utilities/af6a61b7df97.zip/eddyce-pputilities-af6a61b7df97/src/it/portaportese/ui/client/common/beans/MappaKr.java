package it.portaportese.ui.client.common.beans;

public class MappaKr {

}
