package it.portaportese.ui.client.common.beans;

import java.io.Serializable;

public class Risposta implements Serializable {
	String msg = "";
	String whereto = "";

	public Risposta(String msg, String whereto) {
		super();
		this.msg = msg;
		this.whereto = whereto;
	}

	public Risposta() {
		super();
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getWhereto() {
		return whereto;
	}

	public void setWhereto(String whereto) {
		this.whereto = whereto;
	}

}
