package it.portaportese.ui.client.common.beans;

import java.io.Serializable;

public class Uscita implements Serializable {
	int ku = 0;
	String datapp = "";

	public Uscita(int ku, String datapp) {
		super();
		this.ku = ku;
		this.datapp = datapp;
	}

	public Uscita() {
		super();
	}
	
	public String getDatapp() {
		return datapp;
	}

	public void setDatapp(String datapp) {
		this.datapp = datapp;
	}

	public int getKu() {
		return ku;
	}

	public void setKu(int ku) {
		this.ku = ku;
	}
}
