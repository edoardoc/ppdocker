package flusso.xml;

public class Contatti {
	String Telef;
	String Pref;
}
