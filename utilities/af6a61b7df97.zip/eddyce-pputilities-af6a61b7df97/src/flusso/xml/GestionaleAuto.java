package flusso.xml;

import flusso.xml.utils.xmlut;
import forms.AnnuncioBean;
import it.portaportese.utils.DBWrapper;
import it.portaportese.utils.Strings;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.dbcp.BasicDataSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import savers.AnnuncioSaver;

/*

drop TABLE gestautoutente ;
CREATE TABLE gestautoutente (   codutente integer NOT NULL,   idanagrafica integer NOT NULL,   CONSTRAINT gautoutente_pkey PRIMARY KEY (codutente, idanagrafica)   )    without oids ;
insert into gestautoutente (codutente, idanagrafica) VALUES (33682, 300);


  
 */
public class GestionaleAuto {

	class Comparer implements Comparator<String> {

		String directory = "";

		public Comparer(String dir) {
			this.directory = dir;
		}

		public int compare(String obj1, String obj2) {
			File f1 = new File(directory + obj1);
			java.util.Date d1 = new java.util.Date(f1.lastModified());

			File f2 = new File(directory + obj2);
			java.util.Date d2 = new java.util.Date(f2.lastModified());

			return d2.compareTo(d1);
		}
	}

	static String buffertesto = "";
	static DBWrapper dmannuncio = null;
	static DBWrapper dmgautente = null;
	static DBWrapper dmgaannuncio = null;
	static DBWrapper dmannunciolettura = null;
	static Connection connimages = null;

	private static String TIPOANNUNCIO = "NL";
	private static String ATTRIBUTO = "AL";
	private static int KU = 0;

	public static void main(String[] args) throws IOException, SQLException {
		String cartella = "";
		String pooldb = "";
		System.out.println("GestionaleAuto 0.5081");
		System.out.println("--------------");
		try {
			cartella = args[0];
			pooldb = args[1];
		} catch (Exception e) {
			System.out.println("GestionaleAuto <cartella dei file xml> <pool db ad esempio dbppPP2>");
		}

		if (!cartella.equals("") && !pooldb.equals("")) {
			BasicDataSource ds = getDS(pooldb);
			connimages = ds.getConnection();
			dmannuncio = new DBWrapper(ds.getConnection());
			dmannunciolettura = new DBWrapper(ds.getConnection());
			dmgautente = new DBWrapper(ds.getConnection());
			dmgaannuncio = new DBWrapper(ds.getConnection());

			// prelevo KU
			dmannuncio.getList("select prossimoku from formato where codice = '" + TIPOANNUNCIO + "'");
			if (dmannuncio.rsNext()) {
				KU = dmannuncio.rsGetInt("prossimoku");
				System.out.println("KU " + KU);
			} else {
				System.out.println("non trovo KU!");
				System.exit(1);
			}
			dmannuncio.rsClose();

			processaFolder(cartella);
		}
	}

	private static void processaFolder(String directory) throws FileNotFoundException, IOException {
		System.out.println("processaFolder " + directory);
		
		File dir = new File(directory);
		FilenameFilter filter = null; // An optional filter for the directory
		String[] files = dir.list(filter); // Get the (filtered) directory entries
		// Arrays.sort(files, new Comparer(directory)); // And sort them

		for (int i = 0; i < files.length; i++) {
			// File currentFile = new File(directory + files[i]);
			processaFile("" + directory + files[i]);
		}
	}

	private static void processaFile(String nome) throws FileNotFoundException, IOException {
		try {
			AnnuncioBean ah = new AnnuncioBean();

			File fXmlFile = new File(nome);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			// optional, but recommended
			// read this -
			// http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();

			System.out.println("\n\n------------------------------------------------------------------------------");
			System.out.println("FILE :" + nome);

			String pref1 = "", telef1 = "";
			String urlannuncio = "", email = "";
			int idanagrafica = 0;

			NodeList nListAnagrafica = doc.getElementsByTagName("anagrafica");
			for (int temp = 0; temp < nListAnagrafica.getLength(); temp++) {
				Node nNode = nListAnagrafica.item(temp);
				// System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					idanagrafica = Integer.parseInt(xmlut.normalizza(xmlut.estrai("id_anagrafica", eElement)));
					System.out.println("id_anagrafica : " + idanagrafica);

					pref1 = telef1 = "";
					String telefono = xmlut.normalizza(xmlut.estrai("telefono", eElement));
					int doppio = telefono.indexOf(" cel");
					if (doppio > 0)
						telefono = telefono.substring(0, doppio);
					
					System.out.println("TEL. ORIG :" + telefono);

					telefono = Strings.replace(telefono, "/", " ");
					telefono = Strings.replace(telefono, "-", " ");
					telefono = Strings.replace(telefono, ".", " ");
					telefono = Strings.replace(telefono, "(", " ");
					telefono = Strings.replace(telefono, ")", " ");
					telefono = telefono.trim();

					try {
						pref1 = telefono.substring(0, telefono.indexOf(" ")).trim();
						telef1 = telefono.substring(telefono.indexOf(" "), telefono.length()).trim();
					} catch (Exception e) {
						for (int k = 0; k < xmlut.prefissi.length; k++) {
							if (telefono.startsWith(xmlut.prefissi[k])) {
								pref1 = telefono.substring(0, xmlut.prefissi[k].length()).trim();
								telef1 = telefono.substring(xmlut.prefissi[k].length() - 1, telefono.length()).trim();

								if ("0123456789".indexOf(telef1.substring(0, 1)) > 0) {
									// il primo carattere non va
									telef1 = telef1.substring(1, telef1.length());
								}
								break;
							} else {
								// se non comincia con un prefisso di fisso, allora e' un mobile, primi 3 prefisso
								pref1 = telefono.substring(0, 3).trim();
								telef1 = telefono.substring(3, telefono.length()).trim();

							}
						}
					}

					if (pref1.equals("") || telef1.equals("")) {
						System.out.println("************* ERRORE PARSE TELEFONO : " + telefono);
					}
					System.out.println("prefisso : " + pref1);
					System.out.println("telefono : " + telef1);

					urlannuncio = xmlut.normalizza(xmlut.estrai("sito", eElement));
					String http = "http://";
					if (urlannuncio.length() > 0) {
						urlannuncio = urlannuncio.startsWith(http) ? urlannuncio : http + urlannuncio;
					}

					email = xmlut.normalizza(xmlut.estrai("email", eElement));
					System.out.println("sito: " + urlannuncio);
					System.out.println("email: " + email);
				}
			}

			int codutente = cercaGestautoutente(idanagrafica); // IMPORTANTE, LO DEVI ASSOCIARE
			int ct = 0;

			if (codutente != 0) {

				Set<Integer> listapresenti = generaListaPresenti(idanagrafica);

				String elementi[][] = { { "car", "36" }, { "motorbike", "38" } };

				for (String el[] : elementi) {

					NodeList nList = doc.getElementsByTagName(el[0]);
					for (int temp = 0; temp < nList.getLength(); temp++) {
						Node nNode = nList.item(temp);
						// System.out.println("\nCurrent Element :" + nNode.getNodeName());
						if (nNode.getNodeType() == Node.ELEMENT_NODE) {
							ct++;

							Element eElement = (Element) nNode;
							int car_id = Integer.parseInt(eElement.getAttribute("id"));
							Node km = xmlut.estrai("km", eElement);
							Node anno = xmlut.estrai("registration_date", eElement);

							buffertesto = "";
							processaModel(nNode.getChildNodes());
							processaExterior(nNode.getChildNodes());
							buffertesto += " " + xmlut.normalizza(anno);
							buffertesto += " " + xmlut.normalizza(km, " km");

							buffertesto += xmlut.prenormalizza(" cambio ", xmlut.estrai("gearbox", eElement));

							processaOptions(nNode.getChildNodes());

							ArrayList<String> images = processaImages(nNode.getChildNodes());
							String last_modified = xmlut.normalizza(xmlut.estrai("last_modified", eElement));

							// prezzo
							String prezzo = xmlut.normalizza(xmlut.estrai("customers_price", eElement));
							String additional_informations = xmlut.normalizza(xmlut.estrai("additional_informations", eElement));

							// salvataggio
							ah.setCodutente(codutente);
							ah.setPref1(pref1);
							ah.setTelef1(telef1);
							ah.setTipoannuncio(TIPOANNUNCIO);
							ah.setAttributi(ATTRIBUTO);
							ah.setTesto(buffertesto.length() >= 299 ? buffertesto.substring(0, 299) : buffertesto);
							ah.setAddinfo(additional_informations);
							ah.setPrezzo(prezzo);
							ah.setKm(xmlut.normalizzaAsInt(km));
							ah.setAnno(xmlut.normalizzaAnno(anno));
							ah.setNumerofoto(images.size());
							ah.setKr(Integer.parseInt(el[1]));
							ah.setKu(KU);
							ah.setPubblicaemail("true");

							salvaGestautoannuncio(car_id, last_modified, ah, images, urlannuncio);

							// lo tolgo essendo stato processato
							if (listapresenti.contains(car_id))
								listapresenti.remove(car_id);

						} else {
							System.out.println("nNode.getNodeType() : " + nNode.getNodeType());
						}
					}

				}

				// processo cancellati
				if (!listapresenti.isEmpty()) {
					boolean primo = true;
					String perquery = "(";
					for (Iterator i = listapresenti.iterator(); i.hasNext();) {
						Integer cid = (Integer) i.next();

						if (primo) {
							primo = false;
							perquery += cid;
						} else {
							perquery += "," + cid;
						}
					}
					perquery += ")";

					System.out.println("lista car_id da rimuovere: " + perquery);

					System.out.println("aggiorno gli eliminati: ");
					dmannuncio.setSql("update gestautoannuncio set codiceoperazione = 'e' WHERE car_id IN " + perquery);
					int r1 = dmannuncio.executeSql();

					String qw = "update annuncio set ke = 0, statoai = 'W', nf = 'X' where ka in (select ka from gestautoannuncio where car_id in " + perquery
							+ ") AND codutente = " + codutente;
					System.out.println("imposto W... ");
					System.out.println(qw);
					dmannuncio.setSql(qw);
					int r2 = dmannuncio.executeSql();
				}
				System.out.println("TOTALE ELEMENTI TROVATI NEL FILE: " + ct);
			} else {
				System.out.println("ID " + idanagrafica + " NON TROVATO - Salto file corrente.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static Set<Integer> generaListaPresenti(int idanagrafica) {
		Set<Integer> h = new HashSet<Integer>();

		String q = "SELECT car_id FROM gestautoannuncio inner join annuncio on gestautoannuncio.ka = annuncio.ka inner join gestautoutente on annuncio.codutente = gestautoutente.codutente WHERE gestautoutente.idanagrafica = "
				+ idanagrafica + " AND gestautoannuncio.codiceoperazione != 'e';";
		try {
			dmannuncio.getList(q);
			while (dmannuncio.rsNext()) {
				h.add(dmannuncio.rsGetInt("car_id"));
			}
			dmannuncio.rsClose();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return h;
	}

	private static int cercaGestautoutente(int idanagrafica) {
		// prelevo codutente
		int r = 0;
		try {
			dmannuncio.getList("select codutente from gestautoutente where idanagrafica = " + idanagrafica);
			if (dmannuncio.rsNext()) {
				r = dmannuncio.rsGetInt("codutente");
			}
			dmannuncio.rsClose();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return r;
	}

	public static boolean salvaGestautoutente(DBWrapper dm, int codiceutente, int idanagrafica) throws SQLException {
		boolean rval = false;

		if ((codiceutente != 0) && (idanagrafica != 0)) {
			String QOut = "INSERT INTO gestautoutente (codutente, idanagrafica) VALUES (" + codiceutente + ", " + idanagrafica + ")";

			dm.setSql(QOut);
			rval = (dm.executeSql() > 0 ? true : false);

			if (rval) {
				// se il precedente inserimento fallisce vuol dire che l'avevo gia' inserita...
			}
		}

		return rval;
	}

	public static boolean cancellaTutteImmagini(DBWrapper dm, int ka) throws SQLException {
		dm.setSql("delete from images where ka=" + ka);
		return (dm.executeSql() > 0);
	}

	private static void inserisciTutteImmagini(int ka, ArrayList<String> images, String linkannuncio) {

		GestioneImmagini ga = new GestioneImmagini();
		for (int j = 0; j < images.size(); j++) {
			ga.saveImg(connimages, images.get(j), ka, linkannuncio);
		}
	}

	public static boolean salvaGestautoannuncio(int car_id, String last_modified, AnnuncioBean ah, ArrayList<String> images, String urlannuncio) throws SQLException {
		boolean rval = false;
		String db_last_modified = "";
		int ka = 0;
		AnnuncioSaver annuncio = new AnnuncioSaver(dmannuncio);

		if (car_id != 0) {

			// se
			String qq = "SELECT * from gestautoannuncio WHERE car_id = " + car_id;
			dmannunciolettura.getList(qq);
			if (dmannunciolettura.rsNext()) {
				db_last_modified = dmannunciolettura.rsGetString("last_modified");
				ka = dmannunciolettura.rsGetInt("ka");
			}
			dmannunciolettura.rsClose();
			if (ka != 0) {
				ah.setKa(ka);
				// a questo punto se ho ka vuol dire che e' un update o un salto
				if (!db_last_modified.equals(last_modified)) {

					// e devo aggiornare la data su gestannuncio
					String QOut = "update gestautoannuncio set codiceoperazione='a', last_modified='" + last_modified + "' WHERE car_id = " + car_id;
					dmannunciolettura.setSql(QOut);
					rval = (dmannunciolettura.executeSql() > 0 ? true : false);

					if (rval) { // devo aggiornare il record su annuncio
						// ora posso aggiornare le immagini
						ah.setNumerofoto(images.size());

						// prima cancello tutte le immagini
						cancellaTutteImmagini(dmannunciolettura, ka);
						inserisciTutteImmagini(ka, images, urlannuncio);

						// infine lo aggiorno!!!
						ah.setStatoai("W");
						annuncio.update(ah, ah.getCodutente());
						System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id : " + car_id + " last_modified: " + last_modified + " aggiornato!");
					}
				} else {
					// si tratta di un salto
					String QOut = "update gestautoannuncio set codiceoperazione='c' WHERE car_id = " + car_id;
					dmannunciolettura.setSql(QOut);
					rval = (dmannunciolettura.executeSql() > 0 ? true : false);
				}
			} else {

				// in caso contrario non c'e' nessun record e lo devo inserire
				ah.setNumerofoto(images.size());
				ka = annuncio.save(ah);
				inserisciTutteImmagini(ka, images, urlannuncio);
				String QOut = "INSERT INTO gestautoannuncio (codiceoperazione, ka, car_id, last_modified) VALUES ('i', " + ka + ", " + car_id + ", '" + last_modified + "')";
				// System.out.println(QOut);
				dmannunciolettura.setSql(QOut);
				rval = (dmannunciolettura.executeSql() > 0 ? true : false);

				System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id : " + car_id + " last_modified: " + last_modified);
			}
		}
		return rval;
	}

	private static void processaOptions(NodeList nList) {
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeName().equals("options")) {

				try {
					for (int i = 0; i <= nNode.getChildNodes().getLength(); i++) {
						buffertesto += inWhite(nNode.getChildNodes().item(i).getFirstChild());
					}
				} catch (Exception e) {

				}

			}
		}
	}

	private static ArrayList<String> processaImages(NodeList nList) {
		ArrayList<String> ims = new ArrayList<String>();

		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeName().equals("images")) {
				NodeList innernNodeList = nList.item(temp).getChildNodes();
				for (int innertemp = 0; innertemp < innernNodeList.getLength(); innertemp++) {
					Node innernNode = innernNodeList.item(innertemp);
					if (innernNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) innernNode;
						String urlimg = xmlut.normalizza(xmlut.estrai("large", eElement));
						ims.add(urlimg);
						// System.out.println("large " + urlimg);
					}
				}
			}
		}
		return ims;
	}

	private static String inWhite(Node fc) {
		String cosa = xmlut.normalizza(fc);
		if ((fc != null)
				&& ("Boardcomputer,Cerchi in Lega,Climatizzatore,Interni in pelle,Park Distance Control,Sistema di Navigazione,Trazione integrale,Tettuccio apribile,Fari Xenon,Cruise control,ABS,ESP"
						.toLowerCase().indexOf(cosa.toLowerCase()) >= 0)) {
			return " " + cosa;
		} else {
			return "";
		}
	}

	private static void processaModel(NodeList nList) {
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeName().equals("model")) {
				Element eElement = (Element) nNode;
				buffertesto += xmlut.normalizza(xmlut.estrai("make", eElement)) + " " + 
								xmlut.normalizza(xmlut.estrai("model", eElement)) + " " + 
								xmlut.normalizza(xmlut.estrai("version", eElement)) + " " + 
								xmlut.normalizza(xmlut.estrai("cc", eElement), "cc ") + 
								xmlut.normalizza(xmlut.estrai("body", eElement)) + " " + 
								xmlut.normalizza(xmlut.estrai("fuel", eElement)) + " ";

				break;
			}
		}

	}

	private static void processaExterior(NodeList nList) {
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeName().equals("exterior")) {
				Element eElement = (Element) nNode;
				buffertesto += xmlut.normalizza(xmlut.estrai("color", eElement)) + " " + xmlut.normalizza(xmlut.estrai("paint", eElement));
				break;
			}
		}

	}

	public static BasicDataSource getDS(String poolname) {

		String mutex = "";
		synchronized (mutex) {

			BasicDataSource ds = null;
			try {
				ds = new BasicDataSource();

				ds.setMaxActive(350); // cambiato da 150 a 350 dopo aver messo i threads a 80
				ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
				ds.setMinIdle(10);

				ds.setDriverClassName("org.postgresql.Driver");
				System.out.println("getDS chiedo pool " + poolname);

				if (poolname.equals("dbppLOC")) {
					ds.setUsername("pepper");
					ds.setPassword("hotsauce");
					ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

				} else if (poolname.equals("dbppTEST")) {
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
					ds.setUrl("jdbc:postgresql://188.166.194.166:5430/portaportese?compatible=7.1");


				} else if (poolname.equals("dbpp")) {
					System.out.println("Collegato a dbpp!");
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
					ds.setUrl("jdbc:postgresql://pp200.prv.lan/portaportese?compatible=7.1");
				}
			} catch (Exception e) {
				System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
			}
			return ds;
		}
	}
}
