package flusso.xml;

import it.portaportese.images.ImagesProcessing;
import it.portaportese.utils.logging.Syslog;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class GestioneImmagini {

	public boolean saveImg(Connection connimages, String linkimage, int ka, String link) {
		boolean ok = false;
		int maxx = 640;
		int maxy = 480;
		if (ka != 0) {
			try {
				URL url = new URL(linkimage);
				URLConnection conn = url.openConnection();
				InputStream immagine = conn.getInputStream();
				InputStream immagine2 = (new URL(linkimage)).openConnection().getInputStream();
				InputStream immagine3 = (new URL(linkimage)).openConnection().getInputStream();
				InputStream immagine4 = (new URL(linkimage)).openConnection().getInputStream();

				// File immagine = new File(filenamepath);

				ImagesProcessing ip = new ImagesProcessing();

				// SCALA L'IMMAGINE
				ByteArrayOutputStream os = ip.getResizedImage(immagine, maxx, maxy);

				// versione per oidimageservlet
				ByteArrayOutputStream os48x36 = ip.getResizedImage(immagine2, 48, 36);

				// versione per imagesdba400 ****
				ByteArrayOutputStream os180x135 = ip.getResizedImage(immagine3, 180, 135);

				// versione per imagesdba400 ****
				ByteArrayOutputStream os83x60 = ip.getResizedImage(immagine4, 83, 60);

				// PG8
				connimages.setAutoCommit(false);

				try {
					PreparedStatement stmt = null;

					stmt = connimages.prepareStatement("INSERT into images (imgoid, im48x36, im180x135, im83x60, ka, nomefile, url) " + "VALUES(?,?,?,?,?,?,?)");
					stmt.setBytes(1, os.toByteArray()); // devi salvare le varie versioni
					stmt.setBytes(2, os48x36.toByteArray()); // devi salvare le varie versioni
					stmt.setBytes(3, os180x135.toByteArray()); // devi salvare le varie versioni
					stmt.setBytes(4, os83x60.toByteArray()); // devi salvare le varie versioni
					stmt.setInt(5, ka);
					stmt.setString(6, "ga");
					stmt.setString(7, link);
					stmt.executeUpdate();
					stmt.close();
					ok = true;

				} catch (SQLException e) {
					Syslog.write("saveImg SQLException: ", e);
				}
				connimages.commit();
				//System.out.println("saveImg " + linkimage + " ok!");
			} catch (Exception e) {
				Syslog.write("saveImg URL: " + linkimage + " Exception: ", e);
				try {
					connimages.rollback();
				} catch (SQLException e1) {
					System.out.println("saveImg SQLException rolling back transaction... ");
				}
			}
		}
		return ok;
	}
}
