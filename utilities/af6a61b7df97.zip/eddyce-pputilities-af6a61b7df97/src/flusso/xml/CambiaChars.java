package flusso.xml;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import flusso.xml.utils.xmlut;

public class CambiaChars {

	public static void main(String[] args) throws IOException, SQLException {
		String x = null;
		BufferedReader f = new BufferedReader(new InputStreamReader(System.in));

		while ((x = f.readLine()) != null) {
			System.out.println(xmlut.replaceHTMLWithAscii(x));
		}
	}
}
