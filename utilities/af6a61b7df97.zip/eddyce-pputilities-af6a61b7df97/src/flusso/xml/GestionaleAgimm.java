package flusso.xml;

import flusso.xml.utils.FSystemNOSC;
import flusso.xml.utils.xmlut;
import forms.AnnuncioBean;
import it.portaportese.system.PCValues;
import it.portaportese.utils.DBWrapper;
import it.portaportese.utils.Strings;
import it.portaportese.utils.logging.Syslog;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.dbcp.BasicDataSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import savers.AnnuncioSaver;


/*

CREATE TABLE gestAgimmAnnuncio (
  ka integer NOT NULL,
  imm_id text NOT NULL,
  annunciouid text,
  codiceoperazione character(1),
  CONSTRAINT gAgimmanuncio_pkey PRIMARY KEY (ka, imm_id)
) WITHOUT OIDS;

CREATE TABLE gestAgimmUtente (
  codutente integer NOT NULL,
  idanagrafica text NOT NULL,
  CONSTRAINT gAgimmutente_pkey PRIMARY KEY (codutente, idanagrafica)
) WITHOUT OIDS;

*/

public class GestionaleAgimm {

	class Comparer implements Comparator<String> {

		String directory = "";

		public Comparer(String dir) {
			this.directory = dir;
		}

		public int compare(String obj1, String obj2) {
			File f1 = new File(directory + obj1);
			java.util.Date d1 = new java.util.Date(f1.lastModified());

			File f2 = new File(directory + obj2);
			java.util.Date d2 = new java.util.Date(f2.lastModified());

			return d2.compareTo(d1);
		}
	}

	private static final boolean dryrun = false;

	static DBWrapper dmannuncio = null;
	static DBWrapper dmgautente = null;
	static DBWrapper dmgaannuncio = null;
	static DBWrapper dmannunciolettura = null;
	static Connection connimages = null;

	private static String TIPOANNUNCIO = "NL";
	private static String ATTRIBUTO = "AL";
	private static int KU = 0;
	private static PCValues Vpc;
	private static int qaggiornati=0;
	private static int qerrori=0;
	private static int qinseriti=0;
	private static int qsaltati=0;

	public static void main(String[] args) throws IOException, SQLException {
		String cartella = "";
		String pooldb = "";
		System.out.println("GestionaleAgimm 0.120");
		System.out.println("--------------");
		try {
			cartella = args[0];
			pooldb = args[1];
		} catch (Exception e) {
			System.out.println("GestionaleAgimm <cartella dei file xml> <pool db ad esempio dbppPP2>");
		}

		if (!cartella.equals("") && !pooldb.equals("")) {
			BasicDataSource ds = getDS(pooldb);
			connimages = ds.getConnection();
			dmannuncio = new DBWrapper(ds.getConnection());
			dmannunciolettura = new DBWrapper(ds.getConnection());
			dmgautente = new DBWrapper(ds.getConnection());
			dmgaannuncio = new DBWrapper(ds.getConnection());

			// prelevo KU
			dmannuncio.getList("select prossimoku from formato where codice = '" + TIPOANNUNCIO + "'");
			if (dmannuncio.rsNext()) {
				KU = dmannuncio.rsGetInt("prossimoku");
				System.out.println("KU " + KU);
			} else {
				System.out.println("non trovo KU!");
				System.exit(1);
			}
			dmannuncio.rsClose();

			processaFolder(cartella);
			System.out.println("TOTALI");
			System.out.println("qinseriti=" + qinseriti + " qaggiornati=" + qaggiornati + " qsaltati=" + qsaltati + " qerrori=" + qerrori);
		}
	}

	private static void processaFolder(String directory) throws FileNotFoundException, IOException {
		File dir = new File(directory);
		FilenameFilter filter = new FilenameFilter() {
		    public boolean accept(File dir, String name) {
		        return name.toLowerCase().endsWith(".xml");
		    }
		};
				
		String[] files = dir.list(filter); // Get the (filtered) directory entries
		// Arrays.sort(files, new Comparer(directory)); // And sort them

		for (int i = 0; i < files.length; i++) {
			// File currentFile = new File(directory + files[i]);
			String nome = "" + directory + files[i];
			Syslog.write("processo " + nome);
			processaFile(nome);
		}
	}

	private static void initLRBR() {
		if (Vpc == null) {
			FSystemNOSC fs = new FSystemNOSC("init");
			Vpc = (PCValues) fs.load("initdata");
			Syslog.write("LISTA RUBRICHE LOCALE INIZIALIZZATA ..." + (Vpc.getListaRubriche().getRubrica("CD").getkr() == 56 ? " OK! " : ""));
		}
	}

	private static InputStream checkForUtf8BOMAndDiscardIfAny(InputStream inputStream) throws IOException {
		PushbackInputStream pushbackInputStream = new PushbackInputStream(new BufferedInputStream(inputStream), 3);
		byte[] bom = new byte[3];
		if (pushbackInputStream.read(bom) != -1) {
			if (!(bom[0] == (byte) 0xEF && bom[1] == (byte) 0xBB && bom[2] == (byte) 0xBF)) {
				pushbackInputStream.unread(bom);
			}
		}
		return pushbackInputStream;
	}

	private static void processaFile(String nome) throws FileNotFoundException, IOException {
		try {
			initLRBR();

			AnnuncioBean ah = new AnnuncioBean();

			FileInputStream fXmlFile = new FileInputStream(nome);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(checkForUtf8BOMAndDiscardIfAny(fXmlFile));

			// optional, but recommended
			// read this -
			// http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();

			System.out.println("\n\n------------------------------------------------------------------------------");
			System.out.println("FILE :" + nome);

			String pref1 = "", telef1 = "";
			String urlannuncio = "", email = "";
			String idanagrafica = "";

			NodeList nListAnagrafica = doc.getElementsByTagName("anagrafica");
			for (int temp = 0; temp < nListAnagrafica.getLength(); temp++) {
				Node nNode = nListAnagrafica.item(temp);
				// System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					idanagrafica = xmlut.normalizza(estrai("id_anagrafica", eElement));
					System.out.println("id_anagrafica : " + idanagrafica);

					pref1 = telef1 = "";
					String telefono = xmlut.normalizza(estrai("telefono", eElement));
					System.out.println("TEL. ORIG :" + telefono);

					telefono = Strings.replace(telefono, "/", " ");
					telefono = Strings.replace(telefono, "-", " ");
					telefono = Strings.replace(telefono, ".", " ");
					telefono = Strings.replace(telefono, "(", " ");
					telefono = Strings.replace(telefono, ")", " ");
					telefono = telefono.trim();

					try {
						pref1 = telefono.substring(0, telefono.indexOf(" ")).trim();
						telef1 = telefono.substring(telefono.indexOf(" "), telefono.length()).trim();
					} catch (Exception e) {
						for (int k = 0; k < xmlut.prefissi.length; k++) {
							if (telefono.startsWith(xmlut.prefissi[k])) {
								pref1 = telefono.substring(0, xmlut.prefissi[k].length()).trim();
								telef1 = telefono.substring(xmlut.prefissi[k].length() - 1, telefono.length()).trim();

								if ("0123456789".indexOf(telef1.substring(0, 1)) > 0) {
									// il primo carattere non va
									telef1 = telef1.substring(1, telef1.length());
								}
								break;
							} else {
								// se non comincia con un prefisso di fisso, allora e' un mobile, primi 3 prefisso
								pref1 = telefono.substring(0, 3).trim();
								telef1 = telefono.substring(3, telefono.length()).trim();

							}
						}
					}

					if (pref1.equals("") || telef1.equals("")) {
						System.out.println("************* ERRORE PARSE TELEFONO : " + telefono);
					}
					System.out.println("prefisso : " + pref1);
					System.out.println("telefono : " + telef1);

					urlannuncio = xmlut.normalizza(estrai("sito", eElement));
					String http = "http://";
					if (urlannuncio.length() > 0) {
						urlannuncio = urlannuncio.startsWith(http) ? urlannuncio : http + urlannuncio;
					}

					email = xmlut.normalizza(estrai("email", eElement));
					System.out.println("sito: " + urlannuncio);
					System.out.println("email: " + email);
				}
			}

			int codutente = cercaGestimmutente(idanagrafica); // IMPORTANTE, LO DEVI ASSOCIARE
			int ct = 0;

			if (codutente != 0) {

				Set<String> listapresenti = generaListaPresenti(idanagrafica);

				String elementi[][] = { { "immobile", "53" } };

				for (String el[] : elementi) {

					NodeList nList = doc.getElementsByTagName(el[0]);
					for (int temp = 0; temp < nList.getLength(); temp++) {
						Node nNode = nList.item(temp);
						// System.out.println("\nCurrent Element :" + nNode.getNodeName());
						if (nNode.getNodeType() == Node.ELEMENT_NODE) {
							ct++;

							Element eElement = (Element) nNode;
							String imm_id = eElement.getAttribute("id");
							String rubrica = xmlut.normalizza(estrai("rubrica", eElement));
							String testo = xmlut.normalizza(estrai("testo", eElement));
							Node tipologiaimmobile = estrai("tipologiaimmobile", eElement);
							Node superficie = estrai("superficie", eElement);
							Node locali = estrai("locali", eElement);

							
							String sclasseenergetica = xmlut.normalizza(estrai("classeenergetica", eElement));
							String classeenergetica = "";
							if (sclasseenergetica.startsWith("Esente")) {
								classeenergetica = "7";
							} else if (sclasseenergetica.startsWith("A")) {
								classeenergetica = "6";
							} else if (sclasseenergetica.startsWith("B")) {
								classeenergetica = "5";
							} else if (sclasseenergetica.startsWith("C")) {
								classeenergetica = "4";
							} else if (sclasseenergetica.startsWith("D")) {
								classeenergetica = "3";
							} else if (sclasseenergetica.startsWith("E")) {
								classeenergetica = "2";
							} else if (sclasseenergetica.startsWith("F")) {
								classeenergetica = "1";
							} else if (sclasseenergetica.startsWith("G")) {
								classeenergetica = "0";
							} else {
								System.out.println("CLASSE ENERGETICA NON RICONOSCIUTA: " + sclasseenergetica + " assegno void!");
							}

							Node latitudine = estrai("latitudine", eElement);
							Node longitudine = estrai("longitudine", eElement);
							String prezzo = xmlut.normalizza(estrai("prezzo", eElement));
							String additional_informations = xmlut.normalizza(estrai("additional_informations", eElement));

							ArrayList<String> images = processaImages(nNode.getChildNodes());

							// salvataggio
							ah.setCodutente(codutente);
							ah.setPref1(pref1);
							ah.setTelef1(telef1);
							ah.setTipoannuncio(TIPOANNUNCIO);
							ah.setAttributi(ATTRIBUTO);
							ah.setTesto(testo.length() >= 299 ? testo.substring(0, 299) : testo);
							ah.setTipologiaimmobile(xmlut.normalizza(tipologiaimmobile));
							ah.setMq(xmlut.normalizzaAsInt(superficie));
							ah.setLocali(xmlut.normalizzaAsInt(locali));
							ah.setTipoace(classeenergetica);
							ah.setLatitudine(xmlut.normalizzaAsDouble(latitudine));
							ah.setLongitudine(xmlut.normalizzaAsDouble(longitudine));
							ah.setPrezzo(prezzo);
							ah.setAddinfo(additional_informations);

							ah.setNumerofoto(images.size());
							ah.setKr(Vpc.getListaRubriche().getRubrica(rubrica).getkr());
							if (ah.getKr() == 0) {
								System.out.println("KR ERRATO, RUBRICA " + rubrica + " Assegno 53!");
								ah.setKr(53);
							}

							ah.setKu(KU);
							
							// SEMPRE SENZA EMAIL, CAFOLLA VIA SKYPE il 20/10/2015
							//ah.setPubblicaemail("true");

							String annunciouid = DigestUtils.sha1Hex(ah.getPref1() + ah.getTelef1() + ah.getTesto() + ah.getTipologiaimmobile() + ah.getLatitudine()
									+ ah.getLongitudine() + ah.getAddinfo() + ah.getPrezzo() + ah.getNumerofoto() + rubrica);
							salvaGestAgimmAnnuncio(imm_id, annunciouid, ah, images, urlannuncio);

							// lo tolgo essendo stato processato
							if (listapresenti.contains(imm_id))
								listapresenti.remove(imm_id);

						} else {
							System.out.println("nNode.getNodeType() : " + nNode.getNodeType());
						}
					}

				}

				// processo cancellati
				if (!listapresenti.isEmpty()) {
					boolean primo = true;
					String perquery = "(";
					for (Iterator<String> i = listapresenti.iterator(); i.hasNext();) {
						String cid = (String) i.next();

						if (primo) {
							primo = false;
							perquery += "'" + cid + "'";
						} else {
							perquery += ",'" + cid + "'";
						}
					}
					perquery += ")";

					System.out.println("lista imm_id da rimuovere: " + perquery);

					System.out.println("aggiorno gli eliminati: ");
					dmannuncio.setSql("update gestAgimmAnnuncio set codiceoperazione = 'e' WHERE imm_id IN " + perquery);
					if (!dryrun) dmannuncio.executeSql();

					String qw = "update annuncio set ke = 0, statoai = 'W', nf = 'X' where ka in (select ka from gestAgimmAnnuncio where imm_id in " + perquery
							+ ") AND codutente = " + codutente;
					System.out.println("imposto W... ");
					System.out.println(qw);
					dmannuncio.setSql(qw);
					if (!dryrun) dmannuncio.executeSql();
				}
				System.out.println("TOTALE ELEMENTI TROVATI NEL FILE: " + ct);
			} else {
				System.out.println("CODUTENTE NON TROVATO - Salto file corrente.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static Set<String> generaListaPresenti(String idanagrafica) {
		Set<String> h = new HashSet<String>();

		String q = "SELECT imm_id FROM gestAgimmAnnuncio inner join annuncio on gestAgimmAnnuncio.ka = annuncio.ka inner join gestAgimmUtente on annuncio.codutente = gestAgimmUtente.codutente WHERE gestAgimmUtente.idanagrafica = '"
				+ idanagrafica + "' AND gestAgimmAnnuncio.codiceoperazione != 'e';";
		try {
			dmannuncio.getList(q);
			while (dmannuncio.rsNext()) {
				h.add(dmannuncio.rsGetString("imm_id"));
			}
			dmannuncio.rsClose();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return h;
	}

	private static int cercaGestimmutente(String idanagrafica) {
		// prelevo codutente
		int r = 0;
		try {
			dmannuncio.getList("select codutente from gestAgimmUtente where idanagrafica = '" + idanagrafica + "'");
			if (dmannuncio.rsNext()) {
				r = dmannuncio.rsGetInt("codutente");
			}
			dmannuncio.rsClose();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return r;
	}

	public static boolean salvaGestimmutente(DBWrapper dm, int codiceutente, int idanagrafica) throws SQLException {
		boolean rval = false;

		if ((codiceutente != 0) && (idanagrafica != 0)) {
			String QOut = "INSERT INTO gestAgimmUtente (codutente, idanagrafica) VALUES (" + codiceutente + ", " + idanagrafica + ")";

			dm.setSql(QOut);
			if (!dryrun) rval = (dm.executeSql() > 0 ? true : false);

			if (rval) {
				// se il precedente inserimento fallisce vuol dire che l'avevo gia' inserita...
			}
		}

		return rval;
	}

	public static void cancellaTutteImmagini(DBWrapper dm, int ka) throws SQLException {
		dm.setSql("delete from images where ka=" + ka);
		if (!dryrun) dm.executeSql(); 
	}

	private static void inserisciTutteImmagini(int ka, ArrayList<String> images, String linkannuncio) {

		GestioneImmagini ga = new GestioneImmagini();
		for (int j = 0; j < images.size(); j++) {
			if (!dryrun) ga.saveImg(connimages, images.get(j), ka, linkannuncio);
		}
	}

	public static boolean salvaGestAgimmAnnuncio(String imm_id, String sha1code, AnnuncioBean ah, ArrayList<String> images, String urlannuncio) throws SQLException {
		boolean rval = false;
		String db_annunciouid = "", codiceoperazione = "";
		int ka = 0;
		AnnuncioSaver annuncio = new AnnuncioSaver(dmannuncio);

		if (imm_id.length() > 0) {
			// se
			String qq = "SELECT * from gestAgimmAnnuncio WHERE imm_id = '" + imm_id + "'";
			dmannunciolettura.getList(qq);
			if (dmannunciolettura.rsNext()) {
				db_annunciouid = dmannunciolettura.rsGetString("annunciouid");
				ka = dmannunciolettura.rsGetInt("ka");
				codiceoperazione = dmannunciolettura.rsGetString("codiceoperazione");
			}
			dmannunciolettura.rsClose();
			if (ka != 0) {
				ah.setKa(ka);
				// a questo punto se ho ka vuol dire che e' un update o un salto
				if ((codiceoperazione.equals("e")) || (!db_annunciouid.equals(sha1code))) {

					// e devo aggiornare la data su gestannuncio
					String QOut = "update gestAgimmAnnuncio set codiceoperazione='a', annunciouid='" + sha1code + "' WHERE imm_id = '" + imm_id + "'";
					dmannunciolettura.setSql(QOut);
					if (!dryrun) rval = (dmannunciolettura.executeSql() > 0 ? true : false);

					if (rval) { // devo aggiornare il record su annuncio
						// ora posso aggiornare le immagini
						ah.setNumerofoto(images.size());

						// prima cancello tutte le immagini
						cancellaTutteImmagini(dmannunciolettura, ka);
						inserisciTutteImmagini(ka, images, urlannuncio);

						// infine lo aggiorno!!!
						ah.setStatoai("W");
						if (!dryrun) annuncio.update(ah, ah.getCodutente());
						System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id: " + imm_id + " annunciouid: " + sha1code + 
								(db_annunciouid.equals(sha1code) ? " reinserito!" : 	" aggiornato!"));
						qaggiornati++;
					} else {
						System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id: " + imm_id + " annunciouid: " + sha1code + " WARNING NON TROVO annunciouid in gestAgimmAnnuncio!");
						qerrori++;
					}
				} else {
					// si tratta di un salto
					String QOut = "update gestAgimmAnnuncio set codiceoperazione='c' WHERE imm_id = '" + imm_id + "'";
					dmannunciolettura.setSql(QOut);
					if (!dryrun) rval = (dmannunciolettura.executeSql() > 0 ? true : false);
					System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id: " + imm_id + " annunciouid: " + sha1code + " saltato!");
					qsaltati++;
				}
			} else {

				// in caso contrario non c'e' nessun record e lo devo inserire
				ah.setNumerofoto(images.size());
				if (!dryrun) ka = annuncio.save(ah);
				inserisciTutteImmagini(ka, images, urlannuncio);
				String QOut = "INSERT INTO gestAgimmAnnuncio (codiceoperazione, ka, imm_id, annunciouid) VALUES ('i', " + ka + ", '" + imm_id + "', '" + sha1code + "')";
				// System.out.println(QOut);
				dmannunciolettura.setSql(QOut);
				if (!dryrun) rval = (dmannunciolettura.executeSql() > 0 ? true : false);
				System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id: " + imm_id + " annunciouid: " + sha1code + " inserito!");
				qinseriti++;
			}
		}
		return rval;
	}

	private static ArrayList<String> processaImages(NodeList nList) {
		ArrayList<String> ims = new ArrayList<String>();

		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeName().equals("images")) {
				NodeList innernNodeList = nList.item(temp).getChildNodes();
				for (int innertemp = 0; innertemp < innernNodeList.getLength(); innertemp++) {
					Node innernNode = innernNodeList.item(innertemp);
					if (innernNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) innernNode;
						String urlimg = xmlut.normalizza(estrai("picture_url", eElement));
						ims.add(urlimg);
						// System.out.println("large " + urlimg);
					}
				}
			}
		}
		return ims;
	}

	private static Node estrai(String cosa, Element eElement) {
		try {
			return eElement.getElementsByTagName(cosa).item(0).getFirstChild();
		} catch (Exception e) {
			return eElement.getElementsByTagName(cosa).item(0);
		}
	}

	public static BasicDataSource getDS(String poolname) {

		String mutex = "";
		synchronized (mutex) {

			BasicDataSource ds = null;
			try {
				ds = new BasicDataSource();

				ds.setMaxActive(350); // cambiato da 150 a 350 dopo aver messo i threads a 80
				ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
				ds.setMinIdle(10);

				ds.setDriverClassName("org.postgresql.Driver");

				if (poolname.equals("dbppLOC")) {
					ds.setUsername("pepper");
					ds.setPassword("ciccio");
					ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

				} else if (poolname.equals("dbppTEST")) {
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
					ds.setUrl("jdbc:postgresql://188.166.194.166:5430/portaportese?compatible=7.1");

				} else if (poolname.equals("dbpp")) {
					System.out.println("Collegato a dbpp!");
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");

					ds.setUrl("jdbc:postgresql://pp200.prv.lan/portaportese?compatible=7.1");
				}
			} catch (Exception e) {
				System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
			}
			return ds;
		}
	}
}
