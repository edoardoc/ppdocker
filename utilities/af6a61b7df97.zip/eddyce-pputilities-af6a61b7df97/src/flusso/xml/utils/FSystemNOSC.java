package flusso.xml.utils;

import it.portaportese.system.serialize.Serex;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Edoardo
 * 
 * Classe con metodi per salvare e ricaricare dei bean dal filesystem, in
 * pratica un CLASSE PER I/O per serializzare i beans! <b>Ogni oggetto che
 * questa classe serializza deve implementare l'interfaccia Serex </b>
 *  
 */
public class FSystemNOSC {
	private static final String PPUT = "./ppbin/";
	private String prefixpath = null;
	private String extension = null;

	public FSystemNOSC(String nomedir) {
		this.prefixpath = PPUT;
		this.extension = ".sbin";
	}
	public FSystemNOSC(String nomedir, String extension) {
		this.prefixpath = PPUT;
		this.extension = extension;
	}
	public Object load(String regbeanname) {
		Serex rbn = null;
		String filename = prefixpath + regbeanname + extension;

		try {
			FileInputStream fis = new FileInputStream(filename);
			ObjectInputStream ois = new ObjectInputStream(fis);
			rbn = (Serex) ois.readObject();
			ois.close();
		} catch (Exception e) {
			System.err.println("Error during DEserialization: " + e);
			rbn = null;
		}
		return rbn;
	}
	public boolean save(Serex rb, String nome) {
		boolean resultcode = false;

		// ogni oggetto serializzabile discende dalla classe astratta
		// serex
		String filename = prefixpath + nome + extension;
		resultcode = serialize(rb, filename);
		return resultcode;
	}
	private boolean serialize(Serex rb, String filename) {
		boolean resultcode;
		try {
			FileOutputStream fos = new FileOutputStream(filename);

			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(rb);
			oos.flush();
			oos.close();

			resultcode = true;

		} catch (Exception e) {
			System.err.println("Error during serialization: " + e);
			resultcode = false;
		}
		return resultcode;
	}
	public boolean update(Serex rb, String name) {
		boolean resultcode = false;

		String filename = prefixpath + name + extension;
		resultcode = serialize(rb, filename);
		return resultcode;
	}
}