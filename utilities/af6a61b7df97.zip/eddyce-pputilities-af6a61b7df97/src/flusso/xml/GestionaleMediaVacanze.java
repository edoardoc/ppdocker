package flusso.xml;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.dbcp.BasicDataSource;
import org.json.JSONArray;
import org.json.JSONObject;

import flusso.xml.utils.FSystemNOSC;
import flusso.xml.utils.xmlut;
import forms.AnnuncioBean;
import it.portaportese.system.PCValues;
import it.portaportese.utils.DBWrapper;
import it.portaportese.utils.functions;
import it.portaportese.utils.logging.Syslog;
import savers.AnnuncioSaver;

public class GestionaleMediaVacanze {

	static DBWrapper dmannuncio = null;
	static DBWrapper dmgautente = null;
	static DBWrapper dmgaannuncio = null;
	static DBWrapper dmannunciolettura = null;
	static Connection connimages = null;

	private static String TIPOANNUNCIO = "NL";
	private static String ATTRIBUTO = "AL";
	private static int KU = 0;
	private static PCValues Vpc;
	
/*
CREATE TABLE gestmediavacanze (
  ka integer NOT NULL,
  imm_id text NOT NULL,
  annunciouid text,
  codiceoperazione character(1),
  CONSTRAINT gestmediavacanze_pkey PRIMARY KEY (ka, imm_id)
) WITHOUT OIDS;

*/

	public static void main(String[] args) throws IOException, SQLException {
		String dati = "";
		String pooldb = "";
		System.out.println("GestionaleMediaVacanze 1.0");
		System.out.println("--------------");
		try {
			pooldb = args[0];
			dati = functions.readFile(args[1]);
		} catch (Exception e) {
			System.out.println("GestionaleMediaVacanze <pool db ad esempio dbppPP2> <datafile.json> ");
			System.exit(1);
		}

		if (!pooldb.equals("")) {
			BasicDataSource ds = getDS(pooldb);
			connimages = ds.getConnection();
			dmannuncio = new DBWrapper(ds.getConnection());
			dmannunciolettura = new DBWrapper(ds.getConnection());
			dmgautente = new DBWrapper(ds.getConnection());
			dmgaannuncio = new DBWrapper(ds.getConnection());

			// prelevo KU
			dmannuncio.getList("select prossimoku from formato where codice = '" + TIPOANNUNCIO + "'");
			if (dmannuncio.rsNext()) {
				KU = dmannuncio.rsGetInt("prossimoku");
				System.out.println("KU " + KU);
			} else {
				System.out.println("non trovo KU!");
				System.exit(1);
			}
			dmannuncio.rsClose();

			// alla fine ho la stringa
			processaFile(dati);
		}
	}

	private static void initLRBR() {
		if (Vpc == null) {
			FSystemNOSC fs = new FSystemNOSC("init");
			Vpc = (PCValues) fs.load("initdata");
			Syslog.write("LISTA RUBRICHE LOCALE INIZIALIZZATA ..." + (Vpc.getListaRubriche().getRubrica("CD").getkr() == 56 ? " OK! " : ""));
		}
	}
	
	private static void processaFile(String jsonText) throws FileNotFoundException, IOException {
		try {
			initLRBR();

			AnnuncioBean ah = new AnnuncioBean();
			String pref1 = "", telef1 = "", linkesterno = "";

			int CODUTENTE = 46005;	// IMPORTANTE VA IMPOSTATO
			int RUBRICA = 57;	// IMPORTANTE VA IMPOSTATO
			int ct = 0;
			Set<String> listapresenti = generaListaPresenti();
		    JSONArray jsonMainArr = (new JSONObject(jsonText)).getJSONArray("ListaAnnunci");
			for (ct = 0; ct < jsonMainArr.length(); ct++) {
				JSONObject ennesimo = jsonMainArr.getJSONObject(ct);
				String imm_id = checkAsString(ennesimo, "Codice");
				
				// antepongo zona al titolo se c'e'
				String titolo = xmlut.replaceHTMLWithAscii(checkAsString(ennesimo, "Titolo"));
				if ((ennesimo.has("Dove")) && (ennesimo.getJSONObject("Dove").has("City"))) {
					JSONObject crd = ennesimo.getJSONObject("Dove");
					titolo = xmlut.replaceHTMLWithAscii(checkAsString(crd, "City")) + " " + titolo;
				}
				
				ArrayList<String> images = null;
				try {
					JSONArray jsonImagesArr = ennesimo.getJSONArray("Immagini");
					images = processaImages(jsonImagesArr);
				} catch (Exception e) {
					// nessuna immagine
					
				}
				int persone = 0; 
				if (ennesimo.has("Persone")) {
					persone = ennesimo.getInt("Persone");
				}
				linkesterno = checkAsString(ennesimo, "LinkEsterno");
				String http = "http://";
				if (linkesterno.length() > 0) {
					linkesterno = linkesterno.startsWith(http) ? linkesterno : http + linkesterno;
				}

				double latitudine = 0;
				double longitudine = 0;
				if ((ennesimo.has("Dove")) && (ennesimo.getJSONObject("Dove").has("Geo"))) {
					JSONObject crd = ennesimo.getJSONObject("Dove").getJSONObject("Geo");
					latitudine = crd.getDouble("Latitude");
					longitudine = crd.getDouble("Longitude");
				}
				String testo = titolo + " " + xmlut.replaceHTMLWithAscii(checkAsString(ennesimo, "Testo"));
				
				// salvataggio
				ah.setCodutente(CODUTENTE);
				ah.setPref1(pref1);
				ah.setTelef1(telef1);
				ah.setTipoannuncio(images != null ? TIPOANNUNCIO : "NO");
				ah.setAttributi(ATTRIBUTO);
				ah.setTitolo(titolo);
				ah.setTesto(testo.length() >= 249 ? testo.substring(0, 249) : testo);
				//ah.setTipologiaimmobile(xmlut.normalizza(tipologiaimmobile));
				// ah.setMq(xmlut.normalizzaAsInt(superficie));
				// ah.setLocali(xmlut.normalizzaAsInt(locali));
				ah.setPostiletto(persone);
				ah.setLatitudine(latitudine);
				ah.setLongitudine(longitudine);
				// ah.setPrezzo(prezzo);
				ah.setAddinfo(testo);
				ah.setNumerofoto(images != null ? images.size() : 0);
				ah.setKr(RUBRICA);
				ah.setKu(KU);

				String annunciouid = DigestUtils.sha1Hex(ah.getPref1() + ah.getTelef1() + ah.getTesto() + ah.getTipologiaimmobile() + ah.getLatitudine() + ah.getLongitudine()
						+ ah.getAddinfo() + ah.getPrezzo() + ah.getNumerofoto());
				
				salvagestmediavacanze(imm_id, annunciouid, ah, images, linkesterno);

				// lo tolgo essendo stato processato
				if (listapresenti.contains(imm_id))
					listapresenti.remove(imm_id);

			}

			// processo cancellati
			if (!listapresenti.isEmpty()) {
				boolean primo = true;
				String perquery = "(";
				for (Iterator<String> i = listapresenti.iterator(); i.hasNext();) {
					String cid = (String) i.next();

					if (primo) {
						primo = false;
						perquery += "'" + cid + "'";
					} else {
						perquery += ",'" + cid + "'";
					}
				}
				perquery += ")";

				System.out.println("lista imm_id da rimuovere: " + perquery);

				System.out.println("aggiorno gli eliminati: ");
				dmannuncio.setSql("update gestmediavacanze set codiceoperazione = 'e' WHERE imm_id IN " + perquery);
				int r1 = dmannuncio.executeSql();

				String qw = "update annuncio set ke = 0, statoai = 'W', nf = 'X' "
						+ "WHERE ka IN "
						+ "(select ka from gestmediavacanze where imm_id in " + perquery + ") ";
				System.out.println("imposto W... ");
				System.out.println(qw);
				dmannuncio.setSql(qw);
				int r2 = dmannuncio.executeSql();
			}
			System.out.println("TOTALE ELEMENTI TROVATI NEL FILE: " + ct);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String checkAsString(JSONObject ennesimo, String string) {
		if (ennesimo.has(string)) {
			return ennesimo.getString(string);
		} else {
			return "";
		}
	}

	private static Set<String> generaListaPresenti() {
		Set<String> h = new HashSet<String>();

		String q = "SELECT imm_id FROM gestmediavacanze INNER JOIN annuncio on gestmediavacanze.ka = annuncio.ka WHERE gestmediavacanze.codiceoperazione != 'e';";
		try {
			dmannuncio.getList(q);
			while (dmannuncio.rsNext()) {
				h.add(dmannuncio.rsGetString("imm_id"));
			}
			dmannuncio.rsClose();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return h;
	}

	public static boolean cancellaTutteImmagini(DBWrapper dm, int ka) throws SQLException {
		dm.setSql("delete from images where ka=" + ka);
		return (dm.executeSql() > 0);
	}

	private static void inserisciTutteImmagini(int ka, ArrayList<String> images, String linkannuncio) {

		GestioneImmagini ga = new GestioneImmagini();
		for (int j = 0; j < images.size(); j++) {
			ga.saveImg(connimages, images.get(j), ka, linkannuncio);
		}
	}

	public static boolean salvagestmediavacanze(String imm_id, String sha1code, AnnuncioBean ah, ArrayList<String> images, String urlannuncio) throws SQLException {
		boolean rval = false;
		String db_annunciouid = "";
		int ka = 0;
		AnnuncioSaver annuncio = new AnnuncioSaver(dmannuncio);

		if (imm_id.length() > 0) {

			// se
			String qq = "SELECT * from gestmediavacanze WHERE imm_id = '" + imm_id + "'";
			dmannunciolettura.getList(qq);
			if (dmannunciolettura.rsNext()) {
				db_annunciouid = dmannunciolettura.rsGetString("annunciouid");
				ka = dmannunciolettura.rsGetInt("ka");
			}
			dmannunciolettura.rsClose();
			if (ka != 0) {
				ah.setKa(ka);
				// a questo punto se ho ka vuol dire che e' un update o un salto
				if (!db_annunciouid.equals(sha1code)) {

					// e devo aggiornare la data su gestannuncio
					String QOut = "update gestmediavacanze set codiceoperazione='a', annunciouid='" + sha1code + "' WHERE imm_id = '" + imm_id + "'";
					dmannunciolettura.setSql(QOut);
					rval = (dmannunciolettura.executeSql() > 0 ? true : false);

					if (rval) { // devo aggiornare il record su annuncio
						// ora posso aggiornare le immagini
						ah.setNumerofoto(images != null ? images.size() : 0);

						// prima cancello tutte le immagini
						cancellaTutteImmagini(dmannunciolettura, ka);
						if (images != null) {
							inserisciTutteImmagini(ka, images, urlannuncio);
						}

						// infine lo aggiorno!!!
						ah.setStatoai("W");
						annuncio.update(ah, ah.getCodutente());
						System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id : " + imm_id + " annunciouid: " + sha1code + " aggiornato!");
					}
				} else {
					// si tratta di un salto
					System.out.println("salto " + imm_id);

					String QOut = "update gestmediavacanze set codiceoperazione='c' WHERE imm_id = '" + imm_id + "'";
					dmannunciolettura.setSql(QOut);
					rval = (dmannunciolettura.executeSql() > 0 ? true : false);
				}
			} else {
				// in caso contrario non c'e' nessun record e lo devo inserire
				System.out.println("inserisco " + imm_id);
				ah.setNumerofoto(images != null ? images.size() : 0);
				ka = annuncio.save(ah);
				if (images != null) {
					inserisciTutteImmagini(ka, images, urlannuncio);
				}
				String QOut = "INSERT INTO gestmediavacanze (codiceoperazione, ka, imm_id, annunciouid) VALUES ('i', " + ka + ", '" + imm_id + "', '" + sha1code + "')";

				dmannunciolettura.setSql(QOut);
				rval = (dmannunciolettura.executeSql() > 0 ? true : false);

				System.out.println("\nka: " + ka + " kr: " + ah.getKr() + " id : " + imm_id + " annunciouid: " + sha1code);
			}
		}
		return rval;
	}

	private static ArrayList<String> processaImages(JSONArray jsonImagesArr) {
		ArrayList<String> ims = new ArrayList<String>();
		for (int imm = 0; imm < jsonImagesArr.length(); imm++) {
			ims.add(jsonImagesArr.getString(imm));
		}
		return ims;
	}

	public static BasicDataSource getDS(String poolname) {

		String mutex = "";
		synchronized (mutex) {

			BasicDataSource ds = null;
			try {
				ds = new BasicDataSource();

				ds.setMaxActive(350); // cambiato da 150 a 350 dopo aver messo i threads a 80
				ds.setMaxIdle(30); // aumentandolo dovrebbe diminuire il carico max ed aumentare quello medio
				ds.setMinIdle(10);

				ds.setDriverClassName("org.postgresql.Driver");
				System.out.println("getDS chiedo pool " + poolname);

				if (poolname.equals("dbppLOC")) {
					ds.setUsername("pepper");
					ds.setPassword("ciccio");
					ds.setUrl("jdbc:postgresql://localhost/portaportese?compatible=7.1");

				} else if (poolname.equals("dbppTEST")) {
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");
					ds.setUrl("jdbc:postgresql://188.166.194.166:5430/portaportese?compatible=7.1");

				} else if (poolname.equals("dbpp")) {
					System.out.println("Collegato a dbpp!");
					ds.setUsername("pepper");
					ds.setPassword("cia3s4t7e6f3a4n7o78jjkkklkldddEddyock");

					ds.setUrl("jdbc:postgresql://pp200.prv.lan/portaportese?compatible=7.1");
				}
			} catch (Exception e) {
				System.out.println("getDS chiedendo pool " + poolname + "\nEccezione: " + e.getMessage());
			}
			return ds;
		}
	}
}
