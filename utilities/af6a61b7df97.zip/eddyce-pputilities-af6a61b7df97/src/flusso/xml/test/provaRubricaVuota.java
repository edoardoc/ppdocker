package flusso.xml.test;

import java.io.IOException;
import java.sql.SQLException;

import flusso.xml.utils.FSystemNOSC;
import it.portaportese.system.PCValues;
import it.portaportese.utils.logging.Syslog;

public class provaRubricaVuota {
	private static PCValues Vpc;

	private static void initLRBR() {
		if (Vpc == null) {
			FSystemNOSC fs = new FSystemNOSC("init");
			Vpc = (PCValues) fs.load("initdata");
			Syslog.write("LISTA RUBRICHE LOCALE INIZIALIZZATA ..." + (Vpc.getListaRubriche().getRubrica("CD").getkr() == 56 ? " OK! " : ""));
		}
	}

	public static void main(String[] args) throws IOException, SQLException {
		initLRBR();

		System.out.println(Vpc.getListaRubriche().getRubrica("A2022").getkr());
	}

	
}
