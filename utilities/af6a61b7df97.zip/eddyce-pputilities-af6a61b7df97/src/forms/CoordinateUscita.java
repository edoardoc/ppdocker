package forms;

public class CoordinateUscita {
	public CoordinateUscita(int uscita, int annouscita) {
		super();
		this.uscita = uscita;
		this.annouscita = annouscita;
	}
	int	uscita = 0;
	int annouscita = 0;
	
	public int getUscita() {
		return uscita;
	}
	public void setUscita(int uscita) {
		this.uscita = uscita;
	}
	public int getAnnouscita() {
		return annouscita;
	}
	public void setAnnouscita(int annouscita) {
		this.annouscita = annouscita;
	}
}
