package forms;

public class EsistenzaAnnuncio {
	private boolean exists = false;
	private int ka = 0;
	
	public void setExists(boolean exists) {
		this.exists = exists;
	}
	public boolean isExists() {
		return exists;
	}
	public void setKa(int ka) {
		this.ka = ka;
	}
	public int getKa() {
		return ka;
	}
	
}
