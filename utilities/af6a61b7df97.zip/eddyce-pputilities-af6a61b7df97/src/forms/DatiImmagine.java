package forms;

public class DatiImmagine {
    String nome = "";

    String link = "";

    public DatiImmagine() {

        nome = "";
        link = "";
    }

    /**
     * @return Returns the link.
     */
    public String getLink() {
        return link;
    }

    /**
     * @param link
     *            The link to set.
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * @return Returns the nome.
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome
     *            The nome to set.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}