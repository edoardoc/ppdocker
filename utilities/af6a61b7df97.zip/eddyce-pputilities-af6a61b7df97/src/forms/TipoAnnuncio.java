/*
 * TipoAnnuncio.java forms - PPJR Created on Jul 8, 2005 
 *
 */
package forms;

import it.portaportese.system.Valuta;

import java.io.Serializable;

public class TipoAnnuncio implements Serializable {
    String codice="";
    String descrizione=""; 
    String spiegazione=""; 
    Valuta prezzo=null;
    Valuta prezzoaistantanei=null;

    /**
     * @param codice
     * @param descrizione
     * @param prezzo
     */
    public TipoAnnuncio(String codice, String descrizione, String spiegazione, double prezzo, double prezzoaistantanei) {
        this.codice=codice;
        this.descrizione=descrizione;
        this.spiegazione=spiegazione;
        this.prezzo = new Valuta(prezzo);
        this.prezzoaistantanei = new Valuta(prezzoaistantanei);
    }

    public String getCodice() {
        return codice;
    }
    public void setCodice(String codice) {
        this.codice = codice;
    }
    public String getDescrizione() {
        return descrizione;
    }
    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }
    public Valuta getPrezzo() {
        return prezzo;
    }
    
    public void setPrezzo(double prezzo) {
        this.prezzo.setValore(prezzo);
    }
    public void setPrezzo(Valuta prezzo) {
        this.prezzo = prezzo;
    }

    public String getSpiegazione() {
        return spiegazione;
    }

    public void setSpiegazione(String spiegazione) {
        this.spiegazione = spiegazione;
    }

	public Valuta getPrezzoaistantanei() {
		return prezzoaistantanei;
	}

	public void setPrezzoaistantanei(Valuta prezzoaistantanei) {
		this.prezzoaistantanei = prezzoaistantanei;
	}
}
