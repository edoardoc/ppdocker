package forms;

import java.io.Serializable;

public class Coord implements Serializable {
	private static final long serialVersionUID = 1057382052207775330L;
	private float latitudine = 0;
	private float longitudine = 0;
	
	public Coord() {
		super();
	}

	public Coord(float latitudine, float longitudine) {
		super();
		this.latitudine = latitudine;
		this.longitudine = longitudine;
	}

	public float getLatitudine() {
		return latitudine;
	}

	public void setLatitudine(float latitudine) {
		this.latitudine = latitudine;
	}

	public float getLongitudine() {
		return longitudine;
	}

	public void setLongitudine(float longitudine) {
		this.longitudine = longitudine;
	}
}
