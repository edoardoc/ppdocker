package forms;

public class Annuncio400Bean {

	private java.util.Date data = null;
	private java.util.Date dataprimoinserimento = null;
	private String testo = "";
	private String titolo = "";
	private String addinfo = "";
	private String immoviewer = "";
	private String telef1 = "";
	private String pref1 = "";
	private String telef2 = "";
	private String pref2 = "";
	private String rubric = "";
	private String tiprec = "";
	private String flagcp = "";
	private String url = "";
	private long oid = 0;
	private int giornouscita = 0;
	private int meseuscita = 0;
	private int annouscita = 0;
	private int numerofoto = 0;
	private String prezzo = "";
	private String annofabbr = "";
	private int locali = 0;
	private int uscita = 0;
	private String email = "";
	private String codedi = "";
	private int codcliente = 0;
	private int ka = 0;
	private String tipoannuncio = "";
	private String attributi = "";
	private int videostatus = 0;
	private int videofrom = 0;
	private String videolink = "";
	private String videodir = "";
	private String modello = "";
	private String tipo = "";
	private String km = "";
	private String gmap = "";
	private String tipologiaimmobile = "";
	
	
	private double latitudine = 0;
	private double longitudine = 0;
	private String M2 = "";
	private String PL = "";
	private boolean  VLL;
	private boolean  GRD;
	private boolean  PSC;
	private boolean  CMN;
	private boolean  TRZ;
	private boolean  BLC;
	private boolean  PSA;
	private boolean  ATT;
	private boolean  PAL;
	private boolean  PBS;
	private boolean  RST;
	private boolean  LIB;
	private boolean  OCC;
	private boolean  RSA;
	private boolean  SFC;
	private boolean  UUF;
	private boolean  NET;
	private boolean  CLL;
	private boolean  ACN;
	private boolean  ARD;	// ... 2nda battuta
	private boolean  APT;
	private boolean  CSL;
	private boolean  EDF;
	private boolean  AGR;
	private boolean  CPN;
	private boolean  CMM;
	private boolean  DRS;
	private boolean  MGZ;
	private boolean  LBR;
	
	private String FA = "";	// 3za battuta
	private String FB = "";
	private boolean F01;
	private boolean F02;
	private boolean F03;
	private boolean F04;
	private boolean F05;
	private boolean F06;
	private boolean F07;
	private boolean F08;
	private boolean F09;
	private boolean F10;
	private boolean F11;
	private boolean F12;
	private boolean F13;
	private boolean F14;
	private boolean F15;
	private boolean F16;
	private boolean F17;
	private boolean F18;
	private boolean F19;
	private boolean F20;
	
	
	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getKm() {
		return km;
	}

	public void setKm(String km) {
		this.km = km;
	}

	public String getGmap() {
		return gmap;
	}

	public void setGmap(String gmap) {
		this.gmap = gmap;
	}

	public String getFlagcp() {
		return flagcp;
	}

	public void setFlagcp(String flagcp) {
		this.flagcp = flagcp;
	}

	public String getAnnofabbr() {
		return annofabbr;
	}

	public int getAnnouscita() {
		return annouscita;
	}

	public String getCodedi() {
		return codedi;
	}

	public int getGiornouscita() {
		return giornouscita;
	}

	public int getLocali() {
		return locali;
	}

	public int getMeseuscita() {
		return meseuscita;
	}

	public String getPref1() {
		return pref1;
	}

	public String getPref2() {
		return pref2;
	}

	public double getPrezzoAsDouble() {
		try {
			return Double.parseDouble(prezzo);
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	public String getPrezzo() {
		return prezzo.trim();
	}
	public String getRubric() {
		return rubric;
	}

	public String getTelef1() {
		return telef1;
	}

	public String getTelef2() {
		return telef2;
	}

	public String getTipoannuncio() {
		return tipoannuncio;
	}

	public int getUscita() {
		return uscita;
	}

	public void setAnnofabbr(String annofabbr) {
		this.annofabbr = annofabbr;
	}

	public void setAnnouscita(String annouscita) {
		try {
			this.annouscita = Integer.parseInt(annouscita.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setCodcliente(String codcliente) {
		try {
			this.codcliente = Integer.parseInt(codcliente.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setCodedi(String codedi) {
		this.codedi = codedi;
	}

	public void setGiornouscita(String giornouscita) {
		try {
			this.giornouscita = Integer.parseInt(giornouscita.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setLocali(String locali) {
		try {
			this.locali = Integer.parseInt(locali.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setMeseuscita(String meseuscita) {
		try {
			this.meseuscita = Integer.parseInt(meseuscita.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}

	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}

	public void setPrezzo(String prezzo) {
		this.prezzo = prezzo;
	}

	public void setRubric(String rubric) {
		this.rubric = rubric;
	}

	public void setTelef1(String telef1) {
		this.telef1 = telef1;
	}

	public void setTelef2(String telef2) {
		this.telef2 = telef2;
	}

	public void setTipoannuncio(String tipoannuncio) {
		this.tipoannuncio = tipoannuncio;
	}

	public void setUscita(String uscita) {

		try {
			this.uscita = Integer.parseInt(uscita.trim());
		} catch (NumberFormatException e) {
		}

	}

	public String getTesto() {
		return testo;
	}

	public void setTesto(String testo) {
		this.testo = testo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void reset() {
		data = new java.util.Date();	// preimposto ad ora, sempre!
		testo = "";
		addinfo = "";
		telef1 = "";
		pref1 = "";
		telef2 = "";
		pref2 = "";
		rubric = "";
		tiprec = "";
		flagcp = "";
		url = "";
		oid = 0;
		giornouscita = 0;
		meseuscita = 0;
		annouscita = 0;
		numerofoto = 0;
		prezzo = "";
		annofabbr = "";
		locali = 0;
		uscita = 0;
		email = "";
		codedi = "";
		codcliente = 0;
		ka = 0;
		tipoannuncio = "";
		attributi = "AL";
		videostatus = 0;
		videofrom = 0;
		videolink = "";
		videodir = "";
		modello = "";
		tipo = "";
		km = "";
		gmap = "";
		tipologiaimmobile = "";
		
		
		latitudine = 0;
		longitudine = 0;
		M2 = "";
		PL = "";
		FA = "";	// 3za battuta
		FB = "";

		VLL = false;
		GRD = false;
		PSC = false;
		CMN = false;
		TRZ = false;
		BLC = false;
		PSA = false;
		ATT = false;
		PAL = false;
		PBS = false;
		RST = false;
		LIB = false;
		OCC = false;
		RSA = false;
		SFC = false;
		UUF = false;
		NET = false;
		CLL = false;
		ACN = false;
		ARD = false;	// ... 2nda battuta
		APT = false;
		CSL = false;
		EDF = false;
		AGR = false;
		CPN = false;
		CMM = false;
		DRS = false;
		MGZ = false;
		LBR = false;
		
		F01 = false;
		F02 = false;
		F03 = false;
		F04 = false;
		F05 = false;
		F06 = false;
		F07 = false;
		F08 = false;
		F09 = false;
		F10 = false;
		F11 = false;
		F12 = false;
		F13 = false;
		F14 = false;
		F15 = false;
		F16 = false;
		F17 = false;
		F18 = false;
		F19 = false;
		F20 = false;		
	}

	public String toString() {
        return testo + "\n" +
        pref1 + "\n" +
        telef1 + "\n" +
        pref2 + "\n" +
        telef2 + "\n" +
        rubric + "\n" +
        giornouscita  + "\n" +
        meseuscita  + "\n" +
        annouscita  + "\n" +
        prezzo  + "\n" +
        annofabbr  + "\n" +
        locali  + "\n" +
        uscita  + "\n" +
        email  + "\n" +
        codedi  + "\n" +
        codcliente  + "\n" +
        tipoannuncio  + "\n" +
        tiprec  + "\n" +
        ka + "\n";
    }

    public String getTiprec() {
		return tiprec;
	}

	public void setTiprec(String tiprec) {
		this.tiprec = tiprec;
	}

	public void setCodcliente(int i) {
		codcliente = i;
	}

	public int getCodcliente() {
		return codcliente;
	}

	public long getOid() {
		return oid;
	}

	public void setOid(long i) {
		oid = i;
	}

	public int getKa() {
		return ka;
	}
	public void setKa(int i) {
		this.ka = i;
	}

	public void setKa(String i) {
		try {
			this.ka = Integer.parseInt(i.trim());
		} catch (NumberFormatException e) {
		}
	}

	public void setNumerofoto(int numerofoto) {
		this.numerofoto = numerofoto;
	}

	public int getNumerofoto() {
		return numerofoto;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}
	public String getVideolink() {
		return videolink;
	}

	public void setVideolink(String videolink) {
		this.videolink = videolink;
	}

	public int getVideostatus() {
		return videostatus;
	}

	public void setVideostatus(int videostatus) {
		this.videostatus = videostatus;
	}

	public int getVideofrom() {
		return videofrom;
	}

	public void setVideofrom(int videofrom) {
		this.videofrom = videofrom;
	}

	public String getVideodir() {
		return videodir;
	}

	public void setVideodir(String videodir) {
		this.videodir = videodir;
	}

	public double getLatitudine() {
		return latitudine;
	}

	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}

	public double getLongitudine() {
		return longitudine;
	}

	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}

	public String getAttributi() {
		return attributi;
	}

	public void setAttributi(String attributi) {
		this.attributi = attributi;
	}

	public String getM2() {
		return M2;
	}

	public String getPL() {
		return PL;
	}

	public void setPL(String pL) {
		PL = pL;
	}

	public void setM2(String m2) {
		M2 = m2;
	}

	public void setVLL(boolean vLL) {
		VLL = vLL;
	}

	public void setGRD(boolean gRD) {
		GRD = gRD;
	}

	public void setPSC(boolean pSC) {
		PSC = pSC;
	}

	public void setCMN(boolean cMN) {
		CMN = cMN;
	}

	public void setTRZ(boolean tRZ) {
		TRZ = tRZ;
	}

	public void setBLC(boolean bLC) {
		BLC = bLC;
	}

	public void setPSA(boolean pSA) {
		PSA = pSA;
	}

	public void setATT(boolean aTT) {
		ATT = aTT;
	}

	public void setPAL(boolean pAL) {
		PAL = pAL;
	}

	public void setPBS(boolean pBS) {
		PBS = pBS;
	}

	public void setRST(boolean rST) {
		RST = rST;
	}

	public void setLIB(boolean lIB) {
		LIB = lIB;
	}

	public void setOCC(boolean oCC) {
		OCC = oCC;
	}

	public void setRSA(boolean rSA) {
		RSA = rSA;
	}

	public void setSFC(boolean sFC) {
		SFC = sFC;
	}

	public void setUUF(boolean uUF) {
		UUF = uUF;
	}

	public void setNET(boolean nET) {
		NET = nET;
	}

	public void setCLL(boolean cLL) {
		CLL = cLL;
	}

	public void setACN(boolean aCN) {
		ACN = aCN;
	}

	public void setARD(boolean aRD) {
		ARD = aRD;
	}

	public void setAPT(boolean aPT) {
		APT = aPT;
	}

	public void setCSL(boolean cSL) {
		CSL = cSL;
	}

	public void setEDF(boolean eDF) {
		EDF = eDF;
	}

	public void setAGR(boolean aGR) {
		AGR = aGR;
	}

	public void setCPN(boolean cPN) {
		CPN = cPN;
	}

	public void setCMM(boolean cMM) {
		CMM = cMM;
	}

	public void setDRS(boolean dRS) {
		DRS = dRS;
	}

	public void setMGZ(boolean mGZ) {
		MGZ = mGZ;
	}

	public void setLBR(boolean lBR) {
		LBR = lBR;
	}

	public String getFA() {
		return FA;
	}

	public String getFB() {
		return FB;
	}

	public void setFA(String fA) {
		FA = fA;
	}

	public void setFB(String fB) {
		FB = fB;
	}

	public void setF01(boolean f01) {
		F01 = f01;
	}

	public void setF02(boolean f02) {
		F02 = f02;
	}

	public void setF03(boolean f03) {
		F03 = f03;
	}

	public void setF04(boolean f04) {
		F04 = f04;
	}

	public void setF05(boolean f05) {
		F05 = f05;
	}

	public void setF06(boolean f06) {
		F06 = f06;
	}

	public void setF07(boolean f07) {
		F07 = f07;
	}

	public void setF08(boolean f08) {
		F08 = f08;
	}

	public void setF09(boolean f09) {
		F09 = f09;
	}

	public void setF10(boolean f10) {
		F10 = f10;
	}

	public void setF11(boolean f11) {
		F11 = f11;
	}

	public void setF12(boolean f12) {
		F12 = f12;
	}

	public void setF13(boolean f13) {
		F13 = f13;
	}

	public void setF14(boolean f14) {
		F14 = f14;
	}

	public void setF15(boolean f15) {
		F15 = f15;
	}

	public void setF16(boolean f16) {
		F16 = f16;
	}

	public void setF17(boolean f17) {
		F17 = f17;
	}

	public void setF18(boolean f18) {
		F18 = f18;
	}

	public void setF19(boolean f19) {
		F19 = f19;
	}

	public void setF20(boolean f20) {
		F20 = f20;
	}

	public String sVLL() {
		return (VLL ? "true" : "false");
	}

	public String sGRD() {
		return (GRD ? "true" : "false");
	}

	public String sPSC() {
		return (PSC ? "true" : "false");
	}

	public String sCMN() {
		return (CMN ? "true" : "false");
	}

	public String sTRZ() {
		return (TRZ ? "true" : "false");
	}

	public String sBLC() {
		return (BLC ? "true" : "false");
	}

	public String sPSA() {
		return (PSA ? "true" : "false");
	}

	public String sATT() {
		return (ATT ? "true" : "false");
	}

	public String sPAL() {
		return (PAL ? "true" : "false");
	}

	public String sPBS() {
		return (PBS ? "true" : "false");
	}

	public String sRST() {
		return (RST ? "true" : "false");
	}

	public String sLIB() {
		return (LIB ? "true" : "false");
	}

	public String sOCC() {
		return (OCC ? "true" : "false");
	}

	public String sRSA() {
		return (RSA ? "true" : "false");
	}

	public String sSFC() {
		return (SFC ? "true" : "false");
	}

	public String sUUF() {
		return (UUF ? "true" : "false");
	}

	public String sNET() {
		return (NET ? "true" : "false");
	}

	public String sCLL() {
		return (CLL ? "true" : "false");
	}

	public String sACN() {
		return (ACN ? "true" : "false");
	}

	public String sARD() {
		return (ARD ? "true" : "false");
	}
	
	public String sAPT() {
		return (APT ? "true" : "false");
	}
	
	public String sCSL() {
		return (CSL ? "true" : "false");
	}
	
	public String sEDF() {
		return (EDF ? "true" : "false");
	}
	
	public String sAGR() {
		return (AGR ? "true" : "false");
	}
	
	public String sCPN() {
		return (CPN ? "true" : "false");
	}
	
	public String sCMM() {
		return (CMM ? "true" : "false");
	}
	
	public String sDRS() {
		return (DRS ? "true" : "false");
	}
	
	public String sMGZ() {
		return (MGZ ? "true" : "false");
	}
	
	public String sLBR() {
		return (LBR ? "true" : "false");
	}

	public String sF01() {
		return (F01 ? "true" : "false");
	}

	public String sF02() {
		return (F02 ? "true" : "false");
	}

	public String sF03() {
		return (F03 ? "true" : "false");
	}

	public String sF04() {
		return (F04 ? "true" : "false");
	}

	public String sF05() {
		return (F05 ? "true" : "false");
	}

	public String sF06() {
		return (F06 ? "true" : "false");
	}

	public String sF07() {
		return (F07 ? "true" : "false");
	}

	public String sF08() {
		return (F08 ? "true" : "false");
	}

	public String sF09() {
		return (F09 ? "true" : "false");
	}

	public String sF10() {
		return (F10 ? "true" : "false");
	}

	public String sF11() {
		return (F11 ? "true" : "false");
	}

	public String sF12() {
		return (F12 ? "true" : "false");
	}

	public String sF13() {
		return (F13 ? "true" : "false");
	}

	public String sF14() {
		return (F14 ? "true" : "false");
	}

	public String sF15() {
		return (F15 ? "true" : "false");
	}

	public String sF16() {
		return (F16 ? "true" : "false");
	}

	public String sF17() {
		return (F17 ? "true" : "false");
	}

	public String sF18() {
		return (F18 ? "true" : "false");
	}

	public String sF19() {
		return (F19 ? "true" : "false");
	}

	public String sF20() {
		return (F20 ? "true" : "false");
	}

	public String getTipologiaimmobile() {
		return tipologiaimmobile;
	}

	public void setTipologiaimmobile(String tipologiaimmobile) {
		this.tipologiaimmobile = tipologiaimmobile;
	}

	public java.util.Date getData() {
		return data;
	}

	public void setData(java.util.Date data) {
		this.data = data;
	}

	public String getAddinfo() {
		return addinfo;
	}

	public void setAddinfo(String addinfo) {
		this.addinfo = addinfo;
	}

	public java.util.Date getDataprimoinserimento() {
		return dataprimoinserimento;
	}

	public void setDataprimoinserimento(java.util.Date dataprimoinserimento) {
		this.dataprimoinserimento = dataprimoinserimento;
	}

	public String getImmoviewer() {
		return immoviewer;
	}

	public void setImmoviewer(String immoviewer) {
		this.immoviewer = immoviewer;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
}