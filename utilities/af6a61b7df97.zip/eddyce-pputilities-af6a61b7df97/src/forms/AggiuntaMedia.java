package forms;

/* semplice classe per trasferire numero delle foto ed url dalla 
 * tabella images
 */
public class AggiuntaMedia {
	int numerofoto = 0;
	String url = "";
	
	public int getNumerofoto() {
		return numerofoto;
	}
	public void setNumerofoto(int numerofoto) {
		this.numerofoto = numerofoto;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	

}
