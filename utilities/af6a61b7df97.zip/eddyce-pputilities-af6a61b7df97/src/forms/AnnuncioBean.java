package forms;

import gestione.utils;
import gestione.rubriche.Listarubriche;
import it.portaportese.utils.Strings;
import it.portaportese.utils.functions;
import it.portaportese.utils.logging.Syslog;

import java.util.Hashtable;


public class AnnuncioBean {
	private int codutente = 0;
	private java.util.Date data = null;
	private java.util.Date dataprimoinserimento = null;
	private String pubblicaemail = "";
	private String annunciosenzatel = "";
	private String tipo = "o"; // DEFAULT offerta (o)
	private String tipoace = "";	
	private int ka = 0;
	private int kaprovenienza = 0;
	private int ke = 0;
	private int kr = 0;
	private int kroriginale = 0;
	private int ku = 0;
	private int numerofoto = 0;
	private String titolo = "";
	private String addinfo = "";
	private String immoviewer = "";
	private String telef1 = "";
	private String pref1 = "";
	private String telef2 = "";
	private String pref2 = "";
	private String testo = "";
	private String tiprec = "";
	private String nf = "";
	private String statoai = "";
	private String ipimmissione = "";
	private String tipoannuncio = "NO";
	private String attributi = "";
	private boolean corretto = false;
	private String tipoannuncioprecedente = "NO";
	private String descrizionerubrica = "";
	private int videostatus = 0;
	private int videofrom = 0;
	private String videolink = "";
	private String videodir = "";
	private boolean permodifica = false;
	private Hashtable errors;
	private int selectbox1 = 0;
	private int selectbox2 = 0;
	private int selectbox3 = 0;
	private double latitudine = 0;
	private double longitudine = 0;

	private String alimentazione = "";
	private String tipologiaimmobile = "";
	private String modello = "";
	private String prezzo = "";
	private int locali = 0;
	private int postiletto = 0;
	private int mq = 0;
	private int km = 0;
	private int anno = 0;
	
	public AnnuncioBean() {
		errors = new Hashtable();
	}
	public int getKaprovenienza() {
		return kaprovenienza;
	}
	public void setKaprovenienza(int kaprovenienza) {
		this.kaprovenienza = kaprovenienza;
	}
	public int getNumerofoto() {
		return numerofoto;
	}
	public void setNumerofoto(int numerofoto) {
		this.numerofoto = numerofoto;
	}
	public String getErrorMsg(String s, String out) {
		String errorMsg = (String) errors.get(s.trim());
		return (errorMsg == null)
			? ""
			: ((errorMsg.equals("err"))
				? out : errorMsg);
	}
	public void setErrors(String key, String msg) {
		errors.put(key, msg);
	}
    public boolean hasErrors() {
        return !errors.isEmpty();
    }
	public void setCombos(Listarubriche lrbr) {
		if ((selectbox1 == 0) && (getKr() != 0)) {
			// vuol dire che il bean ha il kr
			// dobbiamo aggiungere alla policy la scelta sul terzo combo
			
			int padredikr =  lrbr.getPadre(getKr());
			int padredipadredikr =  lrbr.getPadre(padredikr);
			int padredipadredipadredikr =  lrbr.getPadre(padredipadredikr);	// dovrebbe valere 10000 in caso di 3 combo
			
			if (padredipadredipadredikr == 10000) {
				selectbox3=kr;
				selectbox2=padredikr;
				selectbox1=padredipadredikr;
			} else if (padredipadredikr == 10000) {
				selectbox2=getKr();
				selectbox1=padredikr;
			} else {
				selectbox1=getKr();
			}
		} else if ((selectbox1 == 0) && (selectbox2 == 0)) {
			// ???
			
			selectbox1=1000;
		}
	}

	public int getCodutente() {
		return codutente;
	}

	public java.util.Date getData() {
		return data;
	}
	public String getDBdata() {
		return functions.dateFormatter(data, "dd/MM/yyyy HH:mm:ss");
	}
	public String getTextdata() {
		return functions.dateFormatter(data, "dd/MM/yyyy");
	}
	
	
	public String getPref1() {
		return pref1;
	}

	public String getPref2() {
		return pref2;
	}

	public String getDBpubblicaemail() {
		return (!pubblicaemail.equals("") ? "true" : "false");
	}
	public String getFRMpubblicaemail() {
		return (!pubblicaemail.equals("") ? "checked" : "");
	}
	public String getDBannunciosenzatel() {
		return (!annunciosenzatel.equals("") ? "true" : "false");
	}
	public String getFRMannunciosenzatel() {
		return (!annunciosenzatel.equals("") ? "checked" : "");
	}
	public String getAnnunciosenzatel() {
		return annunciosenzatel;
	}
	public void setAnnunciosenzatel(String annunciosenzatel) {
		this.annunciosenzatel = annunciosenzatel;
	}
	public String getTelef1() {
		return telef1;
	}

	public String getTelef2() {
		return telef2;
	}

	public String getTesto() {
		return testo;
	}

	public String getTipo() {
		return tipo;
	}
    
	public void setCodutente(int codutente) {
		this.codutente = codutente;
	}

	public void setData(java.util.Date data) {
		this.data = data;
	}

	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}

	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}

	public void setTelef1(String telef1) {
		this.telef1 = telef1;
	}

	public void setTelef2(String telef2) {
		this.telef2 = telef2;
	}

	public void setTesto(String testo) {
		this.testo = testo.trim();
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getKr() {
		return kr;
	}

	public void setKr(int kr) {
		this.kr = kr;
	}

	public String getDescrizionerubrica() {
		return descrizionerubrica;
	}

	public void setDescrizionerubrica(String descrizionerubrica) {
		this.descrizionerubrica = descrizionerubrica;
	}

	public String getPubblicaemail() {
		return pubblicaemail;
	}

	public void setPubblicaemail(String pubblicaemail) {
		this.pubblicaemail = pubblicaemail;
	}

	public int getKa() {
		return ka;
	}

	public void setKa(int i) {
		ka = i;
	}

	public int getKu() {
		return ku;
	}

	public void setKu(int i) {
		ku = i;
	}

	public int getKe() {
		return ke;
	}

	public void setKe(int i) {
		ke = i;
	}

	public boolean isPermodifica() {
		return permodifica;
	}

	public void setPermodifica(boolean b) {
		permodifica = b;
	}

	public String getNf() {
		return nf;
	}

	public String getTipoannuncio() {
		return tipoannuncio;
	}
	
	public String getTiprec() {
		return tiprec;
	}

	public void setNf(String string) {
		nf = string;
	}

	public void setTipoannuncio(String string) {
		tipoannuncio = string;
	} 

	public void setTiprec(String string) {
		tiprec = string;
	}
	public int getSelectbox1() {
		return selectbox1;
	}
	public void setSelectbox1(int selectbox1) {
		this.selectbox1 = selectbox1;
	}
	public int getSelectbox2() {
		return selectbox2;
	}
	public void setSelectbox2(int selectbox2) {
		this.selectbox2 = selectbox2;
	}
	public int getSelectbox3() {
		return selectbox3;
	}
	public void setSelectbox3(int selectbox3) {
		this.selectbox3 = selectbox3;
	}
	/*
	 * mi dice se posso impostare il kr dalle select con valore
	 */
	public boolean detectKrfromselect(Listarubriche lrbr, int status) {
		if (tipo.equals("r")) {
			// logica diversa se e' una richiesta
			if (lrbr.isRubricaFoglia(getSelectbox2(), 0)) {
				setKr(getSelectbox2());
				return true;
			} else if (lrbr.isRubricaFoglia(getSelectbox1(), status)) {
				setKr(getSelectbox1());
				return true;
			} else {
				return false;
			}
		} else {
			if ((status >= 1) && (getSelectbox3() != -1) && (lrbr.isRubricaFoglia(getSelectbox3(), status))) {
				// vuol dire che la terza e' una foglia,
				setKr(getSelectbox3());
				return true;
			} else if (((getSelectbox2() == 38) || (getSelectbox2() == 35) || (getSelectbox2() == 36)) && (getSelectbox3() != -1) && (lrbr.isRubricaFoglia(getSelectbox3(), 1))) {
				// vuol dire che la terza e' una foglia, caso delle marche auto
				setKr(getSelectbox3());
				return true;
			} else if ((getSelectbox2() != -1) && (lrbr.isRubricaFoglia(getSelectbox2(), status))) {	// QUESTA!!
				// vuol dire che la seconda e' una foglia,
				setKr(getSelectbox2());
				return true;
			} else if (lrbr.isRubricaFoglia(getSelectbox1(), status)) {
				// vuol dire che la prima e' una foglia,
				setKr(getSelectbox1());
				return true;
			} else {
				// non ci sono foglie selezionate, e' una selezione incompleta
				// Syslog.write("INCOMPLETA per getSelectbox1 " + getSelectbox1() + " getSelectbox2 = " + getSelectbox2() + " getSelectbox3 = " + getSelectbox3() + " status = " + status);
				return false;
			}
		}
	}
	public void setIpimmissione(String remoteAddr) {
		this.ipimmissione = remoteAddr;
	}
	public String getIpimmissione() {
		return ipimmissione;
	}
	public String getTipoannuncioprecedente() {
		return tipoannuncioprecedente;
	}
	public void setTipoannuncioprecedente(String tipoannuncioprecedente) {
		this.tipoannuncioprecedente = tipoannuncioprecedente;
	}
    public String getTipofordb() {
        // la seguente distinzione serve perche' alcuni browser
        // salvano il nome del campo e non lo stato (se non viene cambiato)
        
        if (tipo.length() ==1) {
            return tipo;
        } else {
            if (tipo.equals("offerta"))
                return "o";
            else
                return "r";
        }
        
    }
	public int getKroriginale() {
		return kroriginale;
	}
	public void setKroriginale(int kroriginale) {
		this.kroriginale = kroriginale;
	}
	public int getVideostatus() {
		return videostatus;
	}
	public void setVideostatus(int videostatus) {
		this.videostatus = videostatus;
	}
	public int getVideofrom() {
		return videofrom;
	}
	public void setVideofrom(int videofrom) {
		this.videofrom = videofrom;
	}
	public String getVideolink() {
		return videolink;
	}
	public void setVideolink(String videolink) {
		this.videolink = videolink;
	}
	public String getVideodir() {
		return videodir;
	}
	public void setVideodir(String videodir) {
		this.videodir = videodir;
	}
	public Hashtable getErrors() {
		return errors;
	}
	public double getLatitudine() {
		return latitudine;
	}
	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}
	public double getLongitudine() {
		return longitudine;
	}
	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}
	public String getTipoace() {
		return tipoace;
	}
	public void setTipoace(String tipoace) {
		this.tipoace = tipoace;
	}
	public String getAttributi() {
		return attributi;
	}
	public void setAttributi(String attributi) {
		this.attributi = attributi;
	}
	public boolean isCorretto() {
		return corretto;
	}
	public void setCorretto(boolean corretto) {
		this.corretto = corretto;
	}
	public boolean isAttributoadsistantaneo() {
		return attributi.equals("AI");
	}
	public String getStatoai() {
		return statoai;
	}
	public void setStatoai(String statoai) {
		this.statoai = statoai;
	}
	public String getAlimentazione() {
		return alimentazione;
	}
	public void setAlimentazione(String alimentazione) {
		this.alimentazione = alimentazione;
	}
	public String getModello() {
		return modello;
	}
	public void setModello(String modello) {
		this.modello = modello;
	}
	public String getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(String prezzo) {
		this.prezzo = prezzo;
	}
	public int getLocali() {
		return locali;
	}
	public void setLocali(int locali) {
		this.locali = locali;
	}
	public int getMq() {
		return mq;
	}
	public void setMq(int mq) {
		this.mq = mq;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public int getAnno() {
		return anno;
	}
	public void setAnno(int anno) {
		this.anno = anno;
	}
	public int getPostiletto() {
		return postiletto;
	}
	public void setPostiletto(int postiletto) {
		this.postiletto = postiletto;
	}
	public String getTipologiaimmobile() {
		return tipologiaimmobile;
	}
	public void setTipologiaimmobile(String tipologiaimmobile) {
		this.tipologiaimmobile = tipologiaimmobile;
	}
	public String getAddinfo() {
		return addinfo;
	}
	public void setAddinfo(String addinfo) {
		this.addinfo = addinfo;
	}
	public java.util.Date getDataprimoinserimento() {
		return dataprimoinserimento;
	}
	public void setDataprimoinserimento(java.util.Date dataprimoinserimento) {
		this.dataprimoinserimento = dataprimoinserimento;
	}
	public String getImmoviewer() {
		return immoviewer;
	}
	public void setImmoviewer(String immoviewer) {
		this.immoviewer = immoviewer;
	}
	public String getTitolo() {
		return titolo;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
}
