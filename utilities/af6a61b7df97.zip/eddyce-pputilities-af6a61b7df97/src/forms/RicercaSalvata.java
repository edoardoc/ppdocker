package forms;

import java.util.Date;

public class RicercaSalvata {
	int codutente = 0;
	String titolo = "";
	String url = "";
	String note = "";
	int kr = 0;
	java.util.Date data = null;
	private long oid = 0;
	
	public String getTitolo() {
		return titolo;
	}
	public String getUrl() {
		return url;
	}
	public String getNote() {
		return note;
	}
	public Date getData() {
		return data;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getKr() {
		return kr;
	}
	public void setKr(int kr) {
		this.kr = kr;
	}
	public int getCodutente() {
		return codutente;
	}
	public void setCodutente(int codutente) {
		this.codutente = codutente;
	}
	public long getOid() {
		return oid;
	}
	public void setOid(long oid) {
		this.oid = oid;
	}
}
