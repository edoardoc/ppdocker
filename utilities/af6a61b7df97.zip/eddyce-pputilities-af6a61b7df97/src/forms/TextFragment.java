package forms;

public class TextFragment {
	private String parteevidenziata = "";
	private String linkfinale = "";
	private String text = "";
	private String partenonevid = "";
	private String titololungo = "";
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getParteevidenziata() {
		return parteevidenziata;
	}
	public void setParteevidenziata(String parteevidenziata) {
		this.parteevidenziata = parteevidenziata;
	}
	public String getLinkfinale() {
		return linkfinale;
	}
	public void setLinkfinale(String linkfinale) {
		this.linkfinale = linkfinale;
	}
	public String getPartenonevid() {
		return partenonevid;
	}
	public void setPartenonevid(String partenonevid) {
		this.partenonevid = partenonevid;
	}
	public String getTitololungo() {
		return titololungo;
	}
	public void setTitololungo(String titololungo) {
		this.titololungo = titololungo;
	}
	
}
