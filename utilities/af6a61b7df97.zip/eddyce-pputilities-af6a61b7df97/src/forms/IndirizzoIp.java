/*
 * IndirizzoIp.java gestione.blocchi - PPJR Created on 25-mar-2006 
 *
 */
package forms;

import it.portaportese.utils.functions;

import java.util.Date;

public class IndirizzoIp {
    
    private String ipaddress = "";
    private long tpq = 0;
    private long tuq = 0;
    private int kum = 0;
    private int kr = 0;
    
    private boolean bloccato = false;

    public IndirizzoIp() {
        tpq=System.currentTimeMillis();
        tuq=System.currentTimeMillis();
        kum=1;
        bloccato=false;
    }

    public boolean isBloccato() {
        return bloccato;
    }

    public void setBloccato(boolean bloccato) {
        this.bloccato = bloccato;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public int getKum() {
        return kum;
    }

    public void setKum(int kum) {
        this.kum = kum;
    }

    public long getTpq() {
        return tpq;
    }

    public void setTpq(long tpq) {
        this.tpq = tpq;
    }

    public long getTuq() {
        return tuq;
    }

    public void setTuq(long tuq) {
        this.tuq = tuq;
    }

    public String toString() {
        return getIpaddress() + "\t\t" 
                + functions.dateFormatter((new Date(getTpq())), "dd/MM/yyyy HH:mm:ss") + "\t\t"
                + functions.dateFormatter((new Date(getTuq())), "dd/MM/yyyy HH:mm:ss") + "\t\t"
                + getKum() + "\t\t"
                + isBloccato();
    }

    public int getKr() {
        return kr;
    }

    public void setKr(int kr) {
        this.kr = kr;
    }
}
