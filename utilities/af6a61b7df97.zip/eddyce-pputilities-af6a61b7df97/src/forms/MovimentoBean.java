/*
 * Created on Jun 7, 2005
 *
 */
package forms;

public class MovimentoBean {

    private String fieldname="";
    private String codicetransazione="";
    private String sessione="";
    private int codiceutente = 0;
    private int ka = 0;
    private double valore = 0;
    private java.util.Date data = null;
    private int numerofattura = 0;
    private int anno = 0;
    private boolean flagcontabilizzato = false;
    
    public String getFieldname() {
        return fieldname;
    }
    public void setFieldname(String fieldname) {
        this.fieldname = fieldname;
    }
    public int getAnno() {
        return anno;
    }
    public void setAnno(int anno) {
        this.anno = anno;
    }
    public String getCodicetransazione() {
        return codicetransazione;
    }
    public void setCodicetransazione(String codicetransazione) {
        this.codicetransazione = codicetransazione;
    }
    public int getCodiceutente() {
        return codiceutente;
    }
    public void setCodiceutente(int codiceutente) {
        this.codiceutente = codiceutente;
    }
    public java.util.Date getData() {
        return data;
    }
    public void setData(java.util.Date data) {
        this.data = data;
    }
    public boolean isFlagcontabilizzato() {
        return flagcontabilizzato;
    }
    public void setFlagcontabilizzato(boolean flagcontabilizzato) {
        this.flagcontabilizzato = flagcontabilizzato;
    }
    public int getKa() {
        return ka;
    }
    public void setKa(int ka) {
        this.ka = ka;
    }
    public int getNumerofattura() {
        return numerofattura;
    }
    public void setNumerofattura(int numerofattura) {
        this.numerofattura = numerofattura;
    }
    public double getValore() {
        return valore;
    }
    public void setValore(double valore) {
        this.valore = valore;
    }
    public void reset() {
        codicetransazione="";
        codiceutente = 0;
        ka = 0;
        valore = 0;
        data = null;
        numerofattura = 0;
        flagcontabilizzato = false;
    }
    public String getSessione() {
        return sessione;
    }
    public void setSessione(String sessione) {
        this.sessione = sessione;
    }
}
