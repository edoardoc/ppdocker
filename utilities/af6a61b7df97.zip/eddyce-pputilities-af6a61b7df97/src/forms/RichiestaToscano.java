package forms;

public class RichiestaToscano {

	private java.lang.String nome;
	private java.lang.String cognome;
	private java.lang.String email;
	private java.lang.String telefono;
	private java.lang.String idimmobile;
	private java.lang.String messaggio;

	public java.lang.String getNome() {
		return nome;
	}

	public void setNome(java.lang.String nome) {
		this.nome = nome;
	}

	public java.lang.String getCognome() {
		return cognome;
	}

	public void setCognome(java.lang.String cognome) {
		this.cognome = cognome;
	}

	public java.lang.String getEmail() {
		return email;
	}

	public void setEmail(java.lang.String email) {
		this.email = email;
	}

	public java.lang.String getTelefono() {
		return telefono;
	}

	public void setTelefono(java.lang.String telefono) {
		this.telefono = telefono;
	}

	public java.lang.String getIdimmobile() {
		return idimmobile;
	}

	public void setIdimmobile(java.lang.String idimmobile) {
		this.idimmobile = idimmobile;
	}

	public java.lang.String getMessaggio() {
		return messaggio;
	}

	public void setMessaggio(java.lang.String messaggio) {
		this.messaggio = messaggio;
	}

}
