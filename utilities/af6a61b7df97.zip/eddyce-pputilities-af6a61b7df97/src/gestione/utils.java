package gestione;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class utils {
    /*
     * true se il tipoannuncio e' relativo ad una foto (solo gli NO non hanno foto)
     * e potrebbe chiamarsi anche "tipovideo"
     */
    public static boolean tipoFoto(String tipoannuncio) {
    	return (!tipoannuncio.equals("NO"));
    }
    
	public static double m2dbl(Object o) {
		if (o == null)
			return 0;
		return Double.parseDouble(o.toString());
	}
	
	public static int m2int(Object o) {
		if (o == null)
			return 0;
		return Integer.parseInt(o.toString());
	}
	
	public static int m2intE(Object o) {
		try {
			return Integer.parseInt(o.toString());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
	
	public static String m2str(Object o) {
		if (o == null)
			return "";
		return o.toString();
	}

	public static List resultSetToList(ResultSet rs) throws java.sql.SQLException {
		if (rs == null)
			return Collections.EMPTY_LIST;
		ResultSetMetaData md = rs.getMetaData();
		int columnCount = md.getColumnCount();
		List list = new ArrayList();
		Map rowData;
		while (rs.next()) {
			rowData = new HashMap(columnCount);
			for (int i = 1; i <= columnCount; i++) {
				// rowData.put(md.getColumnName(i), rs.getObject(i));

				// Modifica per HSQLDB che non rilascia i nomi campi in minuscolo
				rowData.put(md.getColumnName(i).toLowerCase(), rs.getObject(i));
			}
			list.add(rowData);
		}
		return list;
	}
	public static boolean isProduction() {
		return true;
	}

	// proprio debug mode, mi logga anche (NON USARE SU PP5)
	public static boolean isDebugMode() {
		return false;
	}

	// questo fa vedere le query ma non mi logga
	public static boolean isDebugModeLight() {
		return !isProduction();
	}
}