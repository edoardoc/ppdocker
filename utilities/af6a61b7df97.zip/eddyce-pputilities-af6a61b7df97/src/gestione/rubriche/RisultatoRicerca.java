/*
 * RisultatoRicerca.java gestione.rubriche - PPJR Created on 29-giu-2006 
 *
 */
package gestione.rubriche;

import java.io.Serializable;

public class RisultatoRicerca implements Serializable{
    private String tipo = null; //o = offerta, r = richiesta
    private Rbean rubrica = null;
    private Double rank = null;
    private int maxpallini = 20; 
    private int pallini = 0;
    private String ricercafiltrata = "";
    private String ricercapchiave = "";
    private String ricercapvocabolario = "";
    private String procedimentocalcolo = "";    // solo per debug
    
    public RisultatoRicerca(Rbean c, double rank, String tipo, String ricercafiltrata, String ricercapchiave, String ricercapvocabolario, String procedimentocalcolo) {
        this.rubrica=c;
        this.rank=new Double(rank);
        this.tipo=tipo;
        this.ricercafiltrata =ricercafiltrata;
        this.ricercapchiave=ricercapchiave;
        this.ricercapvocabolario=ricercapvocabolario;
        this.procedimentocalcolo = procedimentocalcolo;
    }
    public Rbean getRubrica() {
        return rubrica;
    }
    public void setRubrica(Rbean rubrica) {
        this.rubrica = rubrica;
    }
    public Double getRank() {
        return rank;
    }
    public void setRank(Double rank) {
        this.rank = rank;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    /*
     * Filtra le parole della ricerca appena effettuata
    public String filtraParolechiave(String string) {
        String res = "";
        res = string;   // restituisce la string iniziale per default (con un solo token NON si filtra)

        if (!string.equals("") && this.rubrica.getParolechiave() != null) {
            StringBuffer resb = new StringBuffer();
            StringTokenizer tk = new StringTokenizer(string," ");
            if (tk.countTokens() > 1) {
                while (tk.hasMoreTokens()) {
                    String tks = tk.nextToken().toString().toLowerCase();
                    if (!this.rubrica.getParolechiave().contains(tks)) {
                        resb.append(tks);
                        resb.append(" ");
                    }
                }
                res=resb.toString().trim();
            }
        }
        return res;
    }
    */
    public int getMaxpallini() {
        return maxpallini;
    }
    public void setMaxpallini(int maxpallini) {
        this.maxpallini = maxpallini;
    }
    public int getPallini() {
        return pallini;
    }
    public void setPallini(int pallini) {
        this.pallini = pallini;
    }
    public String getRicercafiltrata() {
        return ricercafiltrata;
    }
    public String getRicercapvocabolario() {
        return ricercapvocabolario;
    }
    public void setRicercapvocabolario(String ricercapvocabolario) {
        this.ricercapvocabolario = ricercapvocabolario;
    }
    public String getRicercapchiave() {
        return ricercapchiave;
    }
    public void setRicercapchiave(String ricercapchiave) {
        this.ricercapchiave = ricercapchiave;
    }
    public String getProcedimentocalcolo() {
        return procedimentocalcolo;
    }
    public void setProcedimentocalcolo(String procedimentocalcolo) {
        this.procedimentocalcolo = procedimentocalcolo;
    }
}
