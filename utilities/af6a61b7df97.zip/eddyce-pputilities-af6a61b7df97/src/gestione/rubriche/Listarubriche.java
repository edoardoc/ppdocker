package gestione.rubriche;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import it.portaportese.ui.shared.MiniRbean;
import it.portaportese.utils.DBWrapper;
import it.portaportese.utils.Strings;
import it.portaportese.utils.logging.Syslog;

public class Listarubriche implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3548516674331508552L;
	private Map categoriemap, perrubricamap, perrubricamapshort, perrubricarichiestamap, perpercorsomap;
	private ArrayList hrubric;
	private boolean linked;
	private boolean flat;
	private String href;
	private String BOLDOPEN = "<b>";
	private String BOLDCLOSE = "</b>";
	private int tdepth = 0;
	private int tdepthnew = 0;
	private int krinricerca = 0;
		
	private final int PRIMOLIVELLOMENU = -2;
	private final int SECONDOLIVELLOMENU = 10000;
	private StringBuffer jsmenudinamico;

	public Listarubriche() {
		linked = false;
		flat = false;
		href = "";
		jsmenudinamico = new StringBuffer("");
		categoriemap = Collections.synchronizedMap(new TreeMap());
		perrubricamap = Collections.synchronizedMap(new TreeMap());
		perrubricamapshort = Collections.synchronizedMap(new TreeMap());
		perrubricarichiestamap = Collections.synchronizedMap(new TreeMap());
		perpercorsomap = Collections.synchronizedMap(new TreeMap());
		hrubric = new ArrayList();
	}
	public String getHref() {
		return href;
	}
	public boolean getLinked() {
		return linked;
	}
	public int getPadre(int kc) {
		try {
			Rbean gb = ((Rbean) categoriemap.get(String.valueOf(kc)));
			return gb.getkrpadre();
		} catch (Exception e) {
			return 0;
		}
	}
	public Rbean getRubrica(int kc) {

		Rbean rr = null;
		rr = (Rbean) categoriemap.get(String.valueOf(kc));
		if (rr == null)
			rr = new Rbean();

		return (rr);
	}

	public Rbean getRubrica(String rubric) {
		// utiliza l'altra mappa, quella con le chiavi stringa "RUBRIC"
		// MODIFICATA, ora utilizza ANCHE le chiavi stringa subset kr >= 1000
		
		Rbean rr = null;
		
		//System.err.print("cerco rubrica: " + rubric);
		// presumo offerta su SHORT (caso più probabile)
		rr = (Rbean) perrubricamapshort.get(rubric);

		// presumo offerta su tutte
		if (rr == null)
			rr = (Rbean) perrubricamap.get(rubric);

		// magari è richiesta
		if (rr == null)
			rr = (Rbean) perrubricarichiestamap.get(rubric);

		if (rr == null)
			rr = new Rbean();

		//Syslog.write(" trovato kr: " + rr.getkr()); 
		return (rr);
	}
	public Rbean getRubrica(String rubric, String tiprec) {
		if (tiprec.equals(""))
			return getRubrica(rubric);
		else {
			for (int j =  0; j < hrubric.size(); j++) {
				Rbean c = (Rbean) hrubric.get(j);
				
				// scorre tutte le rubriche
				if (c.getRubric().equals(tiprec)) {
					Rbean padre = (Rbean) getRubrica(c.getkrpadre());
					if (padre.getRubric().equals(rubric)) {
						// anche il tiprec è uguale, trovato!
						return c;
					}
				}
			}
			Syslog.write("WARNING: getRubrica() rubric errato: rubric " + rubric + " tiprec " + tiprec);
			return new Rbean();
		}
	}
	public String getRubricapath(String rubric) {
		Rbean rr = null;

		// presumo offerta
		rr = (Rbean) perrubricamap.get(rubric);

		// magari è richiesta
		if (rr == null)
			rr = (Rbean) perrubricarichiestamap.get(rubric);

		if (rr == null)
			return "";
		else {
			
			krinricerca = rr.getkr();
			setLinked(false);
			setFlat(true);
			tdepth = 0;
			
			int kr=rr.getkr();
			if ((kr < 100) || (kr > 999)) 
				kr=getRubrica(rr.getkr()).getkrpadre();
				

			return "<b>" + getPath(rr.getkr()) + "</b>";
			
		}
	}
	public String getTRubrica(String rubric) {
		if (perrubricamap.get(rubric) == null)
			return "r"; // richiesta
		else
			return "o"; // offerta

	}
	
	public Rbean getMatchSempliceRubrica(String percorso) {
		return (Rbean) perpercorsomap.get(percorso);
	}

	public Rbean getMatchRubrica(String percorso) {
		if (!percorso.equals("")) {
			// tolgo la prima / SEMPRE
			percorso = percorso.substring(1, percorso.length());
			if (perpercorsomap.get(percorso) == null) {
				// Se e' nullo cosi', provo a vedere se ha / alla fine
				if (percorso.endsWith("/")) {
					percorso = percorso.substring(0, percorso.length()-1);
					return (Rbean) perpercorsomap.get(percorso);
				} else {
					// tolgo la parte dopo la /
					percorso = percorso.substring(0, percorso.lastIndexOf("/"));
					return (Rbean) perpercorsomap.get(percorso);
				}
			} else 
				return (Rbean) perpercorsomap.get(percorso);
		} else 
			return null;
	}
	
	public String getDRubrica(String rubric) {
		// questa restituisce solo un testo idoneo per pp
		//	utiliza l'altra mappa, quella con le chiavi stringa "RUBRIC"
		//return "<b>" + getRubrica(rubric).getRubric() + "</b> " + getRubrica(rubric).getDescrizione();
		
		return getDescrizioneRubrica(getRubrica(rubric));
	}

	public String getDRubrica(int kc) {
		// questa restituisce solo un testo idoneo per pp
		//return "<b>" + getRubrica(kc).getRubric() + "</b> " + getRubrica(kc).getDescrizione();
		return getDescrizioneRubrica(getRubrica(kc));
	}

	private String getDescrizioneRubrica(Rbean rr) {
		if (rr.getkrpadre() == SECONDOLIVELLOMENU) { // una categoria master
			return rr.getDescrizione();
		} else {
			return (getRubrica(rr.getkrpadre())).getDescrizione() + "<br>" + rr.getDescrizione();
		}
	}

	public Rbean getRamoRubrica(Rbean rr) {
		if (rr.getkrpadre() == SECONDOLIVELLOMENU || rr.getkr() == SECONDOLIVELLOMENU) { // una categoria master (passo base)
			return getRubrica(rr.getkr());
		} else {
			return getRamoRubrica(getRubrica(rr.getkrpadre()));
		}
	}

	public void calculateDepth(int kr) {

		Rbean gb = ((Rbean) categoriemap.get(String.valueOf(kr)));
		if (gb != null) {
			calculateDepth(gb.getkrpadre());
			tdepth++;
		}

	}
	public Rbean[] getPathArray(int kr) {
		try {
			Rbean gb = ((Rbean) categoriemap.get(String.valueOf(kr)));
			
			if (gb.getkrpadre() == SECONDOLIVELLOMENU) {
				// sono in testa
				Rbean[] rout = new Rbean[1];
				rout[0]=gb;
				return rout;
			
			} else if (gb.getkrpadre() != 0) {
				Rbean[] rr = getPathArray(gb.getkrpadre());
				Rbean[] rout = new Rbean[rr.length+1];
				System.arraycopy(rr, 0, rout, 0, rr.length);
				rout[rr.length]=gb;
				return rout;
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}	
	
	// costruisce il percorso (forse non più usata??)
	public String getPath(int kr) {
		try {
			Rbean gb = ((Rbean) categoriemap.get(String.valueOf(kr)));
			if ((gb == null) || (gb.getkrpadre() == -2))
				return "";

			else if (gb.getkrpadre() != 0) {
				return getPath(gb.getkrpadre())
					+ (tdepth++ > 0 ? " &raquo; " : "")
					+ (krinricerca != gb.getkr()
						? "" + gb.getDescrizione() + ""
						: (flat == true ? gb.getDescrizione() : BOLDOPEN + gb.getDescrizione() + BOLDCLOSE));

			} else {
				return (
					linked
						? "<a href=\"" + href + "kr=" + gb.getkr() + "\">" + gb.getDescrizione() + "</a>"
						: "" + gb.getDescrizione() + "");

			}
		} catch (Exception e) {
			return "";
		}
	}
	
	// costruisce il percorso...
	private String getPathMenu(int kr) {
		try {
			Rbean gb = ((Rbean) categoriemap.get(String.valueOf(kr)));

			if ((gb == null) || (gb.getkrpadre() == -2))
				return "";
			else {
				// TRASLAZIONE AL LIVELLO FINALE
				// FATTA SOLO PER LE FOGLIE DI LIV 3
				
				String prb = gb.getDescrizione();
				if (gb.getkrpadre() < 100) { 
					prb = translationNomeRubrica(prb);	// faccio cmq la prima sostituzione
					
					prb = Strings.replace(prb, "S.", "San-");
					prb = Strings.replace(prb, ",00", "");
					prb = Strings.replace(prb, "Prov.", "Provincia");
					prb = Strings.replace(prb, "_-_", "-");
					prb = Strings.replace(prb, "_", "-");
				}
				return getPathMenu(gb.getkrpadre()) + (tdepthnew++ >= 0 ? "/" : "") + prb;
			}
		} catch (Exception e) {
			return "";
		}
	}
	
	public void visitPreloadRubriche(int krp) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			
			if (c.getkrpadre() == krp) {
				String prb = getUrlRow(c);
				prb = prb.substring(1, prb.length());	// togli la / all'inizio
				
				perpercorsomap.put(prb, c);
				Syslog.write("PRELOAD PERCORSO RUBRICA KR=" + c.getkr() + " [" + getRubrica(c.getkrpadre()).getRubric() + ", " + c.getRubric() + "] <--> " + prb);
				
				visitPreloadRubriche(c.getkr()); // RICORSIONE SOLO SUI PADRI
			}
		}
	}	
	
	/*
	 * il set avviene solo per un valore di pagina != ""
	 */
	public void impostaPaginavera(int krp, String paginavera) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			// filtro in quanto non e' un vero albero ma una lista
			if (c.getkrpadre() == krp) {
				
				// ho trovato una pagina
				if ((!paginavera.equals("")) && (c.getPaginavera().equals(""))) {
					c.setPaginavera(paginavera);
					Syslog.write("Paginavera " + paginavera + " su " + c.getDescrizione());
				}
				impostaPaginavera(c.getkr(), c.getPaginavera()); // RICORSIONE
			}
		}
	}
	
	/*
	 * il set avviene solo per un valore di gruppo != ""
	 */
	public void impostaGruppi(int krp, String gruppo) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			// filtro in quanto non e' un vero albero ma una lista
			if (c.getkrpadre() == krp) {
				
				// ho trovato un gruppo
				if ((!gruppo.equals("")) && (c.getGruppo().equals(""))) {
					c.setGruppo(gruppo);
					Syslog.write("Raggruppamento " + gruppo + " su " + c.getDescrizione());
				}
				impostaGruppi(c.getkr(), c.getGruppo()); // RICORSIONE
			}
		}
	}
	
	/*
	 * il set avviene solo per un valore di Flags != ""
	 * 
	 * IMPORTANTE
	 * questa va chiamata dopo aver semplicemente impostato i campi dalla tabella rubrica
	 * (in pratica ci ripassa sopra ed imposta se trova blank, altrimenti lascia quello che trova)
	 * priorita' tabella!!!!  
	 */
	public void impostaListafiltri(int krp, String listafiltri) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			// filtro in quanto non e' un vero albero ma una lista
			if (c.getkrpadre() == krp) {
				
				// ho trovato un listafiltri
				if ((!listafiltri.equals("")) && (c.getListafiltri().equals(""))) {
					c.setListafiltri(listafiltri);
				}
				impostaListafiltri(c.getkr(), c.getListafiltri()); // RICORSIONE
				
				if (!c.getListafiltri().equals("")) {
					Syslog.write("Listafiltri -> " + c.getDescrizione() + ": " + c.getListafiltri());
				}
			}
		}
	}
	
	/*
	 * il set avviene solo per un valore di Flags != "
	 * IMPORTANTE funziona come impostaListafiltri
	 */
	public void impostaTipologie(int krp, String tipologie) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			// filtro in quanto non e' un vero albero ma una lista
			if (c.getkrpadre() == krp) {
				
				// ho trovato un tipologie
				if ((!tipologie.equals("")) && (c.getTipologie().equals(""))) {
					c.setTipologie(tipologie);
				}
				impostaTipologie(c.getkr(), c.getTipologie()); // RICORSIONE
				
				if (!c.getTipologie().equals("")) {
					Syslog.write("Tipologie -> " + c.getDescrizione() + ": " + c.getTipologie());
				}
			}
		}
	}
	
	public void impostaMqminmqmax(int krp, int mqmin, int mqmax, int mqintervallo) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			if (c.getkrpadre() == krp) {
				// ho trovato un mq (controllo solo mqintervallo)
				if ((mqintervallo != 0) && (c.getMqintervallo() == 0)) {
					c.setMqmin(mqmin);
					c.setMqmax(mqmax);
					c.setMqintervallo(mqintervallo);
				}
				impostaMqminmqmax(c.getkr(), c.getMqmin(), c.getMqmax(), c.getMqintervallo()); // RICORSIONE
				if (c.getMqintervallo() != 0) {
					Syslog.write("Mqmin, Mqmax, Mqintervallo -> " + c.getDescrizione() + ": " + c.getMqmin() + ", " + c.getMqmax() + ", " + c.getMqintervallo());
				}
			}
		}
	}
	
	public void impostaPlminplmax(int krp, int plmin, int plmax, int plintervallo) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			if (c.getkrpadre() == krp) {
				// ho trovato un Pl (controllo solo Plintervallo)
				if ((plintervallo != 0) && (c.getPlintervallo() == 0)) {
					c.setPlmin(plmin);
					c.setPlmax(plmax);
					c.setPlintervallo(plintervallo);
				}
				impostaPlminplmax(c.getkr(), c.getPlmin(), c.getPlmax(), c.getPlintervallo()); // RICORSIONE
				if (c.getPlintervallo() != 0) {
					Syslog.write("Plmin, Plmax, Plintervallo -> " + c.getDescrizione() + ": " + c.getPlmin() + ", " + c.getPlmax() + ", " + c.getPlintervallo());
				}
			}
		}
	}
	
	public void impostaKmminkmmax(int krp, int Kmmin, int Kmmax, int Kmintervallo) {
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
			if (c.getkrpadre() == krp) {
				// ho trovato un Km (controllo solo Kmintervallo)
				if ((Kmintervallo != 0) && (c.getKmintervallo() == 0)) {
					c.setKmmin(Kmmin);
					c.setKmmax(Kmmax);
					c.setKmintervallo(Kmintervallo);
				}
				impostaKmminkmmax(c.getkr(), c.getKmmin(), c.getKmmax(), c.getKmintervallo()); // RICORSIONE
				if (c.getKmintervallo() != 0) {
					Syslog.write("Kmmin, Kmmax, Kmintervallo -> " + c.getDescrizione() + ": " + c.getKmmin() + ", " + c.getKmmax() + ", " + c.getKmintervallo());
				}
			}
		}
	}
	
	private   class Comparer implements Comparator<Rbean> {
        public int compare(Rbean obj1, Rbean obj2)
        {
            return obj1.getRubric().compareTo(obj2.getRubric());
        }
    } 
	
	private   class MiniRBeanComparer implements Comparator<MiniRbean> {
		public int compare(MiniRbean obj1, MiniRbean obj2) {
            return obj1.getRubric().compareTo(obj2.getRubric());
		}
    } 
	
	/*
	 * ritorna un array di mini rbean delle sottorubriche del kr
	 */
	public ArrayList<MiniRbean> subRubriche(int krpadre) {
		ArrayList<MiniRbean> sr = new ArrayList<MiniRbean>();
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();

			if ((c.getkrpadre() == krpadre) && (!c.getPagina().equals("system"))) {
				MiniRbean mrb = new MiniRbean();
				mrb.setkrpadre(c.getkrpadre());
				mrb.setkr(c.getkr());
				mrb.setDescrizione(c.getDescrizione());
				mrb.setRubric(c.getRubric());
				sr.add(mrb);
			}
		
		}
		Collections.sort(sr, new MiniRBeanComparer());
		return sr;
	}
	public boolean isRubricaFoglia(int akr, int status) {
		// la regola della rubrica foglia deve cosiderare anche lo status utente:
		// per gli utenti commerciali si deve arrivare a quelle a 3 caratteri, per gli altri ci fermiamo a 2
		boolean rubricafoglia = false;
		
		if (akr != 0) {
			if (status >= 1) {
				// qui dobbiamo mettere una condizione che ci dice se una rubrica è effettivamente una foglia!
				rubricafoglia = !isPadrediqualcuno(akr);
			} else {
				if (getRubrica(akr).getRubric().length() == 2)
					rubricafoglia = true;
			}
		}
		
		Syslog.write("isRubricaFoglia per kr " + akr + " status " + status + " = " + rubricafoglia);
		return rubricafoglia;
	}
	public boolean isPadrediqualcuno(int akr) {
		boolean padrediqualcuno=false;
		for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
			Rbean c = (Rbean) i.next();
            
			// filtro per "simulare" un albero ennario
			if (c.getkrpadre() == akr) {
				padrediqualcuno=true;
			}
		}
		return padrediqualcuno;
	}
	
	private String getUrlRow(Rbean c) {
		return getPercorso(c.getkr());		
	}
	
	public void load(DBWrapper dm, DBWrapper dm2, String query, int uscita, int uscitaprecedente) throws SQLException {
		String key;
		
		int i=0;

		boolean errore = false;

		DataSource ds = null;
		try {
		    InitialContext ctx = new InitialContext();
		    ds = (DataSource) ctx.lookup("DSMAIN");
		} catch (Exception e) {
		    Syslog.write("Listarubriche: NON RIESCO A CARICARE DSMAIN", e);
		}
		Connection conn = ds.getConnection();

		dm.getList(query);
		while (dm.rsNext() && !errore) {

			Rbean c = new Rbean();
			c.setkr(dm.rsGetInt("kr"));
			key = String.valueOf(c.getkr());
			c.setkrpadre(dm.rsGetInt("krpadre"));
			c.setPagina(dm.rsGetString("pagina"));
			c.setPaginavera(dm.rsGetString("pagina"));
			c.setDescrizione(dm.rsGetString("descrizione"));
			c.setPrefissotesto(dm.rsGetString("prefissotesto").toUpperCase());
			c.setTitolobase(dm.rsGetString("titolobase"));
			c.setTitoloesteso(dm.rsGetString("titoloesteso"));
			c.setAlign(dm.rsGetString("align"));
			c.setHmenu(dm.rsGetInt("hmenu"));
			c.setRubric(dm.rsGetString("rubric"));
			c.setRubricrichieste(dm.rsGetString("rubricrichieste"));
			c.setGruppo(dm.rsGetString("gruppo").toUpperCase());
            
			c.setPrezzomin(dm.rsGetInt("prezzomin"));
			c.setPrezzomax(dm.rsGetInt("prezzomax"));
			c.setIntervallo(dm.rsGetInt("intervallo"));
			
			c.setListafiltri(dm.rsGetString("listafiltri"));
			c.setTipologie(dm.rsGetString("tipologia"));
			c.setMqmin(dm.rsGetInt("mqmin"));
			c.setMqmax(dm.rsGetInt("mqmax"));
			c.setMqintervallo(dm.rsGetInt("mqintervallo"));
			c.setPlmin(dm.rsGetInt("plmin"));
			c.setPlmax(dm.rsGetInt("plmax"));
			c.setPlintervallo(dm.rsGetInt("plintervallo"));
			c.setKmmin(dm.rsGetInt("kmmin"));
			c.setKmmax(dm.rsGetInt("kmmax"));
			c.setKmintervallo(dm.rsGetInt("kmintervallo"));
			
			hrubric.add(i++,c);
			categoriemap.put(key, c);
			
			if (c.getkrpadre() >=1000) {
				perrubricamapshort.put(c.getRubric(), c);
				//Syslog.write("caricando short, kr=" + c.getkr() + " rubric: " + c.getRubric());
			}
			
			perrubricamap.put(c.getRubric(), c);
            
			if (!c.getRubricrichieste().equals("")) {
				perrubricarichiestamap.put(c.getRubricrichieste(), c);
			}
		}
		dm.rsClose();
		
		// SERVE PER ESPORTARE LE RUBRICHE
		//Syslog.write("" + jsmenudinamico);
		buildLinkeria();	// COSTRUISCE I LINKS!!
		
		Syslog.write("********** CARICAMENTO PAGINA **********");
		impostaPaginavera(PRIMOLIVELLOMENU, ""); // scansione per impostare pagina
		
		Syslog.write("********** CARICAMENTO GRUPPI **********");
		impostaGruppi(PRIMOLIVELLOMENU, ""); // scansione per impostare i gruppi

		Syslog.write("********** CARICAMENTO LISTAFILTRI **********");
		impostaListafiltri(PRIMOLIVELLOMENU, ""); // scansione per impostare i flags
		
		Syslog.write("********** CARICAMENTO TIPOLOGIE **********");
		impostaTipologie(PRIMOLIVELLOMENU, ""); // scansione per impostare i flags
		
		Syslog.write("********** CARICAMENTO MQMIN, MQMAX, MQINTERVALLO **********");
		impostaMqminmqmax(PRIMOLIVELLOMENU, 0, 0, 0);

		Syslog.write("********** CARICAMENTO PLMIN, PLMAX, PLINTERVALLO **********");
		impostaPlminplmax(PRIMOLIVELLOMENU, 0, 0, 0);

		Syslog.write("********** CARICAMENTO KMMIN, KMMAX, KMINTERVALLO **********");
		impostaKmminkmmax(PRIMOLIVELLOMENU, 0, 0, 0);

	}
    
    static public int getCValueultimiduenumeri(DBWrapper dm, String rubrica, int uscita, int uscitaprecedente) throws SQLException {
        int value = 0;

        String q = "";
        if (rubrica.length() == 1) {
            //q = "select count(oid) as num from annuncio400 where substr(rubric,1,1) = '" + rubrica + "'";
        } else if (rubrica.length() == 2) {
            q = "select count(oid) as num from annuncio400 where (uscita=" + uscita + " OR uscita = " + (uscita > 0 ? uscitaprecedente : 0) + ") AND rubric = '" + rubrica + "'";
        } else {
            // non avrebbe senso!
            //q = "select count(oid) as num from annuncio400";
        }
        if (!q.equals("")) {
            dm.getList(q);
            dm.rsNext();
            value = dm.rsGetInt("num");
            dm.rsClose();
        }

        return value;
    }
    
	static public int getCValue(DBWrapper dm, String rubrica) throws SQLException {
		int value = 0;

		String q = "";
		if (rubrica.length() == 1) {
			//q = "select count(oid) as num from annuncio400 where substr(rubric,1,1) = '" + rubrica + "'";
		} else if (rubrica.length() == 2) {
			q = "select count(oid) as num from annuncio400 where rubric = '" + rubrica + "'";
		} else {
			q = "select count(oid) as num from annuncio400";
		}
		if (!q.equals("")) {
			dm.getList(q);
			dm.rsNext();
			value = dm.rsGetInt("num");
			dm.rsClose();
		}

		return value;
	}
    
    static public ArrayList trasformaArraylist(HashMap hm) {
        ArrayList listVersion = new ArrayList(hm.entrySet());
        Collections.sort(listVersion, new Comparator() {
            public int compare(Object o1, Object o2) {
                Integer v1 = (Integer) ((Map.Entry) o1).getValue();
                Integer v2 = (Integer) ((Map.Entry) o2).getValue();
                return v2.compareTo(v1);
            }
        });
        return listVersion;
    }
    
    static private HashMap getVocabolario(DBWrapper dm, String q) throws SQLException {
        HashMap vocabolario = new HashMap();

        if (!q.equals("")) {
            dm.getList(q);
            while(dm.rsNext()) {
                String testo = dm.rsGetString("tsmart");
                
                StringTokenizer tk = new StringTokenizer(Strings.removeStrange(Strings.evidenziaTokens(testo)).trim()," ");
                while (tk.hasMoreTokens()) {
                    String token=tk.nextToken().toLowerCase();
                    
                    if (vocabolario.containsKey(token)) {
                        int cnt = Integer.valueOf(vocabolario.get(token).toString()).intValue() + 1;
                        vocabolario.put(token, new Integer(cnt));
                    } else {
                        vocabolario.put(token, new Integer(1));
                    }
                }
            }
            dm.rsClose();
        }
        return vocabolario;
    }
    
    /*
     * 
     * Prepara un link corretto della rubrica
     * 
     */
    public String linkkr(Rbean c) {
        String lnk = "";
        String rubricapadre = getRubrica(c.getkrpadre()).getRubric();
        if (rubricapadre.length() == 2) {
            lnk="kr=" + c.getkrpadre() + "&sottorubrica=" + c.getkr();
        } else {
            lnk="kr=" + c.getkr();
        }
        return lnk;
    }
    
    /*
     * La funzione scorri è uno scheletro che mi garantisce lo scorrimento 
     * delle sole rubriche con annunci
     */
    public void scorri() throws SQLException {
            DataSource ds = null;
            try {
                InitialContext ctx = new InitialContext();
                ds = (DataSource) ctx.lookup("DSRO1");
            } catch (Exception e) {
                Syslog.write("Listarubriche: NON RIESCO A CARICARE DSRO", e);
            }
            Connection conn = ds.getConnection();
            DBWrapper dm = new DBWrapper(conn);
            String q = "";
            int totlmm=0;
            String where = "";

            for (Iterator i = categoriemap.values().iterator(); i.hasNext();) {
                Rbean c = (Rbean) i.next();
                
                if (!isPadrediqualcuno(c.getkr())) {
                    // check per selezionare delle rubriche vere e proprie!
                    String rubricapadre = getRubrica(c.getkrpadre()).getRubric();
                    if (rubricapadre.length() == 2) {
                        // confronto con tiprec
                        where = "tiprec = '" + c.getRubric() + "' and rubric = '" + rubricapadre + "'";
                        q = "select tsmart from annuncio400 where " + where;
                        
                    } else {
                        where = "rubric = '" + c.getRubric() + "'";
                        q = "select tsmart from annuncio400 where " + where;
                    }
                	c.setVocabolario(getVocabolario(dm, q));
                    
                	// *********** per costruire tabella ridotta
                	// System.out.println(qridotta);
                	
                    if (c.getVocabolario() != null) {
                        //Syslog.write(c.getkr() + " " + c.getDescrizione() + " " + c.getVocabolario().size() + " termini");
                        totlmm+=c.getVocabolario().size();
                    }
                }
                
                // verifico la richiesta
                // la richiesta non viene "tramandata" nei figli
                if ((c.getRubricrichieste().length() == 2) && (!c.getRubric().equals(c.getRubricrichieste()))) {
                    // q = "select testo from annuncio400 where uscita = " + uscita + " AND rubric = '" + c.getRubricrichieste() + "'";
                    where = "rubric = '" + c.getRubricrichieste() + "'";
                    q = "select tsmart from annuncio400 where " + where;
                    c.setVocabolariorichieste(getVocabolario(dm, q));
                    
                    if (c.getVocabolario() != null) {
                        //Syslog.write(c.getkr() + " (R) " + c.getDescrizione() + " " + c.getVocabolario().size() + " termini");
                        totlmm+=c.getVocabolariorichieste().size();
                    }
                }
                //Runtime rt = Runtime.getRuntime();
                //Syslog.write("memoria Kb (totale / disponibile): " + rt.totalMemory()/1024 + "/" + rt.freeMemory()/1024);
            }
            dm.closeDB();
            Syslog.write("VOCABOLARIO per tutte le uscite - TOTALE TERMINI: " + totlmm);
    }
    
	public void setHref(String xf) {
		href = xf;
	}
	public void setLinked(boolean xf) {
		linked = xf;
	}
	public String percorsoGruppi(int kr) {
		krinricerca = kr;
		setLinked(true);
		setFlat(false);
		setHref("index.jsp?");
		tdepth = 0;
		return getPath(kr);
	}
	
	public String percorsoGruppisenza(int kr) {
		if (kr != PRIMOLIVELLOMENU) {
			kr = getPadre(kr);
			krinricerca = kr;
			setLinked(true);
			setFlat(false);
			setHref("index.jsp?");
			tdepth = 0;
			return getPath(kr);
		}
		return "";
	}

	public String GetGrupposenzaflat(int kr) {
		krinricerca =  getPadre(kr);
		setLinked(false);
		setFlat(true);
		tdepth = 0;
		return getPath(kr);
	}
	
	public String GetGruppoflat(int kr) {
		krinricerca =  kr;
		setLinked(false);
		setFlat(true);
		tdepth = 0;
		return getPath(kr);
	}
	
	public String getGruppo(int kr) {
		krinricerca = kr;
		setLinked(false);
		setFlat(false);
		tdepth = 0;
		return getPath(kr);
	}
	public Rbean getThis(int kr) {
		return (Rbean) categoriemap.get(String.valueOf(kr));
	}
	public String getGruppoflat(int kr) {
			krinricerca = kr;
			setLinked(false);
			setFlat(true);
			tdepth = 0;

			return getPath(kr);
	}
	
	// viene invocata solo dal menu' 
	public String getPercorso(int kr) {
		tdepthnew = 0;
		return translationNomeRubrica(getPathMenu(kr));
	}
	
	/* TRASLAZIONE DI PRIMO LIVELLO */
	private String translationNomeRubrica(String s) {
		StringBuffer buf = new StringBuffer(2 * s.length());
		char ch;
		for (int n = 0; n < s.length(); n++) {
			ch = s.charAt(n);
			switch (ch) {
				case '\'' :
					buf.append("_");
					break;
				case 'à' :	// a con accento a sx
					buf.append("a");
					break;
				case ' ' :
					buf.append("_");
					break;
				default :
					buf.append(ch);
					break;
			}

		}
		return buf.toString();
	}
	public Object[] getGruppoflatarray (int kr, int sottorubrica) {
		try {
			
			return getPathArray(sottorubrica == 0 ? kr : sottorubrica);
		} catch (Exception e) { 
			Syslog.write("getGruppoflatarray ", e);
			return null;
		}
	}
		
	public int getTdepth() {
		if (krinricerca == 0)
			return 0;
		else
			return tdepth;
	}
	public void setFlat(boolean xflat) {
		flat = xflat;
	}
	public void setTdepth(int xtdepth) {
		tdepth = xtdepth;
	}

	public String cADS(String prefisso, int cADSkr, int cADSsottorubrica) {
		String tutto = "";
		if (cADSsottorubrica == 0) {
			// caso classico, siamo in una rubrica normale
			String rubric = getRubrica(cADSkr).getRubric();
			tutto = prefisso + "_" + rubric;
		} else {
			// siamo in una foglia, devo calcolare anche il tiprec
			String rubric = getRubrica(cADSkr).getRubric();
			String tiprec = getRubrica(cADSsottorubrica).getRubric();
			tutto = prefisso + "_" + rubric + "_" + tiprec;
		}
		
		// Syslog.write("TESTING ADSLOT " + tutto);
		return tutto;
	}
	public String getJsmenudinamico() {
		return jsmenudinamico.toString();
	}
	
	public void buildLinkeria() {
		visitPreloadRubriche(SECONDOLIVELLOMENU);
	}	
    public Map getCategoriemap() {
        return categoriemap;
    }
}
