package gestione.rubriche;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;

public class Rbean implements Serializable {
	private int kr = 0;
	private int krpadre = 0;
	private String pagina = "";
	private String paginavera = "";
	private String descrizione = "";
	private String prefissotesto = "";
	private String titolobase = "";
	private String titoloesteso = "";
	private String nomefoto = "";
	private int hmenu = 0;
	private String align = "";
	private String rubric = "";
	private String rubricrichieste = "";
	private String gruppo = "";
	private int prezzomin = 0;
	private int prezzomax = 0;
	private int intervallo = 0;
	
	private String listafiltri = "";
	private String tipologie = "";
	private int mqmin = 0;
	private int mqmax = 0;
	private int mqintervallo = 0;
	private int plmin = 0;
	private int plmax = 0;
	private int plintervallo = 0;
	private int kmmin = 0;
	private int kmmax = 0;
	private int kmintervallo = 0;
	
    private HashSet parolechiave = null;
	private int numeroannunci = 0;
    private int numeroannuncirubricheultiminumeri = 0;
    private HashMap vocabolario = null;
    private HashMap vocabolariorichieste = null;

    public Rbean() {
	}

	public String getDescrizione() {
		return descrizione;
	}

	public int getkr() {
		return kr;
	}

	public int getkrpadre() {
		return krpadre;
	}

	public String getNomefoto() {
		return nomefoto;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setkr(int kr) {
		this.kr = kr;
	}

	public void setkrpadre(int krpadre) {
		this.krpadre = krpadre;
	}

	public void setNomefoto(String nomefoto) {
		this.nomefoto = nomefoto;
	}
	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public int getHmenu() {
		return hmenu;
	}

	public void setHmenu(int hmenu) {
		this.hmenu = hmenu;
	}

	public String getAlign() {
		return align;
	}

	public void setAlign(String align) {
		this.align = align;
	}

	public String getRubric() {
		return rubric;
	}

	public void setRubric(String rubric) {
		this.rubric = rubric;
	}

	public String getRubricrichieste() {
		return rubricrichieste;
	}

	public void setRubricrichieste(String rubricrichieste) {
		this.rubricrichieste = rubricrichieste;
	}

	public int getNumeroannunci() {
		return numeroannunci;
	}

	public void setNumeroannunci(int i) {
		numeroannunci = i;
	}

    public void setVocabolario(HashMap vocabolario) {
        this.vocabolario=vocabolario;
    }

    public HashMap getVocabolariorichieste() {
        return vocabolariorichieste;
    }

    public void setVocabolariorichieste(HashMap vocabolariorichieste) {
        this.vocabolariorichieste = vocabolariorichieste;
    }

    public HashMap getVocabolario() {
        return vocabolario;
    }

    public HashSet getParolechiave() {
        return parolechiave;
    }

    public void setParolechiave(HashSet parolechiave) {
        this.parolechiave = parolechiave;
    }

    public int getNumeroannuncirubricheultiminumeri() {
        return numeroannuncirubricheultiminumeri;
    }

    public void setNumeroannuncirubricheultiminumeri(int numeroannunciultimerubriche) {
        this.numeroannuncirubricheultiminumeri = numeroannunciultimerubriche;
    }

	public String getGruppo() {
		return gruppo;
	}

	public void setGruppo(String gruppo) {
		this.gruppo = gruppo;
	}

	public String getTitolobase() {
		return titolobase;
	}

	public void setTitolobase(String titolobase) {
		this.titolobase = titolobase;
	}

	public String getTitoloesteso() {
		return titoloesteso;
	}

	public void setTitoloesteso(String titoloesteso) {
		this.titoloesteso = titoloesteso;
	}

	public String getPrefissotesto() {
		return prefissotesto;
	}

	public void setPrefissotesto(String prefissotesto) {
		this.prefissotesto = prefissotesto;
	}

	public int getPrezzomin() {
		return prezzomin;
	}

	public void setPrezzomin(int prezzomin) {
		this.prezzomin = prezzomin;
	}

	public int getPrezzomax() {
		return prezzomax;
	}

	public void setPrezzomax(int prezzomax) {
		this.prezzomax = prezzomax;
	}

	public int getIntervallo() {
		return intervallo;
	}

	public void setIntervallo(int intervallo) {
		this.intervallo = intervallo;
	}

	public String getListafiltri() {
		return listafiltri;
	}

	public void setListafiltri(String listafiltri) {
		this.listafiltri = listafiltri;
	}

	public int getMqmin() {
		return mqmin;
	}

	public void setMqmin(int mqmin) {
		this.mqmin = mqmin;
	}

	public int getMqmax() {
		return mqmax;
	}

	public void setMqmax(int mqmax) {
		this.mqmax = mqmax;
	}

	public int getMqintervallo() {
		return mqintervallo;
	}

	public void setMqintervallo(int mqintervallo) {
		this.mqintervallo = mqintervallo;
	}

	public int getPlmin() {
		return plmin;
	}

	public void setPlmin(int plmin) {
		this.plmin = plmin;
	}

	public int getPlmax() {
		return plmax;
	}

	public void setPlmax(int plmax) {
		this.plmax = plmax;
	}

	public int getPlintervallo() {
		return plintervallo;
	}

	public void setPlintervallo(int plintervallo) {
		this.plintervallo = plintervallo;
	}

	public int getKmmin() {
		return kmmin;
	}

	public int getKmmax() {
		return kmmax;
	}

	public int getKmintervallo() {
		return kmintervallo;
	}

	public void setKmmin(int kmmin) {
		this.kmmin = kmmin;
	}

	public void setKmmax(int kmmax) {
		this.kmmax = kmmax;
	}

	public void setKmintervallo(int kmintervallo) {
		this.kmintervallo = kmintervallo;
	}

	public String getTipologie() {
		return tipologie;
	}

	public void setTipologie(String tipologie) {
		this.tipologie = tipologie;
	}

	public String getListafiltri2() {
		StringTokenizer st = new StringTokenizer(listafiltri, ",");
		StringBuffer out = new StringBuffer();
		while (st.hasMoreTokens()) {
			String cs = st.nextToken();
			if (cs.trim().length() == 2) {
				out.append(cs + " ");
			}
		}
		return out.toString().trim();
	}

	/*
	 * inutile versione della precedente che ritorna la lista dei filtri da 3 car separati dalla ,
	 * non posso parametrizzare perche' ci sono troppe istanze che la usano in modi diversi...
	 */
	public String getListafiltri3v() {
		StringTokenizer st = new StringTokenizer(listafiltri, ",");
		StringBuffer out = new StringBuffer();
		while (st.hasMoreTokens()) {
			String cs = st.nextToken();
			if (cs.trim().length() == 3) {
				out.append(cs + ",");
			}
		}
		return out.toString().trim();
	}
	
	public String getPaginavera() {
		return paginavera;
	}

	public void setPaginavera(String paginavera) {
		this.paginavera = paginavera;
	}

}
