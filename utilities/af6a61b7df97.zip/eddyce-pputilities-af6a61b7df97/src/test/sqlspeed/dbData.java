package test.sqlspeed;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dbData extends Thread {
	boolean ready = false;
	String query = "";
	private Statement stmt = null;
	private ResultSet rs = null;
	private Connection con = null;
	private long tempoconnessione = 0;
	private long tempofetch = 0;
	private long tempoesecuzione = 0;
	private boolean terminato = false;

	public long getTempoconnessione() {
		return tempoconnessione;
	}
	public long getTempofetch() {
		return tempofetch;
	}
	public long getTempoesecuzione() {
		return tempoesecuzione;
	}
	public boolean isTerminato() {
		return terminato;
	}
	public dbData(String pool, String query) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		long starttimer = System.currentTimeMillis();
		Class.forName("org.postgresql.Driver").newInstance();
		String machinename = pool.substring(6, pool.length()).toLowerCase(); 
		con = DriverManager.getConnection("jdbc:postgresql://" + machinename + ".prv.lan/dba400L1?compatible=7.1", "pepper", "hotsauce");
        stmt = con.createStatement();
		long stoptimer = System.currentTimeMillis();
        this.tempoconnessione  = (stoptimer-starttimer);
		this.query = query;
	}
	public void run() {
		while (!ready) {
			;
		}
		
		try {
			long starttimer = System.currentTimeMillis();
			rs = stmt.executeQuery(query);
			long stoptimer = System.currentTimeMillis();
			this.tempoesecuzione =  (stoptimer-starttimer);
			
			long starttimerf = System.currentTimeMillis();
	
			long i=0;
			StringBuffer cc= new StringBuffer();
			while (rs.next()) {
				i++;
				String aa = rs.getString("testo");
				long bb = rs.getLong("oid");
			}
			long stoptimerf = System.currentTimeMillis();
			//System.out.println("records = " + i);
			this.tempofetch = (stoptimerf-starttimerf);
			
			con.close();
		} catch (SQLException e) {
			System.out.println("errore db! " + e.getMessage());
			
		}
		terminato  = true;
	}
	public synchronized void start() {
		super.start();
	}
	
	public void setReady(boolean b) {
		ready = b;
	}
}
