package test.sqlspeed;

import test.sqlspeed.dbData;

import java.sql.SQLException;

public class dbDataLauncher {

	/**
	 * @param args
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public static void main(String[] args) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		if (args.length != 3) {
			System.out.println("args: " + args.length);
			System.out.println("dbDataLauncher QuantiThreads dba400PPX \"select testo limit 1\"");
			System.exit(1);
		}
		String squanti = args[0];
		String pool = args[1];
		String query = args[2];
		int quanti = Integer.parseInt(squanti);

		
		dbData[] nameThread = new dbData[quanti];
		for(int i=0; i < quanti;i++) {
			nameThread[i] = new dbData(pool, query);
			nameThread[i].start();		
			nameThread[i].setReady(true);
		}
		boolean tuttiterminati = false;
		while (!tuttiterminati) {
			tuttiterminati=true;
			for(int i=0; i < quanti;i++) {
				tuttiterminati = tuttiterminati && nameThread[i].isTerminato();
			}
		}
		long connessione = 0;
		long esecuzione = 0;
		long fetch = 0;
		long connessionemax = 0;
		long esecuzionemax = 0;
		long fetchmax = 0;
		long connessionemin = 10000000000000L;
		long esecuzionemin = 10000000000000L;
		long fetchmin = 10000000000000L;
		
		for(int i=0; i < quanti;i++) {
			
			connessione += nameThread[i].getTempoconnessione();
			esecuzione += nameThread[i].getTempoesecuzione();
			fetch += nameThread[i].getTempofetch();
			
			connessionemax = nameThread[i].getTempoconnessione() > connessionemax ? nameThread[i].getTempoconnessione() : connessionemax;
			connessionemin = nameThread[i].getTempoconnessione() < connessionemin ? nameThread[i].getTempoconnessione() : connessionemin;
			
			esecuzionemax = nameThread[i].getTempoesecuzione() > esecuzionemax ? nameThread[i].getTempoesecuzione() : esecuzionemax;
			esecuzionemin = nameThread[i].getTempoesecuzione() < esecuzionemin ? nameThread[i].getTempoesecuzione() : esecuzionemin;
			
			fetchmax = nameThread[i].getTempofetch() > fetchmax ? nameThread[i].getTempofetch() : fetchmax;
			fetchmin = nameThread[i].getTempofetch() < fetchmin ? nameThread[i].getTempofetch() : fetchmin;
						
		}		
		System.out.println("Numero threads: " + quanti);
		System.out.println("Tempo connessione medio: " + (connessione / quanti) + "ms");
		System.out.println("Tempo esecuzione medio: " + (esecuzione / quanti) + "ms");
		System.out.println("Tempo fetch medio: " + (fetch / quanti) + "ms");
		
		System.out.println("Tempo connessione max: " + connessionemax + "ms");
		System.out.println("Tempo connessione min: " + connessionemin + "ms");
		
		System.out.println("Tempo esecuzione max: " + esecuzionemax + "ms");
		System.out.println("Tempo esecuzione min: " + esecuzionemin + "ms");
		
		System.out.println("Tempo fetch max: " + fetchmax + "ms");
		System.out.println("Tempo fetch min: " + fetchmin + "ms");
		
	}
}