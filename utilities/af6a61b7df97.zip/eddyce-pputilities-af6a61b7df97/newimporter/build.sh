env GOOS=linux GOARCH=amd64 go build -o jsonifiermc_linux -v jsonifiermc.go
go build -o jsonifiermc_osx -v jsonifiermc.go 
