package main

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"html"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
)

type geoDef struct {
	Latitude  float64 `xml:"latitude"`
	Longitude float64 `xml:"longitude"`
}

type locationDef struct {
	City    string `xml:"city"`
	Country string `xml:"country"`
	Geo     geoDef `xml:"geo"`
}

type textDef struct {
	Locale string `xml:"locale,attr"`
	Data   string `xml:",chardata"`
}

type titleDef struct {
	Text []textDef `xml:"text"`
}

type descriptionDef struct {
	Text []textDef `xml:"text"`
}

type imageDef struct {
	Order string `xml:"order,attr"`
	URL   string `xml:",chardata"`
}

type imagesDef struct {
	Image []imageDef `xml:"image"`
}

type objectDef struct {
	ID          string         `xml:"id,attr"`
	Title       titleDef       `xml:"title"`
	Description descriptionDef `xml:"description"`
	Images      imagesDef      `xml:"images"`
	Location    locationDef    `xml:"location"`
	Units       unitsDef       `xml:"units"`
}

type objectsDef struct {
	Object []objectDef `xml:"object"`
}

type returnValueDef struct {
	Listing objectsDef `xml:"objects"`
}

type linksDef struct {
	Link []textDef `xml:"link"`
}

type unitDef struct {
	Bedrooms  string   `xml:"bedrooms,attr"`
	Maxguests int      `xml:"max_guests,attr"`
	Links     linksDef `xml:"links"`
}

type unitsDef struct {
	Unit []unitDef `xml:"unit"`
}

var in = `
<listing version="1.08.2" type="objects" timestamp="2016-11-29T15:28:36+01:00">
	<objects>
		<object id="78687">
			<title>
				<text locale="de"><![CDATA[Appartement mit 50 m&sup2;]]></text>
				<text locale="en"><![CDATA[Flat, 50 m&sup2;]]></text>
				<text locale="es"><![CDATA[Apartamento de 50 m&sup2;]]></text>
				<text locale="fr"><![CDATA[Appartement de 50 m&sup2;]]></text>
				<text locale="it"><![CDATA[Appartamento di 50 m&sup2;]]></text>
				<text locale="nl"><![CDATA[Appartement von 50 m&sup2;]]></text>
				<text locale="pt"><![CDATA[Apartamentos de 50 m&sup2;]]></text>
			</title>
			<scorings>
				<scoring locale="de">14</scoring>
				<scoring locale="en">15</scoring>
				<scoring locale="es">15</scoring>
				<scoring locale="fr">15</scoring>
				<scoring locale="it">18</scoring>
				<scoring locale="nl">15</scoring>
				<scoring locale="pt">15</scoring>
			</scorings>
			<description>
				<text locale="de"><![CDATA[Delicious sch&ouml;n eingerichtete Wohnung in Santa Maria di Leuca, nur 50 mt. vom Meer entfernt.&lt;br /&gt;Die Wohnung Es besteht aus zwei Schlafzimmer, 1 Badezimmer, Esszimmer, K&uuml;che, kleine Terrasse vor und externe W&auml;sche zusammen.&lt;br /&gt;Kostenlose Parkpl&auml;tze unter dem Haus.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;DIE ANGEGEBENEN PREISE SIND AUF DER BASIS EINES AUFENTHALTS VON 7 TAGEN BERECHNET.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;DIESE ANZEIGE PROFITIERT VON DER QUALIT&Auml;TSKONTROLLE VON MediaFerienPortal.com.]]></text>
				<text locale="en"><![CDATA[Beautifully furnished home located in Santa Maria di Leuca, just 50 mt. from the sea.&lt;br /&gt;The apartment is composed of two bedrooms, 1 bathroom, dining room, kitchen, small terrace in front, and external laundry.&lt;br /&gt;Free parking underneath the house.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;THE PRICES INDICATED ARE BASED ON 7 DAYS' RENTAL.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;THIS IS A MediaHols.com QUALITY CONTROLLED AD.]]></text>
				<text locale="es"><![CDATA[Deliciosa y hermosa casa amueblada ubicada en Santa Maria di Leuca, a s&oacute;lo 50 m del mar.&lt;br /&gt;El apartamento se compone de dos dormitorios, 1 ba&ntilde;o, sala comedor, cocina, peque&ntilde;a terraza y lavadero externo.&lt;br /&gt;Aparcamiento gratuito en la casa.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LAS TARIFAS INDICADAS SE CALCULAN SOBRE UNA BASE DE UNA ESTANCIA DE 7 D&Iacute;AS.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;ESTE ANUNCIO CUENTA CON EL CONTROL DE CALIDAD MediaVacaciones.com.]]></text>
				<text locale="fr"><![CDATA[D&eacute;licieuse maison joliment meubl&eacute; situ&eacute; &agrave; Santa Maria di Leuca, &agrave; seulement 50 mt. de la mer.&lt;br /&gt;L'appartement est compos&eacute; de deux chambres &agrave; coucher, 1 salle de bain, salle &agrave; manger, cuisine, petite terrasse &agrave; l'avant, et buanderie externe.&lt;br /&gt;Un parking gratuit sous la maison.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LES TARIFS INDIQUES SONT CALCULES SUR UNE BASE DE 7 JOURS DE LOCATION.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;CETTE ANNONCE BENEFICIE DU CONTROLE QUALITE MediaVacances.com.]]></text>
				<text locale="it"><![CDATA[Deliziosa dimora finemente arredata situata a Santa Maria di Leuca a soli 50 mt.  dal mare.L'appartamento e'composto da due camere da letto , 1 bagno, sala da pranzo, angolo cottura , piccolo terrazzo antistante , e lavanderia esterna.Parcheggio libero sotto casa.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LE TARIFFE INDICATE SONO CALCOLATE SULLA BASE DI 7 GIORNI DI AFFITTO.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;QUESTO ANNUNCIO BENEFICIA DEL CONTROLLO QUALITA MediaVacanze.com.]]></text>
				<text locale="nl"><![CDATA[Heerlijke prachtig ingerichte woning gelegen in Santa Maria di Leuca, op slechts 50 mt. van de zee. Het appartement bestaat uit twee slaapkamers, 1 badkamer, eetkamer, keuken klein terras voorzijde, wasruimte en gratis parkeerplaats onder het huis.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;DE AANGEGEVEN TARIEVEN WORDEN BEREKEND OP BASIS VAN EEN HUUR PER WEEK.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;DEZE ADVERTENTIE VALT ONDER DE KWALITEITSCONTROLE VAN MediaVakanties.com.]]></text>
				<text locale="pt"><![CDATA[Deliciosa casa muito bem decorada, situada em Santa Maria di Leuca, a apenas 50 m do mar. O apartamento &eacute; composto por dois quartos, uma casa de banho, sala de jantar, cozinha, pequeno terra&ccedil;o na frente  e lavandaria externa. Estacionamento gratuito e debaixo da casa.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;AS TARIFAS INDICADAS S&Atilde;O CALCULADAS COM BASE EM 7 DIAS DE LOCA&Ccedil;&Atilde;O.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;ESTE AN&Uacute;NCIO BENEFICIA DO CONTROLO DE QUALIDADE MediaFerias.com.]]></text>
			</description>
			<images>
				<image order="1">http://static.mediavacanze.com/img/Thumbnails/P/78687/1198167_l.jpeg</image>
				<image order="2">http://static.mediavacanze.com/img/Photos/P/78687/845914.jpg</image>
				<image order="3">http://static.mediavacanze.com/img/Thumbnails/P/78687/707102_l.jpg</image>
				<image order="4">http://static.mediavacanze.com/img/Thumbnails/P/78687/707105_l.jpg</image>
				<image order="5">http://static.mediavacanze.com/img/Thumbnails/P/78687/707104_l.jpg</image>
				<image order="6">http://static.mediavacanze.com/img/Thumbnails/P/78687/719000_l.jpg</image>
				<image order="7">http://static.mediavacanze.com/img/Photos/P/78687/707103.jpg</image>
				<image order="8">http://static.mediavacanze.com/img/Thumbnails/P/78687/705259_l.jpg</image>
				<image order="9">http://static.mediavacanze.com/img/Thumbnails/P/78687/705263_l.jpg</image>
				<image order="10">http://static.mediavacanze.com/img/Photos/P/78687/845389.jpg</image>
				<image order="11">http://static.mediavacanze.com/img/Thumbnails/P/78687/712632_l.jpg</image>
				<image order="12">http://static.mediavacanze.com/img/Thumbnails/P/78687/712633_l.jpg</image>
				<image order="13">http://static.mediavacanze.com/img/Photos/P/78687/845390.jpg</image>
				<image order="14">http://static.mediavacanze.com/img/Thumbnails/P/78687/1198162_l.jpg</image>
			</images>
			<location>
				<city>Santa Maria Di Leuca</city>
				<country>Italy</country>
				<geo>
					<latitude>39.793575</latitude>
					<longitude>18.350115</longitude>
				</geo>
			</location>
			<amenities>
				<amenity id="dishwasher">yes</amenity>
				<amenity id="washing_machine_available">yes</amenity>
				<amenity id="tv">yes</amenity>
				<amenity id="air_conditioning">yes</amenity>
				<amenity id="parking_lot">yes</amenity>
				<amenity id="smoking_allowed">yes</amenity>
				<amenity id="distance_to_water">50</amenity>
			</amenities>
			<units>
				<unit id="78687" max_guests="5" size="50" bedrooms="2" link="NOT RELIABLE http://www.mediavacanze.com/PORTAPORTESE78687">
					<links>
						<link locale="de">http://www.mediaferienportal.com/PORTAPORTESE78687</link>
						<link locale="en">http://www.mediahols.com/PORTAPORTESE78687</link>
						<link locale="es">http://www.mediavacaciones.com/PORTAPORTESE78687</link>
						<link locale="fr">http://www.mediavacances.com/PORTAPORTESE78687</link>
						<link locale="it">http://www.mediavacanze.com/PORTAPORTESE78687</link>
						<link locale="nl">http://www.mediavakanties.com/PORTAPORTESE78687</link>
						<link locale="pt">http://www.mediaferias.com/PORTAPORTESE78687</link>
					</links>
					<reviews count="2" avgRating="20">
						<review arrival="2013-07-20" created="2013-08-21" rating="20" nickname="Rosanna B." locale="it"><![CDATA[Casa vacanza che ha rispettato la descrizione avuta, inoltre la massima disponibilt&agrave; dei proprietari. Ottimo ricordo di Maria Di Leuca.&lt;br /&gt;]]></review>
						<review arrival="2013-08-17" created="2013-09-05" rating="20" nickname="Rosaria M." locale="it"><![CDATA[In questa casetta vale la pena alloggiarci per trascorrere le vacanze in totale relax. La cosa fondamentale &egrave; stata la pulizia della casa e la disponibilit&agrave; della proprietaria. Quest'alloggio si trova in una posizione alquanto centrale di Leuca, a pochissimi metri dalla scogliera e qualche metro in pi&ugrave; dalla spiaggia, proprio come viene specificato nella descrizione.]]></review>
					</reviews>
					<prices>
						<range dateFrom="2016-11-29" dateTo="2017-03-24">
							<price minStay="1" maxPersons="5" taxesIncluded="true" weekDays="1234567" currency="EUR">21.43</price>
						</range>
					</prices>
					<checkins>
						<range dateFrom="2016-11-29" dateTo="2018-11-29">
							<checkin>1234567</checkin>
						</range>
					</checkins>
					<availabilities>
						<range dateFrom="2016-11-29" dateTo="2018-11-29">
							<availability>11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111</availability>
						</range>
					</availabilities>
				</unit>
			</units>
		</object>
		<object id="76652">
			<title>
				<text locale="de"><![CDATA[Appartement mit 35 m&sup2;]]></text>
				<text locale="en"><![CDATA[Flat, 35 m&sup2;]]></text>
				<text locale="es"><![CDATA[Apartamento de 35 m&sup2;]]></text>
				<text locale="fr"><![CDATA[Appartement de 35 m&sup2;]]></text>
				<text locale="it"><![CDATA[Appartamento di 35 m&sup2;]]></text>
				<text locale="nl"><![CDATA[Appartement von 35 m&sup2;]]></text>
				<text locale="pt"><![CDATA[Apartamentos de 35 m&sup2;]]></text>
			</title>
			<scorings>
				<scoring locale="de">10</scoring>
				<scoring locale="en">10</scoring>
				<scoring locale="es">11</scoring>
				<scoring locale="fr">11</scoring>
				<scoring locale="it">16</scoring>
				<scoring locale="nl">11</scoring>
				<scoring locale="pt">11</scoring>
			</scorings>
			<description>
				<text locale="de"><![CDATA[The Cove Traum hat 3 Wohnungen zu vermieten, um einen ruhigen und erholsamen Urlaub zu verbringen! &lt;br/&gt; Komplett mit allen notwendigen Annehmlichkeiten f&uuml;r einen perfekten Komfort (gro&szlig;e K&uuml;che, Waschmaschine, Klimaanlage, Badezimmer mit Dusche, Wasserversorgung und Parkpl&auml;tze). Die ger&auml;umige K&uuml;che k&ouml;nnen Sie die atemberaubende Aussicht auf das Meer genie&szlig;en. Jede Wohnung bietet Platz f&uuml;r bis zu 4/5 Personen und befindet sich weniger als 5 Minuten zu Fu&szlig; vom Meer&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;DIE ANGEGEBENEN PREISE SIND AUF DER BASIS EINES AUFENTHALTS VON 7 TAGEN BERECHNET.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;DIESE ANZEIGE PROFITIERT VON DER QUALIT&Auml;TSKONTROLLE VON MediaFerienPortal.com.]]></text>
				<text locale="en"><![CDATA[The Cove Dream has 3 apartments for rent to spend a quiet and relaxing holiday! &lt;br/&gt; Complete with all the necessary amenities for a perfect comfort (large kitchen, washing machine, air conditioning, bathroom with shower, water supply and private parking). The spacious kitchen allows you to enjoy the stunning sea views. Each apartment can accommodate up to 4/5 people and is located less than 5 minutes walk from the sea&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;THE PRICES INDICATED ARE BASED ON 7 DAYS' RENTAL.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;THIS IS A MediaHols.com QUALITY CONTROLLED AD.]]></text>
				<text locale="es"><![CDATA[The Dream Cove dispone de 3 apartamentos en alquiler para pasar unas vacaciones tranquilas y relajantes! &lt;br/&gt; Completo con todas las comodidades necesarias para un perfecto confort (cocina amplia, lavadora, aire acondicionado, ba&ntilde;o con ducha, suministro de agua y estacionamiento privado). La cocina le permite disfrutar de las impresionantes vistas al mar. Cada apartamento tiene capacidad para 4/5 personas y est&aacute; situado a menos de 5 minutos a pie del mar&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LAS TARIFAS INDICADAS SE CALCULAN SOBRE UNA BASE DE UNA ESTANCIA DE 7 D&Iacute;AS.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;ESTE ANUNCIO CUENTA CON EL CONTROL DE CALIDAD MediaVacaciones.com.]]></text>
				<text locale="fr"><![CDATA[Le r&ecirc;ve Cove dispose de 3 appartements &agrave; louer pour un s&eacute;jour paisible et relaxant! &lt;br/&gt; Complet avec tous les agr&eacute;ments n&eacute;cessaires pour un confort parfait (grande cuisine, machine &agrave; laver, air conditionn&eacute;, salle de bain avec douche, d&amp;#39;approvisionnement en eau et d&amp;#39;un parking priv&eacute;). La cuisine spacieuse vous permet de profiter de la vue magnifique sur la mer. Chaque appartement peut accueillir jusqu&amp;#39;&agrave; 4/5 personnes et est situ&eacute; &agrave; moins de 5 minutes &agrave; pied de la mer&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LES TARIFS INDIQUES SONT CALCULES SUR UNE BASE DE 7 JOURS DE LOCATION.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;CETTE ANNONCE BENEFICIE DU CONTROLE QUALITE MediaVacances.com.]]></text>
				<text locale="it"><![CDATA[La Caletta da Sogno dispone di 3 appartamenti in affitto per trascorrere una tranquilla e rilassante vacanza!&lt;br /&gt;Completi di tutti i servizi necessari per un ottimo comfort (ampia cucina, lavatrice, aria condizionata, bagno con doccia, riserva idrica e parcheggio privato). L'ampia cucina consente di godere della splendida vista sul mare. Ciascun appartamento pu&ograve; alloggiare sino a 4/5 persone e si trovano a meno di 5 minuti a piedi dal mare&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LE TARIFFE INDICATE SONO CALCOLATE SULLA BASE DI 7 GIORNI DI AFFITTO.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;QUESTO ANNUNCIO BENEFICIA DEL CONTROLLO QUALITA MediaVacanze.com.]]></text>
				<text locale="nl"><![CDATA[The Cove Dream heeft 3 appartementen te huur om een ??rustige en ontspannen vakantie door te brengen! &lt;br/&gt; Compleet met alle nodige voorzieningen voor een perfect comfort (grote keuken, wasmachine, airconditioning, badkamer met douche, watervoorziening en een eigen parkeerplaats). De ruime keuken kunt u het prachtige uitzicht op zee te genieten. Elk appartement is geschikt voor maximaal 4/5 personen en is gelegen op minder dan 5 minuten lopen van de zee&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;DE AANGEGEVEN TARIEVEN WORDEN BEREKEND OP BASIS VAN EEN HUUR PER WEEK.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;DEZE ADVERTENTIE VALT ONDER DE KWALITEITSCONTROLE VAN MediaVakanties.com.]]></text>
				<text locale="pt"><![CDATA[O sonho Cove tem 3 apartamentos para alugar para umas f&eacute;rias tranquilas e relaxantes!&lt;br /&gt;Completo com todas as comodidades necess&aacute;rias para uma conforto perfeito (grande cozinha, m&aacute;quina de lavar roupa, ar condicionado, banheiro com chuveiro, abastecimento de &aacute;gua e estacionamento privado). A espa&ccedil;osa cozinha permite-lhe desfrutar da deslumbrante vista para o mar. Cada apartamento pode acomodar at&eacute; 4/5 pessoas e est&aacute; localizado a menos de 5 minutos a p&eacute; do mar&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;AS TARIFAS INDICADAS S&Atilde;O CALCULADAS COM BASE EM 7 DIAS DE LOCA&Ccedil;&Atilde;O.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;ESTE AN&Uacute;NCIO BENEFICIA DO CONTROLO DE QUALIDADE MediaFerias.com.]]></text>
			</description>
			<images>
				<image order="1">http://static.mediavacanze.com/img/Thumbnails/P/76652/671771_l.jpg</image>
				<image order="2">http://static.mediavacanze.com/img/Thumbnails/P/76652/671788_l.jpg</image>
				<image order="3">http://static.mediavacanze.com/img/Thumbnails/P/76652/671789_l.jpg</image>
				<image order="4">http://static.mediavacanze.com/img/Thumbnails/P/76652/671790_l.jpg</image>
				<image order="5">http://static.mediavacanze.com/img/Thumbnails/P/76652/671791_l.jpg</image>
				<image order="6">http://static.mediavacanze.com/img/Thumbnails/P/76652/671794_l.jpg</image>
				<image order="7">http://static.mediavacanze.com/img/Thumbnails/P/76652/671795_l.jpg</image>
				<image order="8">http://static.mediavacanze.com/img/Thumbnails/P/76652/671796_l.jpg</image>
				<image order="9">http://static.mediavacanze.com/img/Thumbnails/P/76652/671797_l.jpg</image>
				<image order="10">http://static.mediavacanze.com/img/Thumbnails/P/76652/671798_l.jpg</image>
				<image order="11">http://static.mediavacanze.com/img/Thumbnails/P/76652/671799_l.jpg</image>
			</images>
			<location>
				<city>La Caletta</city>
				<country>Italy</country>
				<geo>
					<latitude>40.608215</latitude>
					<longitude>9.748742</longitude>
				</geo>
			</location>
			<amenities>
				<amenity id="pets_allowed">yes</amenity>
				<amenity id="washing_machine_available">yes</amenity>
				<amenity id="tv">yes</amenity>
				<amenity id="air_conditioning">yes</amenity>
				<amenity id="microwave">yes</amenity>
				<amenity id="parking_lot">yes</amenity>
				<amenity id="smoking_allowed">yes</amenity>
				<amenity id="distance_to_water">300</amenity>
			</amenities>
			<units>
				<unit id="76652" max_guests="5" size="35" bedrooms="1" link="NOT RELIABLE http://www.mediavacanze.com/PORTAPORTESE76652">
					<links>
						<link locale="de">http://www.mediaferienportal.com/PORTAPORTESE76652</link>
						<link locale="en">http://www.mediahols.com/PORTAPORTESE76652</link>
						<link locale="es">http://www.mediavacaciones.com/PORTAPORTESE76652</link>
						<link locale="fr">http://www.mediavacances.com/PORTAPORTESE76652</link>
						<link locale="it">http://www.mediavacanze.com/PORTAPORTESE76652</link>
						<link locale="nl">http://www.mediavakanties.com/PORTAPORTESE76652</link>
						<link locale="pt">http://www.mediaferias.com/PORTAPORTESE76652</link>
					</links>
					<prices>
						<range dateFrom="2016-11-29" dateTo="2016-12-30">
							<price minStay="1" maxPersons="5" taxesIncluded="true" weekDays="1234567" currency="EUR">35.71</price>
						</range>
					</prices>
					<checkins>
						<range dateFrom="2016-11-29" dateTo="2018-11-29">
							<checkin>1234567</checkin>
						</range>
					</checkins>
					<availabilities>
						<range dateFrom="2016-11-29" dateTo="2018-11-29">
							<availability>11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111</availability>
						</range>
					</availabilities>
				</unit>
			</units>
		</object>
	</objects>
</listing>`

// TipoAnnuncio e' il tipo base
type TipoAnnuncio struct {
	Codice      string
	Titolo      string
	Testo       string
	Dove        locationDef
	Immagini    []string
	LinkEsterno string
	Persone     int
}

// ListaAnnunci e' invece la lista
type ListaAnnunci struct {
	Annuncio []TipoAnnuncio `json:"ListaAnnunci"`
}

func main() {
	var err error
	var r *strings.Reader

	r = strings.NewReader(in) // per usare la stringa locale
	if len(os.Args) >= 2 {
		xmlFile, err := os.Open(os.Args[1])
		if err != nil {
			fmt.Println("Error opening file:", err)
			return
		}
		defer xmlFile.Close()
		b, _ := ioutil.ReadAll(xmlFile)
		r = strings.NewReader(string(b)) // lettura url
	}
	var returnValue returnValueDef
	err = xml.NewDecoder(r).Decode(&returnValue)
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	da := 0
	indiceFinale := len(returnValue.Listing.Object) - 1
	a := indiceFinale
	if len(os.Args) == 4 {
		da, _ = strconv.Atoi(os.Args[2])
		a, _ = strconv.Atoi(os.Args[3])
		if a > indiceFinale || a == 0 {
			a = indiceFinale
		}
	}
	// fmt.Printf("indiceFinale = %d processo da %d a %d \n", indiceFinale, da, a)
	processa(returnValue, da, a)
}

func processa(returnValue returnValueDef, da int, a int) {
	var out ListaAnnunci
	for i := da; i <= a; i++ {
		var enn TipoAnnuncio

		enn.Codice = returnValue.Listing.Object[i].ID // id annuncio

		// titolo + Dove.City + max_guests + "persone"
		// Appartamento di 50 m² Santa Maria Di Leuca 5 persone
		enn.Persone = returnValue.Listing.Object[i].Units.Unit[0].Maxguests
		var titolo2di3 = returnValue.Listing.Object[i].Location.City
		titolo3di3 := ""
		if enn.Persone > 0 {
			titolo3di3 = fmt.Sprintf("%d persone", enn.Persone)
		}
		enn.Titolo = html.UnescapeString(valoreItaliano(returnValue.Listing.Object[i].Title.Text)) + " " + titolo2di3 + " " + titolo3di3

		enn.Testo = togliHTML(html.UnescapeString(valoreItaliano(returnValue.Listing.Object[i].Description.Text))) // testo
		enn.Dove = returnValue.Listing.Object[i].Location

		// images
		for j := range returnValue.Listing.Object[i].Images.Image {
			enn.Immagini = append(enn.Immagini, returnValue.Listing.Object[i].Images.Image[j].URL)
		}

		enn.LinkEsterno = valoreItaliano(returnValue.Listing.Object[i].Units.Unit[0].Links.Link)

		out.Annuncio = append(out.Annuncio, enn)
	}
	formattati, err := json.MarshalIndent(out, "", "    ")
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(string(formattati))
}

func valoreItaliano(xs []textDef) string {
	for _, v := range xs {
		if v.Locale == "it" {
			return v.Data
		}
	}
	return "n/a"
}

func togliHTML(xs string) string {
	xs = strings.Replace(xs, "<br />", "", -1)
	xs = strings.Replace(xs, "</strong>", "", -1)
	xs = strings.Replace(xs, "<br>", "", -1)
	xs = strings.Replace(xs, "<strong>", "", -1)
	return xs
}
