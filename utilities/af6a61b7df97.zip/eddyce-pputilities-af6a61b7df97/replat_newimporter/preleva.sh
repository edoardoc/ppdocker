#curl -s POST -d "{$dove}" https://api2.frimm.com/XAllegroFrimm.cgi

# HTML Form URL Encoded: application/x-www-form-urlencoded
#    Form item: "WsXml" = "yes"
#    Form item: "WsXmlData" = "<WsXmlData><caller><name>portaportese</name><key>mZs1OvCQaqrp7eJ3G4Tp5fx7fU6oV38o0s9egqpD</key></caller><login><username>portaportese</username><password>areatest</password></login><operation><object>ReRe</object>

cat WsXmlData.xml | curl -d WsXml=yes -d Encoding=B6 -d WsXmlData=@- http://apitest2.replat.com/XAllegroFrimm.cgi