scp root@www.portaportese.it:/root/rpp/WEB-INF/init/initdata.sbin ppbin/
