wget -q https://www.mediavacances.com/export/porta_portese.xml -O ./porta_portese.xml
if [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac OSX
		newimporter/jsonifiermc_osx porta_portese.xml | recode -S u8..HTML-i18n | java -Xmx1024M -cp build/.:./lib/* flusso.xml.CambiaChars > ./pp.json
else
    # else
		newimporter/jsonifiermc_linux porta_portese.xml | recode -S u8..HTML-i18n | java -Xmx1024M -cp build/.:./lib/* flusso.xml.CambiaChars > ./pp.json
fi
TODAY=`date +%Y%m%d-%H%M`
java -Xmx1024M -cp build/.:./lib/* flusso.xml.GestionaleMediaVacanze $1 ./pp.json 2>&1 
