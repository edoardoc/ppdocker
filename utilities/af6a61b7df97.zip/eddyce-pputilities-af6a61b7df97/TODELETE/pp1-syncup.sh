# -n dry run

rsync --delete --progress  --exclude 'lib/' --exclude 'files_esempio/' --exclude '.java' --exclude '.svn/' -e ssh -av ./build/ root@pp1.inroma.roma.it:/root/utilities/
rsync --delete --progress  --exclude '.java' --exclude '.svn/' -e ssh -av ./lib/ root@pp1.inroma.roma.it:/root/utilities/lib
rsync --delete --progress  --exclude '.java' --exclude '.svn/' -e ssh -av ./scripts/ root@pp1.inroma.roma.it:/root/utilities/scripts
scp runLogparser root@pp1.inroma.roma.it:/root/utilities/
scp gmmvc.sh root@pp1.inroma.roma.it:/root/
scp newimporter/jsonifiermc_linux root@pp1.inroma.roma.it:/home/mediavacanze
