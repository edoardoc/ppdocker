# -n dry run

rsync --delete --progress  --exclude 'lib/' --exclude 'files_esempio/' --exclude '.java' --exclude '.svn/' -e ssh -av ./build/ root@pp1.inroma.roma.it:/root/testut/
rsync --delete --progress  --exclude '.java' --exclude '.svn/' -e ssh -av ./lib/ root@pp1.inroma.roma.it:/root/testut/lib
