wget -q https://www.mediavacances.com/export/porta_portese.xml -O ./porta_portese.xml
./jsonifiermc_linux porta_portese.xml > ./pp.json
TODAY=`date +%Y%m%d-%H%M`
cd /root/
java -Xmx1024M -cp ./utilities:./utilities/lib/* flusso.xml.GestionaleMediaVacanze $1 $2 2>&1 | tee /root/gmmvclogs/$2-${TODAY}.log
