export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
# faccio query gestimmannuncio di tutti i ka che devono essere in linea
psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "select ka from gestimmannuncio where codiceoperazione <> 'e' order by ka " >  /tmp/oldList

export PGPASSWORD=hotsauce
# faccio query di tutti i ka che sono in linea di toscano
psql -t -h 194.242.232.21 -p 5432 -U pepper dba400L1 -c "select ka from annuncio400 where ((codcliente > 90299 AND codcliente < 90383) OR codcliente in (45629, 41453, 31866, 44659, 39261, 42337, 32700, 32120, 29339)) order by ka" >  /tmp/newList

# usa comm per mostrare le differenze.
comm -23 /tmp/oldList /tmp/newList > /tmp/diffEd

KAS="$(tr '\n' , < /tmp/diffEd)"
QUERY="delete from gestimmannuncio where ka in ("${KAS%??}")"

echo $QUERY
export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "$QUERY"
