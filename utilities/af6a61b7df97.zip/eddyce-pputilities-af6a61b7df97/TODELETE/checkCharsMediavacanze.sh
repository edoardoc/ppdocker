cat pp.json | java -Xmx1024M -cp build/.:./lib/* flusso.xml.CambiaChars | less
