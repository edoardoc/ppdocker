export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
# faccio query gestimmannuncio di tutti i ka che devono essere in linea
psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "select ka from gestmediavacanze where codiceoperazione <> 'e' order by ka " >  /tmp/oldmvList

export PGPASSWORD=hotsauce
# faccio query di tutti i ka che sono in linea di toscano
psql -t -h 194.242.232.21 -p 5432 -U pepper dba400L1 -c "select ka from annuncio400 where codcliente in (46005) order by ka" >  /tmp/newmvList

# usa comm per mostrare le differenze.
comm -23 /tmp/oldmvList /tmp/newmvList > /tmp/diffmvEd

KAS="$(tr '\n' , < /tmp/diffmvEd)"
QUERY="delete from gestmediavacanze where ka in ("${KAS%?}")"

echo $QUERY
#export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
#psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "$QUERY"
