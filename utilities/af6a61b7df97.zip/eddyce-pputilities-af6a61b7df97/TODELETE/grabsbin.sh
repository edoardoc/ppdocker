scp root@pp1:/home/ppjr/default-ear/default-war/WEB-INF/init/initdata.sbin ./ppbin/
