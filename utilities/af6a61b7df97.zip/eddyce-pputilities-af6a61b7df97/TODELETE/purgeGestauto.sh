rm /tmp/oldList /tmp/newList

export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
# faccio query gestimmannuncio di tutti i ka che devono essere in linea
psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "select ka from gestautoannuncio where codiceoperazione <> 'e' order by ka " >  /tmp/oldgaList

export PGPASSWORD=hotsauce
# faccio query di tutti i ka che sono in linea di toscano
psql -t -h 194.242.232.21 -p 5432 -U pepper dba400L1 -c "select ka from annuncio400 where codcliente in (43482, 27202, 36455, 45529, 46102, 33682) order by ka" >  /tmp/newgaList

# usa comm per mostrare le differenze.
comm -23 /tmp/oldgaList /tmp/newgaList > /tmp/diffgaEd

KAS="$(tr '\n' , < /tmp/diffgaEd)" 
QUERY="delete from gestautoannuncio where ka in ("${KAS%??}")"

echo $QUERY
#export PGPASSWORD=cia3s4t7e6f3a4n7o78jjkkklkldddEddyock
#psql -t -h 194.242.232.20 -p 5432 -U pepper portaportese -c "$QUERY"
