#!/bin/bash

mkdir -p ./toscanoimmobiliare
rm toscanoimmobiliare/*.txt
rm toscanoimmobiliare/*.xml*
dove=https://tportal.blob.core.windows.net/9ktparty-portaportese/_q1_jhgf_
# RICORDATI CHE L'URL VA DEPURATO DELLA PAROLA elenco.txt
# test https://tportalstage.blob.core.windows.net/9ktparty-portaportese/_q1_jhgf_
echo URL: "${dove}elenco.txt"
wget ${dove}elenco.txt --output-document toscanoimmobiliare/listatoscano.txt

# creo file temp
TMP_FILE=toscanoimmobiliare/ciccio.txt
cp -p toscanoimmobiliare/listatoscano.txt "${TMP_FILE}"

# prima stringa di sostituzione
stringa=s~^~${dove}~
echo stringa: ${stringa}

sed -e ${stringa} "${TMP_FILE}" > toscanoimmobiliare/listatoscano.txt
wget -i toscanoimmobiliare/listatoscano.txt -P toscanoimmobiliare/

java -Xmx1024M -cp build/.:./lib/* flusso.xml.GestionaleToscano toscanoimmobiliare/ $1 2>&1