echo 'working on...'
ls -l /files_gestionale_auto/
java -Xmx1024M -cp build/.:./lib/* flusso.xml.GestionaleAuto /files_gestionale_auto/ $1 2>&1 
