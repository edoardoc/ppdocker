# bisogna scaricare in locale i file dall ftp

