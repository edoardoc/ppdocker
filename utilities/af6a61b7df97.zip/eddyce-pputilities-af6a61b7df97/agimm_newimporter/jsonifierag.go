package main

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
)

var listaAgenzie = `
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<agenzie>
<agenzia>
<uniqueid><![CDATA[2385-1]]></uniqueid>
<ragionesociale><![CDATA[Casoli Franca "Immobiluna&Casedamare"]]></ragionesociale>
<referente><![CDATA[]]></referente>
<indirizzo><![CDATA[Viale Mazzini n.3]]></indirizzo>
<cap>19038</cap>
<cod_istat>011027</cod_istat>
<piva>01007630112</piva>
<codfiscale>01007630112</codfiscale>
<telefono1>0187691179</telefono1>
<telefono2></telefono2>
<cellulare1></cellulare1>
<cellulare2></cellulare2>
<fax></fax>
<email><![CDATA[info@immobiluna.com]]></email>
<web><![CDATA[http://www.immobiluna.com]]></web>
<logo><![CDATA[]]></logo>
</agenzia>
<agenzia>
<uniqueid><![CDATA[2369-1]]></uniqueid>
<ragionesociale><![CDATA[Az Immobiliare Misterbianco]]></ragionesociale>
<referente><![CDATA[Marasà Giuseppe/Fragalà Marco]]></referente>
<indirizzo><![CDATA[Via B. Buozzi n° 13/b]]></indirizzo>
<cap>95045</cap>
<cod_istat>087029</cod_istat>
<piva>04655970871</piva>
<codfiscale>04655970871</codfiscale>
<telefono1>095301265</telefono1>
<telefono2></telefono2>
<cellulare1></cellulare1>
<cellulare2></cellulare2>
<fax>095301265</fax>
<email><![CDATA[misterbianco@azimmobiliare.it]]></email>
<web><![CDATA[www.azimmobiliare.it]]></web>
<logo><![CDATA[http://static3.agimonline.com/pub_files/2369/logo/logo.png]]></logo>
</agenzia>
<agenzia>
<uniqueid><![CDATA[2369-4]]></uniqueid>
<ragionesociale><![CDATA[Az Immobiliare Mascalucia]]></ragionesociale>
<referente><![CDATA[Di Muni Daniele]]></referente>
<indirizzo><![CDATA[Via Roma n° 169]]></indirizzo>
<cap>95030</cap>
<cod_istat>087024</cod_istat>
<piva>04754350876</piva>
<codfiscale>04754350876</codfiscale>
<telefono1>0956179363</telefono1>
<telefono2>0957277940</telefono2>
<cellulare1>3407336374</cellulare1>
<cellulare2></cellulare2>
<fax>0952933735</fax>
<email><![CDATA[mascalucia@azimmobiliare.it]]></email>
<web><![CDATA[www.azimmobiliare.it]]></web>
<logo><![CDATA[http://static3.agimonline.com/pub_files/2369/logo/logo.png]]></logo>
</agenzia>
</agenzie>
`

var listaAnnunci = `
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<annunci>
<annuncio>
<uniqueid><![CDATA[2385-201346]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4783]]></riferimento>
<data_inserimento>20140716</data_inserimento>
<data_aggiornamento>20140716</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Semindipendente]]></tipologia>
<cod_istat>011027</cod_istat>
<zona><![CDATA[Bradia]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1296970</latitudine>
<longitudine>9.9712730</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Semindipendente - Trifamigliare a Bradia, Sarzana]]></titolo>
<descrizione><![CDATA[Sarzana, località Bradia, semindipendente con ingresso indipendente  in edificio quadrifamiliare composto da: ingresso in disimpegno, due camere, soggiorno con angolo cottura, antibagno e bagno. Posto auto. Consegna dell' immobile completamente rifinito.Sono disponibili altri  appartamenti con due camere da letto, terrazzi e giardini. 

 ]]></descrizione>
<mq>60</mq>
<prezzo>190000</prezzo>
<trattativa>0</trattativa>
<vani>3</vani>
<camere>2</camere>
<camere_note><![CDATA[matr.+cameretta]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[]]></soggiorno>
<piani><![CDATA[]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[In costruzione]]></condizioni>
<riscaldamento><![CDATA[]]></riscaldamento>
<cucina><![CDATA[Angolo cottura]]></cucina>
<classe_energetica><![CDATA[VA]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[ND]]></giardino_tipo>
<giardino_mq>200</giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>1</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>0</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102829.jpg</url>
<titolo><![CDATA[100_8988.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102826.jpg</url>
<titolo><![CDATA[100_8994.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102827.jpg</url>
<titolo><![CDATA[100_8986.jpg]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102828.jpg</url>
<titolo><![CDATA[100_8987.jpg]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102830.jpg</url>
<titolo><![CDATA[100_8989.jpg]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102831.jpg</url>
<titolo><![CDATA[100_8990.jpg]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102833.jpg</url>
<titolo><![CDATA[100_8992.jpg]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102834.jpg</url>
<titolo><![CDATA[100_8993.jpg]]></titolo>
<tipo></tipo>
</img_8>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201345]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4782]]></riferimento>
<data_inserimento>20140707</data_inserimento>
<data_aggiornamento>20140707</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Semindipendente]]></tipologia>
<cod_istat>011027</cod_istat>
<zona><![CDATA[]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1112566</latitudine>
<longitudine>9.96325539999998</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Semindipendente a Sarzana]]></titolo>
<descrizione><![CDATA[Sarzana, prima periferia , casetta semindipendente, tutta su di un livello con giardinetto privato, così composta: ingresso nel corridoio, cucina abitabile con balcone,soggiorno, due camere matrimoniali, bagno con doccia.  Riscaldamento termoautonomo,cantine di circa 30 mq. Sottotetto.Abitabile subito,arredata o non .Ideale anche come casa vacanze in quanto vicinissima al centro storico di Sarzana e a pochi minuti dalle spiagge!!]]></descrizione>
<mq>110</mq>
<prezzo>280000</prezzo>
<trattativa>0</trattativa>
<vani>4</vani>
<camere>2</camere>
<camere_note><![CDATA[matrimoniali]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[ con doccia]]></bagni_note>
<soggiorno><![CDATA[Normale]]></soggiorno>
<piani><![CDATA[readerAnnunci]]></piani>
<piani_totali>1</piani_totali>
<condizioni><![CDATA[Buono]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Abitabile]]></cucina>
<classe_energetica><![CDATA[ND]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>1</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[ND]]></giardino_tipo>
<giardino_mq>50</giardino_mq>
<cantina>1</cantina>
<cantina_mq>30</cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>1</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102805.jpg</url>
<titolo><![CDATA[100_8975.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102803.jpg</url>
<titolo><![CDATA[100_8985.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102804.jpg</url>
<titolo><![CDATA[100_8974.jpg]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102806.jpg</url>
<titolo><![CDATA[100_8976.jpg]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102808.jpg</url>
<titolo><![CDATA[100_8978.jpg]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102809.jpg</url>
<titolo><![CDATA[100_8979.jpg]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102810.jpg</url>
<titolo><![CDATA[100_8980.jpg]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102811.jpg</url>
<titolo><![CDATA[100_8981.jpg]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102812.jpg</url>
<titolo><![CDATA[100_8982.jpg]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102813.jpg</url>
<titolo><![CDATA[100_8983.jpg]]></titolo>
<tipo></tipo>
</img_10>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201344]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4781]]></riferimento>
<data_inserimento>20140702</data_inserimento>
<data_aggiornamento>20140704</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Semindipendente]]></tipologia>
<cod_istat>011027</cod_istat>
<zona><![CDATA[]]></zona>
<indirizzo><![CDATA[viale g. mazzini ]]></indirizzo>
<indirizzo_visibile>1</indirizzo_visibile>
<latitudine>44.110301396435986</latitudine>
<longitudine>9.965122217474345</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Semindipendente - Terratetto a Sarzana]]></titolo>
<descrizione><![CDATA[Sarzana fuori delle mura del centro storico semindipendente con piccola aia su due livelli così composta: Piano terra 4 locali ad uso cantina. Piano primo ingresso nel soggiorno, cucina,  bagno 2 camere e terrazzino. Impianti nuovi, bagno nuovo. Possibilità di unire internamente con scala i due livelli .  A F F A R E!!!]]></descrizione>
<mq>100</mq>
<prezzo>145000</prezzo>
<trattativa>0</trattativa>
<vani>5</vani>
<camere>2</camere>
<camere_note><![CDATA[camera matr. e cameretta]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[nuovocon doccia]]></bagni_note>
<soggiorno><![CDATA[Normale]]></soggiorno>
<piani><![CDATA[t]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[Abitabile]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[]]></cucina>
<classe_energetica><![CDATA[VA]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>1</cantina>
<cantina_mq>50</cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/m/102802.jpg</url>
<titolo><![CDATA[cittadella2.jpg]]></titolo>
<tipo></tipo>
</img_1>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201343]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4780]]></riferimento>
<data_inserimento>20140617</data_inserimento>
<data_aggiornamento>20140617</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>011020</cod_istat>
<zona><![CDATA[]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1112566</latitudine>
<longitudine>9.9632554</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Appartamento - Bilocale a Ortonovo]]></titolo>
<descrizione><![CDATA[Isola di Ortonovo, appartamentino  arredato nuovo, al piano secondo in casa di due piani, completamente ristrutturato composto da ingresso in cucina, con balcone,camera ,bagno con doccia, termoautonomo, aria condizionata,piccolo ripostiglio posto auto ,ideale per  single , come casa vacanze o ad uso investimento .Possibilità di unirlo ad altro appartamento stesso piano ( ns. rif. 4779)]]></descrizione>
<mq>40</mq>
<prezzo>80000</prezzo>
<trattativa>0</trattativa>
<vani>2</vani>
<camere>1</camere>
<camere_note><![CDATA[matrimoniale]]></camere_note>
<bagni></bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[]]></soggiorno>
<piani><![CDATA[2]]></piani>
<piani_totali>2</piani_totali>
<condizioni><![CDATA[Ristrutturato]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Abitabile]]></cucina>
<classe_energetica><![CDATA[VA]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>1</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>1</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102789.jpg</url>
<titolo><![CDATA[100_8969.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102787.jpg</url>
<titolo><![CDATA[100_8973.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102788.jpg</url>
<titolo><![CDATA[100_8968.jpg]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102790.jpg</url>
<titolo><![CDATA[100_8970.jpg]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102791.jpg</url>
<titolo><![CDATA[100_8971.jpg]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102792.jpg</url>
<titolo><![CDATA[100_8972.jpg]]></titolo>
<tipo></tipo>
</img_6>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201342]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4779]]></riferimento>
<data_inserimento>20140617</data_inserimento>
<data_aggiornamento>20140703</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>011020</cod_istat>
<zona><![CDATA[]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1112566</latitudine>
<longitudine>9.9632554</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Appartamento - trilocale a Ortonovo]]></titolo>
<descrizione><![CDATA[Isola  di Ortonovo appartamentino al piano secondo in casa di due piani, composto da ingresso, cucina abitabile, camera matrimoniale cameretta, bagno ,balcone che gira tutto intorno,possibilità di unirlo a bilocale ns. rif. 4780 sul solito piano .Ideale per giovane coppia ,single, oppure come casa vacanze.]]></descrizione>
<mq>55</mq>
<prezzo>135000</prezzo>
<trattativa>0</trattativa>
<vani>3</vani>
<camere>2</camere>
<camere_note><![CDATA[matr. + cameretta]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[]]></soggiorno>
<piani><![CDATA[2]]></piani>
<piani_totali>2</piani_totali>
<condizioni><![CDATA[Buono]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Abitabile]]></cucina>
<classe_energetica><![CDATA[VA]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>1</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>1</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102784.jpg</url>
<titolo><![CDATA[100_8964.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102779.jpg</url>
<titolo><![CDATA[100_8967.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102780.jpg</url>
<titolo><![CDATA[100_8960.jpg]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102781.jpg</url>
<titolo><![CDATA[100_8961.jpg]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102782.jpg</url>
<titolo><![CDATA[100_8962.jpg]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102783.jpg</url>
<titolo><![CDATA[100_8963.jpg]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102785.jpg</url>
<titolo><![CDATA[100_8965.jpg]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102786.jpg</url>
<titolo><![CDATA[100_8966.jpg]]></titolo>
<tipo></tipo>
</img_8>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201340]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[7498]]></riferimento>
<data_inserimento>20140603</data_inserimento>
<data_aggiornamento>20140623</data_aggiornamento>
<contratto><![CDATA[A]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>011027</cod_istat>
<zona><![CDATA[]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1112566</latitudine>
<longitudine>9.9632554</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Appartamento a Sarzana]]></titolo>
<descrizione><![CDATA[ Sarzana, località Ghiarettolo  si affitta a persone referenziate,appartamento arredato al piano terra con  ampio giardino privato ad angolo, composto da ingresso nel soggiorno con angolo cottura, ripostiglio, camera matrimoniale, bagno, giardino privato, posto auto .No animali .Altro appartamento al piano primo, con cantina al piano terra, sempre con giardino privato di uguale composizione e solito prezzo.Sono disponibili in agenzia altre soluzioni + grandi]]></descrizione>
<mq>50</mq>
<prezzo>550</prezzo>
<trattativa>0</trattativa>
<vani>2</vani>
<camere>1</camere>
<camere_note><![CDATA[matrimoniale]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[Normale]]></soggiorno>
<piani><![CDATA[]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[Buono]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Angolo cottura]]></cucina>
<classe_energetica><![CDATA[ND]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[ND]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>0</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/s/102760.jpg</url>
<titolo><![CDATA[case_189.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/s/102761.jpg</url>
<titolo><![CDATA[case_106.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/m/102762.jpg</url>
<titolo><![CDATA[th.jpg]]></titolo>
<tipo></tipo>
</img_3>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2385-201339]]></uniqueid>
<idagenzia><![CDATA[2385-1]]></idagenzia>
<riferimento><![CDATA[4777]]></riferimento>
<data_inserimento>20140523</data_inserimento>
<data_aggiornamento>20140616</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Semindipendente]]></tipologia>
<cod_istat>045008</cod_istat>
<zona><![CDATA[Fosdinovo paese]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>44.1112566</latitudine>
<longitudine>9.9632554</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Semindipendente - Terratetto a Fosdinovo paese, Fosdinovo]]></titolo>
<descrizione><![CDATA[Fosdinovo paese, casa  terratetto su tre livelli completamente ristrutturata così composta : ingresso con scale che portano alla cucina abitabile con balcone con vista aperta sulla campagna, piccolo dislivello con salotto/studio, secondo piano camera matrimoniale con bagno, loggia coperta, terzo piano  con vista parziale mare due camere, bagno. Al piano terra cantina di circa 25 mq. con piccola aia esterna ideale per fare il barbeque! Casa ideale per l'estate e le vacanze !.]]></descrizione>
<mq>75</mq>
<prezzo>160000</prezzo>
<trattativa>0</trattativa>
<vani>5</vani>
<camere>3</camere>
<camere_note><![CDATA[matr e camerette]]></camere_note>
<bagni>2</bagni>
<bagni_note><![CDATA[vasca e doccia]]></bagni_note>
<soggiorno><![CDATA[]]></soggiorno>
<piani><![CDATA[t]]></piani>
<piani_totali>3</piani_totali>
<condizioni><![CDATA[Ristrutturato]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Abitabile]]></cucina>
<classe_energetica><![CDATA[ND]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>1</cantina>
<cantina_mq>25</cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq>3</balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102745.jpg</url>
<titolo><![CDATA[100_8933.jpg]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102746.jpg</url>
<titolo><![CDATA[100_8934.jpg]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102747.jpg</url>
<titolo><![CDATA[100_8935.jpg]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102748.jpg</url>
<titolo><![CDATA[100_8936.jpg]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102749.jpg</url>
<titolo><![CDATA[100_8937.jpg]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102750.jpg</url>
<titolo><![CDATA[100_8938.jpg]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102751.jpg</url>
<titolo><![CDATA[100_8939.jpg]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102752.jpg</url>
<titolo><![CDATA[100_8940.jpg]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102753.jpg</url>
<titolo><![CDATA[100_8941.jpg]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102754.jpg</url>
<titolo><![CDATA[100_8942.jpg]]></titolo>
<tipo></tipo>
</img_10>
<img_11>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102755.jpg</url>
<titolo><![CDATA[100_8943.jpg]]></titolo>
<tipo></tipo>
</img_11>
<img_12>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102756.jpg</url>
<titolo><![CDATA[100_8944.jpg]]></titolo>
<tipo></tipo>
</img_12>
<img_13>
<url>http://static3.agimonline.com/pub_files/2385/img/b/102744.jpg</url>
<titolo><![CDATA[100_8932.jpg]]></titolo>
<tipo></tipo>
</img_13>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8173]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1778]]></riferimento>
<data_inserimento>20140717</data_inserimento>
<data_aggiornamento>20140717</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>087051</cod_istat>
<zona><![CDATA[Centro]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>37.574925</latitudine>
<longitudine>15.072771999999986</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Appartamento - 4 vani a Centro, Tremestieri Etneo]]></titolo>
<descrizione><![CDATA[Tremestieri etneo zona centro disponiamo di un appartamento NUOVISSIMO di 4 vani posto al secondo piano di un nuovo condominio in stile moderno.L'appartamento è in ottime condizione ed è composto da un soggiorno grande,una cucina semi abitabile, due camere da letto, lavanderia,bagno con doccia, cantina mq 10 e box auto privato di mq 20. ]]></descrizione>
<mq>100</mq>
<prezzo>200000</prezzo>
<trattativa>0</trattativa>
<vani>4</vani>
<camere>2</camere>
<camere_note><![CDATA[]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[con doccia]]></bagni_note>
<soggiorno><![CDATA[Grande]]></soggiorno>
<piani><![CDATA[2]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[Ottimo]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Semi abitabile]]></cucina>
<classe_energetica><![CDATA[C]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>1</garage>
<garage_mq>20</garage_mq>
<arredato>0</arredato>
<ascensore>1</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>1</cantina>
<cantina_mq>10</cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162442.jpg</url>
<titolo><![CDATA[Prospetto]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162443.jpg</url>
<titolo><![CDATA[Esterno]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162444.jpg</url>
<titolo><![CDATA[Balcone]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162445.jpg</url>
<titolo><![CDATA[Salone]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162446.jpg</url>
<titolo><![CDATA[Cucina]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162447.jpg</url>
<titolo><![CDATA[Lavanderia ]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162448.jpg</url>
<titolo><![CDATA[Bagno ]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162450.jpg</url>
<titolo><![CDATA[Bagno]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162449.jpg</url>
<titolo><![CDATA[Camera]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162451.jpg</url>
<titolo><![CDATA[Camera]]></titolo>
<tipo></tipo>
</img_10>
<img_11>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162452.jpg</url>
<titolo><![CDATA[Corridoio ]]></titolo>
<tipo></tipo>
</img_11>
<img_12>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162453.jpg</url>
<titolo><![CDATA[Cantina]]></titolo>
<tipo></tipo>
</img_12>
<img_13>
<url>http://static3.agimonline.com/pub_files/2369/img/b/162454.jpg</url>
<titolo><![CDATA[Box auto ]]></titolo>
<tipo></tipo>
</img_13>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8122]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1777]]></riferimento>
<data_inserimento>20140709</data_inserimento>
<data_aggiornamento>20140710</data_aggiornamento>
<contratto><![CDATA[A]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>087005</cod_istat>
<zona><![CDATA[Circonvallazione  ]]></zona>
<indirizzo><![CDATA[Via Paolo Vasta 16]]></indirizzo>
<indirizzo_visibile>1</indirizzo_visibile>
<latitudine>37.6048818</latitudine>
<longitudine>15.114872300000002</longitudine>
<coordinate_visibili>1</coordinate_visibili>
<titolo><![CDATA[Appartamento a Circonvallazione  , Aci Sant'Antonio]]></titolo>
<descrizione><![CDATA[Aci Sant'Antonio pressi Circonvallazione in residence su due elevazioni disponiamo con CONTRATTO AFFITTO CON RISCATTO di un Appartamento di vani 5 e mq 125, composto al primo piano da salone ingresso, 3 camere da letto matrimoniali, bagno con vasca, bagno con doccia e ripostiglio. Al secondo piano dispone di una cucina grande in muratura da completare l'arredamento, soggiorno avverando con camino e terrazza a livello di mq 50. L'immobile inoltre, dispone di riscaldamento autonomo a metano, garage di mq 15 e posto auto scoperto all'interno del residence. Panoramico lato Etna e lato mare! L' appartamento si trova in buono stato! ]]></descrizione>
<mq>125</mq>
<prezzo>700</prezzo>
<trattativa>0</trattativa>
<vani>5</vani>
<camere>3</camere>
<camere_note><![CDATA[]]></camere_note>
<bagni>2</bagni>
<bagni_note><![CDATA[UNO CON VASCA UNO CON DOCCIA]]></bagni_note>
<soggiorno><![CDATA[Media]]></soggiorno>
<piani><![CDATA[1]]></piani>
<piani_totali>2</piani_totali>
<condizioni><![CDATA[]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Angolo cottura]]></cucina>
<classe_energetica><![CDATA[F]]></classe_energetica>
<ape>112</ape>
<spese_condominiali>25</spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>1</garage>
<garage_mq>15</garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>1</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>1</terrazza>
<terrazza_mq>50</terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161717.jpg</url>
<titolo><![CDATA[Esterno]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161718.jpg</url>
<titolo><![CDATA[esterno1]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161719.jpg</url>
<titolo><![CDATA[ingresso residence]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161720.jpg</url>
<titolo><![CDATA[salone]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161721.jpg</url>
<titolo><![CDATA[vano]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161722.jpg</url>
<titolo><![CDATA[veranda]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161723.jpg</url>
<titolo><![CDATA[disimpegno]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161724.jpg</url>
<titolo><![CDATA[bagno]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161725.jpg</url>
<titolo><![CDATA[lavanderia]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161726.jpg</url>
<titolo><![CDATA[camera da letto]]></titolo>
<tipo></tipo>
</img_10>
<img_11>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161727.jpg</url>
<titolo><![CDATA[vista da balcone]]></titolo>
<tipo></tipo>
</img_11>
<img_12>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161728.jpg</url>
<titolo><![CDATA[balcone]]></titolo>
<tipo></tipo>
</img_12>
<img_13>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161729.jpg</url>
<titolo><![CDATA[cucina soggiorno]]></titolo>
<tipo></tipo>
</img_13>
<img_14>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161730.jpg</url>
<titolo><![CDATA[cucina]]></titolo>
<tipo></tipo>
</img_14>
<img_15>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161731.jpg</url>
<titolo><![CDATA[soggiorno ]]></titolo>
<tipo></tipo>
</img_15>
<img_16>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161732.jpg</url>
<titolo><![CDATA[soggiorno]]></titolo>
<tipo></tipo>
</img_16>
<img_17>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161733.jpg</url>
<titolo><![CDATA[terrazza]]></titolo>
<tipo></tipo>
</img_17>
<img_18>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161734.jpg</url>
<titolo><![CDATA[terrazza]]></titolo>
<tipo></tipo>
</img_18>
<img_19>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161735.jpg</url>
<titolo><![CDATA[vista etna]]></titolo>
<tipo></tipo>
</img_19>
<img_20>
<url>http://static3.agimonline.com/pub_files/2369/img/m/161736.jpg</url>
<titolo><![CDATA[planimetria]]></titolo>
<tipo></tipo>
</img_20>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8121]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1776]]></riferimento>
<data_inserimento>20140709</data_inserimento>
<data_aggiornamento>20140710</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>087029</cod_istat>
<zona><![CDATA[Centro]]></zona>
<indirizzo><![CDATA[Via Dei mille 10]]></indirizzo>
<indirizzo_visibile>1</indirizzo_visibile>
<latitudine>37.5149314</latitudine>
<longitudine>15.009629200000063</longitudine>
<coordinate_visibili>1</coordinate_visibili>
<titolo><![CDATA[Appartamento - 3 vani a Centro, Misterbianco]]></titolo>
<descrizione><![CDATA[Misterbianco zona centrale disponiamo al secondo piano di un piccolo condominio un appartamento di 3 vani composto da un bagno con doccia, due camere, una cucina semi abitabile, soggiorno grande e lavanderia esterna. L'appartamento dispone di un lastrico solare di proprietà esclusiva.]]></descrizione>
<mq>84</mq>
<prezzo>90000</prezzo>
<trattativa>0</trattativa>
<vani>3</vani>
<camere>2</camere>
<camere_note><![CDATA[]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[con doccia]]></bagni_note>
<soggiorno><![CDATA[Grande]]></soggiorno>
<piani><![CDATA[2]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[Discreto]]></condizioni>
<riscaldamento><![CDATA[]]></riscaldamento>
<cucina><![CDATA[Semi abitabile]]></cucina>
<classe_energetica><![CDATA[VA]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161752.jpg</url>
<titolo><![CDATA[esterno]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161753.jpg</url>
<titolo><![CDATA[balcone]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161754.jpg</url>
<titolo><![CDATA[bagno]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161755.jpg</url>
<titolo><![CDATA[cucina]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161756.jpg</url>
<titolo><![CDATA[disimpegno]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161757.jpg</url>
<titolo><![CDATA[cameretta]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161758.jpg</url>
<titolo><![CDATA[camera]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161759.jpg</url>
<titolo><![CDATA[lastrico solare]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161760.jpg</url>
<titolo><![CDATA[lastrico solare]]></titolo>
<tipo></tipo>
</img_9>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8120]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1775]]></riferimento>
<data_inserimento>20140709</data_inserimento>
<data_aggiornamento>20140711</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Appartamento]]></tipologia>
<cod_istat>087029</cod_istat>
<zona><![CDATA[Centro]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>37.51496506249097</latitudine>
<longitudine>15.006649535443103</longitudine>
<coordinate_visibili>1</coordinate_visibili>
<titolo><![CDATA[Appartamento a Centro, Misterbianco]]></titolo>
<descrizione><![CDATA[Misterbianco,zona centrale disponiamo di un appartamento in perfetto stato, posto al primo piano di un confortevole condominio composto da ingresso soggiorno,una camera da letto,una cameretta,bagno con vasca e cucina abitabile. L'appartamento inoltre dispone di due balconi di cui uno composto da lavanderia in veranda. Il tutto in ottime condizioni!]]></descrizione>
<mq>100</mq>
<prezzo>130000</prezzo>
<trattativa>0</trattativa>
<vani>3.5</vani>
<camere>2</camere>
<camere_note><![CDATA[]]></camere_note>
<bagni>1</bagni>
<bagni_note><![CDATA[con vasca]]></bagni_note>
<soggiorno><![CDATA[Media]]></soggiorno>
<piani><![CDATA[1]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[Ottimo]]></condizioni>
<riscaldamento><![CDATA[Autonomo]]></riscaldamento>
<cucina><![CDATA[Abitabile]]></cucina>
<classe_energetica><![CDATA[G]]></classe_energetica>
<ape></ape>
<spese_condominiali>35</spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[ND]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161702.jpg</url>
<titolo><![CDATA[esterna]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161703.jpg</url>
<titolo><![CDATA[esterna]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161704.jpg</url>
<titolo><![CDATA[esterno]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161705.jpg</url>
<titolo><![CDATA[salone]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161706.jpg</url>
<titolo><![CDATA[balcone]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161707.jpg</url>
<titolo><![CDATA[soggiorno]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161708.jpg</url>
<titolo><![CDATA[cucina]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161709.jpg</url>
<titolo><![CDATA[balcone]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161710.jpg</url>
<titolo><![CDATA[bagno]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161711.jpg</url>
<titolo><![CDATA[bagno]]></titolo>
<tipo></tipo>
</img_10>
<img_11>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161712.jpg</url>
<titolo><![CDATA[camera]]></titolo>
<tipo></tipo>
</img_11>
<img_12>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161713.jpg</url>
<titolo><![CDATA[camera]]></titolo>
<tipo></tipo>
</img_12>
<img_13>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161714.jpg</url>
<titolo><![CDATA[corridoio]]></titolo>
<tipo></tipo>
</img_13>
<img_14>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161715.jpg</url>
<titolo><![CDATA[corridoio]]></titolo>
<tipo></tipo>
</img_14>
<img_15>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161716.jpg</url>
<titolo><![CDATA[veranda]]></titolo>
<tipo></tipo>
</img_15>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8118]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1774]]></riferimento>
<data_inserimento>20140709</data_inserimento>
<data_aggiornamento>20140710</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Agricolo]]></tipologia>
<cod_istat>087029</cod_istat>
<zona><![CDATA[Zona Toscano]]></zona>
<indirizzo><![CDATA[Via Antonino Orlando ]]></indirizzo>
<indirizzo_visibile>1</indirizzo_visibile>
<latitudine>37.52719704196807</latitudine>
<longitudine>14.998944935443092</longitudine>
<coordinate_visibili>1</coordinate_visibili>
<titolo><![CDATA[Terreno Agricolo a Zona Toscano, Misterbianco]]></titolo>
<descrizione><![CDATA[Misterbianco a ridosso della zona toscano in via Antonino Orlando, disponiamo di terreno agricolo incolto mq 2900.]]></descrizione>
<mq>2900</mq>
<prezzo>60000</prezzo>
<trattativa>0</trattativa>
<vani>0</vani>
<camere></camere>
<camere_note><![CDATA[]]></camere_note>
<bagni></bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[]]></soggiorno>
<piani><![CDATA[]]></piani>
<piani_totali>0</piani_totali>
<condizioni><![CDATA[]]></condizioni>
<riscaldamento><![CDATA[]]></riscaldamento>
<cucina><![CDATA[]]></cucina>
<classe_energetica><![CDATA[]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>0</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[NS]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>0</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161761.jpg</url>
<titolo><![CDATA[mappa]]></titolo>
<tipo></tipo>
</img_1>
</images>
</annuncio>
<annuncio>
<uniqueid><![CDATA[2369-8104]]></uniqueid>
<idagenzia><![CDATA[2369-1]]></idagenzia>
<riferimento><![CDATA[1773]]></riferimento>
<data_inserimento>20140705</data_inserimento>
<data_aggiornamento>20140705</data_aggiornamento>
<contratto><![CDATA[V]]></contratto>
<tipologia><![CDATA[Indipendente]]></tipologia>
<cod_istat>087029</cod_istat>
<zona><![CDATA[Semicentro]]></zona>
<indirizzo><![CDATA[ ]]></indirizzo>
<indirizzo_visibile>0</indirizzo_visibile>
<latitudine>37.5194378</latitudine>
<longitudine>15.002554199999963</longitudine>
<coordinate_visibili>0</coordinate_visibili>
<titolo><![CDATA[Indipendente - Intero Stabile a Semicentro, Misterbianco]]></titolo>
<descrizione><![CDATA[Misterbianco,zona semicentrale disponiamo di un intero stabile composto da piano terra dove troviamo garage con bagno e sfogo esterno,primo piano composto da cucina abitabile,camera da letto,bagno,ampia zona giorno,lavanderia e balcone che si affaccia sul lato strada. Il secondo piano è ancora al grezzo quindi da rifinire, ed infine al piano superiore troviamo un ampia terrazza con vista panoramica lato montagna.]]></descrizione>
<mq></mq>
<prezzo>170000</prezzo>
<trattativa>0</trattativa>
<vani>0</vani>
<camere></camere>
<camere_note><![CDATA[]]></camere_note>
<bagni></bagni>
<bagni_note><![CDATA[]]></bagni_note>
<soggiorno><![CDATA[Grande]]></soggiorno>
<piani><![CDATA[]]></piani>
<piani_totali>3</piani_totali>
<condizioni><![CDATA[]]></condizioni>
<riscaldamento><![CDATA[]]></riscaldamento>
<cucina><![CDATA[]]></cucina>
<classe_energetica><![CDATA[]]></classe_energetica>
<ape></ape>
<spese_condominiali></spese_condominiali>
<spese_note><![CDATA[]]></spese_note>
<anno></anno>
<garage>1</garage>
<garage_mq></garage_mq>
<arredato>0</arredato>
<ascensore>0</ascensore>
<giardino_tipo><![CDATA[ND]]></giardino_tipo>
<giardino_mq></giardino_mq>
<cantina>0</cantina>
<cantina_mq></cantina_mq>
<taverna>0</taverna>
<taverna_mq></taverna_mq>
<postoauto>0</postoauto>
<postoauto_mq></postoauto_mq>
<balcone>1</balcone>
<balcone_mq></balcone_mq>
<terrazza>0</terrazza>
<terrazza_mq></terrazza_mq>
<prestigio>0</prestigio>
<images>
<img_1>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161455.jpg</url>
<titolo><![CDATA[Prospetto]]></titolo>
<tipo></tipo>
</img_1>
<img_2>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161433.jpg</url>
<titolo><![CDATA[Garage]]></titolo>
<tipo></tipo>
</img_2>
<img_3>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161434.jpg</url>
<titolo><![CDATA[Garage]]></titolo>
<tipo></tipo>
</img_3>
<img_4>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161435.jpg</url>
<titolo><![CDATA[Bagno garage]]></titolo>
<tipo></tipo>
</img_4>
<img_5>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161436.jpg</url>
<titolo><![CDATA[Ingresso/corpo scala]]></titolo>
<tipo></tipo>
</img_5>
<img_6>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161437.jpg</url>
<titolo><![CDATA[Cortile piano terra]]></titolo>
<tipo></tipo>
</img_6>
<img_7>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161438.jpg</url>
<titolo><![CDATA[Forno]]></titolo>
<tipo></tipo>
</img_7>
<img_8>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161439.jpg</url>
<titolo><![CDATA[Cortile]]></titolo>
<tipo></tipo>
</img_8>
<img_9>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161440.jpg</url>
<titolo><![CDATA[Cortile]]></titolo>
<tipo></tipo>
</img_9>
<img_10>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161441.jpg</url>
<titolo><![CDATA[Zona giorno (primo piano)]]></titolo>
<tipo></tipo>
</img_10>
<img_11>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161442.jpg</url>
<titolo><![CDATA[Cucina]]></titolo>
<tipo></tipo>
</img_11>
<img_12>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161443.jpg</url>
<titolo><![CDATA[Bagno]]></titolo>
<tipo></tipo>
</img_12>
<img_13>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161444.jpg</url>
<titolo><![CDATA[Camera da letto]]></titolo>
<tipo></tipo>
</img_13>
<img_14>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161445.jpg</url>
<titolo><![CDATA[Camera da letto]]></titolo>
<tipo></tipo>
</img_14>
<img_15>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161446.jpg</url>
<titolo><![CDATA[Lavanderia]]></titolo>
<tipo></tipo>
</img_15>
<img_16>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161447.jpg</url>
<titolo><![CDATA[Balcone interno]]></titolo>
<tipo></tipo>
</img_16>
<img_17>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161448.jpg</url>
<titolo><![CDATA[Balcone lato strada]]></titolo>
<tipo></tipo>
</img_17>
<img_18>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161449.jpg</url>
<titolo><![CDATA[Secondo piano]]></titolo>
<tipo></tipo>
</img_18>
<img_19>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161450.jpg</url>
<titolo><![CDATA[Secondo piano]]></titolo>
<tipo></tipo>
</img_19>
<img_20>
<url>http://static3.agimonline.com/pub_files/2369/img/b/161451.jpg</url>
<titolo><![CDATA[Secondo piano]]></titolo>
<tipo></tipo>
</img_20>
</images>
</annuncio>
</annunci>
`

type geoDef struct {
	Latitude  float64 `xml:"latitude"`
	Longitude float64 `xml:"longitude"`
}

type locationDef struct {
	Indirizzo string `xml:"indirizzo"`
	Geo       geoDef `xml:"geo"`
}

type textDef struct {
	Locale string `xml:"locale,attr"`
	Data   string `xml:",chardata"`
}

type titleDef struct {
	Text []textDef `xml:"text"`
}

type descriptionDef struct {
	Text []textDef `xml:"text"`
}

type imageDef struct {
	Link string `xml:"url"`
}

// Barbarico
type imagesDef struct {
	Image1  imageDef `xml:"img_1"`
	Image2  imageDef `xml:"img_2"`
	Image3  imageDef `xml:"img_3"`
	Image4  imageDef `xml:"img_4"`
	Image5  imageDef `xml:"img_5"`
	Image6  imageDef `xml:"img_6"`
	Image7  imageDef `xml:"img_7"`
	Image8  imageDef `xml:"img_8"`
	Image9  imageDef `xml:"img_9"`
	Image10 imageDef `xml:"img_10"`
	Image11 imageDef `xml:"img_11"`
	Image12 imageDef `xml:"img_12"`
	Image13 imageDef `xml:"img_13"`
	Image14 imageDef `xml:"img_14"`
	Image15 imageDef `xml:"img_15"`
	Image16 imageDef `xml:"img_16"`
	Image17 imageDef `xml:"img_17"`
	Image18 imageDef `xml:"img_18"`
	Image19 imageDef `xml:"img_19"`
	Image20 imageDef `xml:"img_20"`
}

type annunciDef struct {
	Annuncio []annuncioDef `xml:"annuncio"`
}

type annuncioDef struct {
	ID               string    `xml:"uniqueid"`
	IDagenzia        string    `xml:"idagenzia"`
	Titolo           string    `xml:"titolo"`
	Descrizione      string    `xml:"descrizione"`
	Superficie       int       `xml:"mq"`
	Prezzo           int       `xml:"prezzo"`
	Vani             float32   `xml:"vani"`
	ClasseEnergetica string    `xml:"classe_energetica"`
	IndirizzoSi      bool      `xml:"indirizzo_visibile"`
	Indirizzo        string    `xml:"indirizzo"`
	CoordinateSi     bool      `xml:"coordinate_visibili"`
	Longitudine      float64   `xml:"longitudine"`
	Latitudine       float64   `xml:"latitudine"`
	Images           imagesDef `xml:"images"`
}

type agenzieDef struct {
	Agenzia []agenziaDef `xml:"agenzia"`
}
type agenziaDef struct {
	ID             string `xml:"uniqueid"`
	Ragionesociale string `xml:"ragionesociale"`
	Indirizzo      string `xml:"indirizzo"`
	Cap            string `xml:"cap"`
	Tel1           string `xml:"telefono1"`
	Tel2           string `xml:"telefono2"`
	Email          string `xml:"email"`
}

// DATI IN OUTPUT TipoAnnuncio e' il tipo base
type TipoAnnuncio struct {
	Codice           string
	IDanagrafica     string
	Titolo           string
	Testo            string
	Telefono1        string
	Telefono2        string
	Email            string
	Dove             locationDef
	Immagini         []string
	LinkEsterno      string
	Vani             int
	Prezzo           int
	ClasseEnergetica string
	Superficie       int
}

// ListaAnnunci e' invece la lista
type ListaAnnunci struct {
	Annuncio []TipoAnnuncio `json:"ListaAnnunci"`
}

func main() {
	var err error
	var readerAnnunci *strings.Reader

	readerAnnunci = strings.NewReader(listaAnnunci) // per usare la stringa locale
	if len(os.Args) >= 2 {
		xmlFile, err := os.Open(os.Args[1])
		if err != nil {
			fmt.Println("Error opening file:", err)
			return
		}
		defer xmlFile.Close()
		b, _ := ioutil.ReadAll(xmlFile)
		readerAnnunci = strings.NewReader(string(b)) // lettura url
	}
	var xmlAnnunci annunciDef
	err = xml.NewDecoder(readerAnnunci).Decode(&xmlAnnunci)
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	readerAgenzie := strings.NewReader(listaAgenzie) // per usare la stringa locale
	var xmlAgenzie agenzieDef
	err = xml.NewDecoder(readerAgenzie).Decode(&xmlAgenzie)
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	agenziaMap := map[string]agenziaDef{}
	for i := 0; i <= len(xmlAgenzie.Agenzia)-1; i++ {
		agenziaMap[xmlAgenzie.Agenzia[i].ID] = xmlAgenzie.Agenzia[i]
	}

	da := 0
	indiceFinale := len(xmlAnnunci.Annuncio) - 1
	a := indiceFinale
	processa(xmlAnnunci, agenziaMap, da, a)
}

func processa(xmlAnnunci annunciDef, agenziaMap map[string]agenziaDef, da int, a int) {
	var out ListaAnnunci
	for i := da; i <= a; i++ {
		var enn TipoAnnuncio

		// se c'e' match con agenzia, altrimenti scarto!
		if v, ok := agenziaMap[xmlAnnunci.Annuncio[i].IDagenzia]; ok {
			enn.Telefono1 = v.Tel1
			enn.Telefono2 = v.Tel2
			enn.Email = v.Email

			enn.Codice = xmlAnnunci.Annuncio[i].ID
			enn.IDanagrafica = xmlAnnunci.Annuncio[i].IDagenzia
			enn.Titolo = xmlAnnunci.Annuncio[i].Titolo

			enn.Testo = xmlAnnunci.Annuncio[i].Descrizione
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image1.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image2.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image3.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image4.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image5.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image6.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image7.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image8.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image9.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image10.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image11.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image12.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image13.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image14.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image15.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image16.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image17.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image18.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image19.Link)
			enn.Immagini = append(enn.Immagini, xmlAnnunci.Annuncio[i].Images.Image20.Link)
			if xmlAnnunci.Annuncio[i].CoordinateSi {
				enn.Dove.Geo.Latitude = xmlAnnunci.Annuncio[i].Latitudine
				enn.Dove.Geo.Longitude = xmlAnnunci.Annuncio[i].Longitudine
			}
			if xmlAnnunci.Annuncio[i].IndirizzoSi {
				enn.Dove.Indirizzo = xmlAnnunci.Annuncio[i].Indirizzo
			}

			enn.Vani = int(xmlAnnunci.Annuncio[i].Vani + 0.5)
			enn.ClasseEnergetica = xmlAnnunci.Annuncio[i].ClasseEnergetica
			enn.Prezzo = xmlAnnunci.Annuncio[i].Prezzo
			enn.Superficie = xmlAnnunci.Annuncio[i].Superficie

			// images
			/*
				// titolo + Dove.City + max_guests + "persone"
				// Appartamento di 50 m² Santa Maria Di Leuca 5 persone
				enn.Persone = xmlAnnunci.Listing.Object[i].Units.Unit[0].Maxguests
				var titolo2di3 = xmlAnnunci.Listing.Object[i].Location.City
				titolo3di3 := ""
				if enn.Persone > 0 {
					titolo3di3 = fmt.Sprintf("%d persone", enn.Persone)
				}
				enn.Titolo = html.UnescapeString(valoreItaliano(xmlAnnunci.Listing.Object[i].Title.Text)) + " " + titolo2di3 + " " + titolo3di3

				enn.Testo = togliHTML(html.UnescapeString(valoreItaliano(xmlAnnunci.Listing.Object[i].Description.Text))) // testo
				enn.Dove = xmlAnnunci.Listing.Object[i].Location

				// images
				for j := range xmlAnnunci.Listing.Object[i].Images.Image {
					enn.Immagini = append(enn.Immagini, xmlAnnunci.Listing.Object[i].Images.Image[j].URL)
				}

				enn.LinkEsterno = valoreItaliano(xmlAnnunci.Listing.Object[i].Units.Unit[0].Links.Link)
			*/
			out.Annuncio = append(out.Annuncio, enn)
		}

	}
	formattati, err := json.MarshalIndent(out, "", "    ")
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(string(formattati))
}

func togliHTML(xs string) string {
	xs = strings.Replace(xs, "<br />", "", -1)
	xs = strings.Replace(xs, "</strong>", "", -1)
	xs = strings.Replace(xs, "<br>", "", -1)
	xs = strings.Replace(xs, "<strong>", "", -1)
	return xs
}
