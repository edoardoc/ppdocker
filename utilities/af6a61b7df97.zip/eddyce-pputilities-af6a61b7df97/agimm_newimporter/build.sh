env GOOS=linux GOARCH=amd64 go build -o jsonifierag_linux -v jsonifierag.go
go build -o jsonifierag_osx -v jsonifierag.go 
